# app/db.py

import json
import os

DB_FILE = "face_db.json"

# =========================
# INIT DB
# =========================
def _load_db():
    if not os.path.exists(DB_FILE):
        return {"users": {}, "embeddings": []}

    with open(DB_FILE, "r") as f:
        return json.load(f)


def _save_db(db):
    with open(DB_FILE, "w") as f:
        json.dump(db, f)


# =========================
# USERS
# =========================
def create_user(name):
    db = _load_db()

    user_id = str(len(db["users"]) + 1)
    db["users"][user_id] = name

    _save_db(db)
    return user_id


def get_user(user_id):
    db = _load_db()
    return db["users"].get(str(user_id))


def delete_user(user_id):
    db = _load_db()

    user_id = str(user_id)

    if user_id in db["users"]:
        del db["users"][user_id]

    db["embeddings"] = [
        e for e in db["embeddings"]
        if str(e["user_id"]) != user_id
    ]

    _save_db(db)


# =========================
# EMBEDDINGS
# =========================
def save_embedding(user_id, emb):
    db = _load_db()

    db["embeddings"].append({
        "user_id": str(user_id),
        "embedding": emb.tolist()
    })

    _save_db(db)


def get_all_embeddings():
    db = _load_db()

    result = []

    for e in db["embeddings"]:
        result.append({
            "user_id": e["user_id"],
            "embedding": e["embedding"]
        })

    return result


# =========================
# UPDATE HELPERS
# =========================
def clear_user_embeddings(user_id):
    db = _load_db()

    user_id = str(user_id)

    db["embeddings"] = [
        e for e in db["embeddings"]
        if str(e["user_id"]) != user_id
    ]

    _save_db(db)