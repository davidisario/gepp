# app/face_engine.py

from insightface.app import FaceAnalysis
import numpy as np
import cv2

app = FaceAnalysis(name="buffalo_s")
app.prepare(ctx_id=-1)

# Verificación: confirma qué modelo de reconocimiento se cargó
print(app.models['recognition'].taskname, app.models['recognition'].model_file)

def get_embedding(image_bytes):
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    faces = app.get(img)

    if len(faces) == 0:
        return None

    face = max(
        faces,
        key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1])
    )

    emb = face.embedding
    emb = emb / np.linalg.norm(emb)

    return emb