# generate_keys.py
import os
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

def generate_keys(output_dir="keys"):
    os.makedirs(output_dir, exist_ok=True)

    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with open(f"{output_dir}/ed25519_private.pem", "wb") as f:
        f.write(private_pem)

    public_raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    with open(f"{output_dir}/ed25519_public.raw", "wb") as f:
        f.write(public_raw)  # 32 bytes

    aes_key = os.urandom(32)
    with open(f"{output_dir}/aes_key.bin", "wb") as f:
        f.write(aes_key)  # 32 bytes

    print("Llaves generadas en:", output_dir)
    print("- ed25519_private.pem -> SOLO en el servidor, nunca sale de aquí")
    print("- ed25519_public.raw  -> copiar a Android (verificar firma)")
    print("- aes_key.bin         -> copiar a Android (descifrar offline)")

if __name__ == "__main__":
    generate_keys()