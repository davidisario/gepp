# app/main.py

import base64
from fastapi import FastAPI, UploadFile, File, Form
from typing import List

from app.face_engine import get_embedding
from app.db import create_user, save_embedding
from app.services.recognition import find_match
from app.models.schemas import RegisterResponse, RecognizeResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Request

app = FastAPI()

#CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # en prod lo restringes
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================
# REGISTER
# =========================

#@app.post("/register")
#async def register(request: Request):
#    body = await request.form()
#    print(body)


from fastapi.responses import FileResponse
import numpy as np
from app.qr_credential import (
    load_private_key, load_aes_key,
    generate_qr_payload, generate_credential_pdf,
)

PRIVATE_KEY = load_private_key("keys/ed25519_private.pem")
AES_KEY = load_aes_key("keys/aes_key.bin")
import tempfile
import os

CAPTURES_DIR = "capturas"

@app.post("/register")
async def register(
    id_empleado: str = Form(...),
    #pin: str = Form(...),
    files: List[UploadFile] = File(...)
):
    #user_id = create_user(id_empleado)

    #os.makedirs(CAPTURES_DIR, exist_ok=True)

    embeddings = []

    for idx, file in enumerate(files):
        image_bytes = await file.read()

        #ext = _get_extension(file.filename, file.content_type)
        #file_name = f"{id_empleado}_{pin}_{idx}{ext}"
        #file_path = os.path.join(CAPTURES_DIR, file_name)

        #with open(file_path, "wb") as f:
            #f.write(image_bytes)

        emb = get_embedding(image_bytes)
        if emb is not None:
            embeddings.append(emb)
            #save_embedding(user_id, emb)


    if not embeddings:
        return {"status": "error",
                "id_empleado": id_empleado,
                "detail": "No se detectó rostro en ninguna imagen"}

    # Promedia los embeddings de todas las fotos válidas y renormaliza --
    # da un "template" más robusto que usar una sola foto.
    avg_embedding = np.mean(embeddings, axis=0)
    avg_embedding = avg_embedding / np.linalg.norm(avg_embedding)

    #qr_encrypted = generate_qr_payload(id_empleado, pin, avg_embedding, PRIVATE_KEY, AES_KEY)

    #output_path = ("credenciales/credencial_"+id_empleado+".pdf")
    #generate_credential_pdf(id_empleado, qr_encrypted, output_path)

    #return FileResponse(
        #output_path,
        #media_type="application/pdf",
        #filename=f"credencial_{id_empleado}.pdf",
    #)

    b64_encoded = base64.b64encode(avg_embedding.tobytes())
    b64_string = b64_encoded.decode('utf-8')

    return {
        "status": "success",
        "id_empleado": id_empleado,
        "base64Embedding":b64_string,
            }


def _get_extension(filename: str, content_type: str) -> str:
    if filename and "." in filename:
        return os.path.splitext(filename)[1]
    if content_type == "image/png":
        return ".png"
    return ".jpg"

    # save_embedding() ya no se llama -- el almacenamiento en la base
    # central (para reimpresión) queda a cargo del cliente que consuma esta API.
# =========================
# RECOGNIZE
# =========================
"""@app.post("/recognize", response_model=RecognizeResponse)
async def recognize(file: UploadFile = File(...)):
    image_bytes = await file.read()
    emb = get_embedding(image_bytes)

    if emb is None:
        return {"user": None, "confidence": 0.0}

    user, score = find_match(emb)

    return {
        "user": user,
        "confidence": float(score)
    }"""

"""@app.delete("/user/{user_id}")
def delete_user_endpoint(user_id: int):
    from app.db import delete_user, get_user

    user = get_user(user_id)

    if not user:
        return {"error": "User not found"}

    delete_user(user_id)

    return {
        "status": "deleted",
        "user_id": user_id
    }
"""
"""@app.put("/user/{user_id}")
async def update_user(
    user_id: int,
    files: List[UploadFile] = File(...)
):
    from app.db import delete_user, save_embedding, get_user

    user = get_user(user_id)

    if not user:
        return {"error": "User not found"}

    if len(files) < 1:
        return {"error": "At least 1 image required"}

    # borrar embeddings anteriores
    delete_user(user_id)

    from app.db import create_user
    new_user_id = create_user(user)

    success = 0

    for file in files:
        image_bytes = await file.read()
        emb = get_embedding(image_bytes)

        if emb is not None:
            save_embedding(new_user_id, emb)
            success += 1

    if success == 0:
        return {
            "error": "No valid faces detected"
        }

    return {
        "status": "updated",
        "user_id": new_user_id,
        "embeddings_saved": success
    }
"""
"""@app.post("/user/{user_id}/embeddings")
async def add_embeddings(
    user_id: int,
    files: List[UploadFile] = File(...)
):
    from app.db import get_user, save_embedding

    user = get_user(user_id)

    if not user:
        return {"error": "User not found"}

    success = 0

    for file in files:
        image_bytes = await file.read()
        emb = get_embedding(image_bytes)

        if emb is not None:
            save_embedding(user_id, emb)
            success += 1

    if success == 0:
        return {"error": "No valid faces detected"}

    return {
        "status": "added",
        "user_id": user_id,
        "embeddings_added": success
    }"""