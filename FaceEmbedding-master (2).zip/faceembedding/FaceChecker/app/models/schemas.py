# app/models/schemas.py

from pydantic import BaseModel
from typing import Optional

class RegisterResponse(BaseModel):
    status: str
    user_id: int
    embeddings_saved: int

class RecognizeResponse(BaseModel):
    user: Optional[str]
    confidence: float