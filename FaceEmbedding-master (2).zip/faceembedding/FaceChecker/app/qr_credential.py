import os
import struct
import hashlib
import numpy as np
from datetime import datetime, timezone

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import serialization

import qrcode
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

FORMAT_VERSION = 1
EMBEDDING_DIM = 512
PIN_HASH_LEN = 16


def load_private_key(path: str) -> Ed25519PrivateKey:
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def load_aes_key(path: str) -> bytes:
    with open(path, "rb") as f:
        key = f.read()
    if len(key) != 32:
        raise ValueError("La llave AES debe ser de 32 bytes (AES-256)")
    return key


def quantize_embedding(embedding: np.ndarray) -> bytes:
    """Cuantiza el embedding L2-normalizado a int8 (-127..127). Reduce
    512 floats (2048 bytes) a 512 bytes -- 4x más chico, pérdida de
    precisión insignificante para similitud coseno."""
    scaled = np.clip(np.round(embedding * 127), -127, 127).astype(np.int8)
    return scaled.tobytes()


def hash_pin(pin: str, id_personal: str) -> bytes:
    """Hash truncado del PIN, salado con id_personal -- así dos empleados
    con el mismo PIN no producen el mismo hash."""
    digest = hashlib.sha256(f"{id_personal}:{pin}".encode("utf-8")).digest()
    return digest[:PIN_HASH_LEN]


def build_payload(id_personal: str, pin: str, embedding: np.ndarray) -> bytes:
    if len(id_personal) > 10:
        raise ValueError("id_personal no debe exceder 10 caracteres")
    if embedding.shape[0] != EMBEDDING_DIM:
        raise ValueError(f"Se esperaba un embedding de {EMBEDDING_DIM} dimensiones")

    id_bytes = id_personal.encode("ascii")
    issued_at = int(datetime.now(timezone.utc).timestamp())
    pin_hash = hash_pin(pin, id_personal)
    embedding_q = quantize_embedding(embedding)

    fmt = f"<BB{len(id_bytes)}sI{PIN_HASH_LEN}s{EMBEDDING_DIM}s"
    return struct.pack(
        fmt, FORMAT_VERSION, len(id_bytes), id_bytes, issued_at, pin_hash, embedding_q
    )


def sign_payload(payload: bytes, private_key: Ed25519PrivateKey) -> bytes:
    signature = private_key.sign(payload)  # 64 bytes
    return payload + signature


def encrypt_blob(blob: bytes, aes_key: bytes) -> bytes:
    aesgcm = AESGCM(aes_key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, blob, associated_data=None)  # incluye tag de 16 bytes
    return nonce + ciphertext


def generate_qr_payload(id_personal: str, pin: str, embedding: np.ndarray,
                         private_key: Ed25519PrivateKey, aes_key: bytes) -> bytes:
    payload = build_payload(id_personal, pin, embedding)
    signed = sign_payload(payload, private_key)
    return encrypt_blob(signed, aes_key)


def generate_qr_image(data: bytes):
    qr = qrcode.QRCode(
        version=None,  # ajusta automáticamente el tamaño necesario
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=6,
        border=4,
    )
    qr.add_data(data, optimize=0)  # bytes crudos -> modo byte nativo, sin Base64
    qr.make(fit=True)
    return qr.make_image(fill_color="black", back_color="white")

import tempfile
import os

def generate_credential_pdf(id_personal: str, qr_data: bytes, output_path: str):
    qr_img = generate_qr_image(qr_data)

    # esto ya no depende de la ruta de output_path -- genera su propio temp seguro
    qr_tmp_fd, qr_tmp_path = tempfile.mkstemp(suffix=".png")
    #qr_tmp_path = id_personal+".png"
    #os.close(qr_tmp_fd)  # cerramos el file descriptor, solo necesitamos la ruta

    qr_img.save(qr_tmp_path)

    page_width = 85 * mm
    page_height = 110 * mm
    c = canvas.Canvas(output_path, pagesize=(page_width, page_height))

    qr_size = 60 * mm
    qr_x = (page_width - qr_size) / 2
    c.drawImage(qr_tmp_path, qr_x, 35 * mm, width=qr_size, height=qr_size)

    c.setFont("Helvetica-Bold", 12)
    text = f"ID Personal: {id_personal}"
    text_width = c.stringWidth(text, "Helvetica-Bold", 12)
    c.drawString((page_width - text_width) / 2, 20 * mm, text)

    c.showPage()
    c.save()
    #os.remove(qr_tmp_path)