# app/services/recognition.py

import numpy as np
from app.db import get_all_embeddings, get_user

THRESHOLD = 0.5

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def find_match(embedding):
    best_user = None
    best_score = -1

    for record in get_all_embeddings():
        score = cosine_similarity(embedding, record["embedding"])

        if score > best_score:
            best_score = score
            best_user = record["user_id"]

    if best_score >= THRESHOLD:
        return get_user(best_user), best_score

    return None, best_score