const { exec } = require('child_process');
exec('npm run start:prod', (error, stdout, stderr) => {
  if (error) {
    console.log('Build output:\n', stdout, stderr);
  }
});

setTimeout(() => {
  fetch('http://localhost:3000/api/docs-json')
    .then(r => r.json())
    .then(data => {
      console.log('\n=== ENDPOINTS ENCONTRADOS ===\n');
      const paths = Object.keys(data.paths).sort();
      paths.forEach((path, i) => {
        const methods = Object.keys(data.paths[path]);
        console.log(`${i+1}. ${methods.join(', ').toUpperCase()} ${path}`);
      });
      console.log(`\nTOTAL: ${paths.length} endpoints`);
      process.exit(0);
    })
    .catch(err => {
      console.error('Error:', err.message);
      process.exit(1);
    });
}, 10000);
