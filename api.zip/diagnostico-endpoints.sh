#!/bin/bash

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  DIAGNÓSTICO DE ENDPOINTS - Cambio Mercado API              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

echo "📋 1. Verificando archivos de módulos..."
echo ""

if [ -f "src/modules/catalogos/catalogos.module.ts" ]; then
    echo "✅ catalogos.module.ts existe"
else
    echo "❌ catalogos.module.ts NO existe"
fi

if [ -f "src/modules/catalogos/catalogos.controller.ts" ]; then
    echo "✅ catalogos.controller.ts existe"
else
    echo "❌ catalogos.controller.ts NO existe"
fi

echo ""
echo "📋 2. Verificando importación en AppModule..."
grep "CatalogosModule" src/app.module.ts && echo "✅ CatalogosModule está importado" || echo "❌ CatalogosModule NO está importado"

echo ""
echo "📋 3. Contando endpoints en controladores..."
echo ""
echo "captura-cambio.controller.ts:"
grep -c "@Get\|@Post\|@Delete" src/modules/captura-cambio/controllers/captura-cambio.controller.ts
grep -E "@Get|@Post|@Delete" src/modules/captura-cambio/controllers/captura-cambio.controller.ts | sed 's/^/  /'

echo ""
echo "catalogos.controller.ts:"
grep -c "@Get\|@Post\|@Delete" src/modules/catalogos/catalogos.controller.ts
grep -E "@Get|@Post|@Delete" src/modules/catalogos/catalogos.controller.ts | sed 's/^/  /'

echo ""
echo "📋 4. Verificando que los controladores estén registrados..."
echo ""
echo "En CapturaCambioModule:"
grep "controllers:" src/modules/captura-cambio/captura-cambio.module.ts | sed 's/^/  /'

echo ""
echo "En CatalogosModule:"
grep "controllers:" src/modules/catalogos/catalogos.module.ts | sed 's/^/  /'

echo ""
echo "📋 5. Verificando compilación..."
echo ""
if [ -d "dist" ]; then
    echo "✅ Directorio dist/ existe"
    ls -lh dist/*.js 2>/dev/null | wc -l | xargs echo "  Archivos JS compilados:"
else
    echo "❌ Directorio dist/ NO existe - ejecuta: npm run build"
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  RESUMEN ESPERADO                                            ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  • CatalogosModule: ✅ Importado en AppModule                ║"
echo "║  • Controladores: 2 registrados                              ║"
echo "║  • Endpoints totales: 10                                     ║"
echo "║    - captura-cambio: 8 endpoints                             ║"
echo "║    - catalogos: 2 endpoints                                  ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "🔧 PASOS DE CORRECCIÓN:"
echo "1. rm -rf dist && npm run build"
echo "2. npm run start:dev"
echo "3. Abrir: http://localhost:3000/api/docs"
echo "4. Verificar que aparezcan los 3 tags:"
echo "   - Captura de Cambios (8)"
echo "   - Catálogos (2)"
echo "   - Auth (0)"
echo ""

