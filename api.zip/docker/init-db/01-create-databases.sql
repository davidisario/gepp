-- =====================================================
-- PCM - Portal de Cambios de Mercado
-- Script 01: Crear Bases de Datos
-- =====================================================

USE master;
GO

-- Crear base de datos PCMFULL (principal)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'PCMFULL')
BEGIN
    CREATE DATABASE PCMFULL
    COLLATE SQL_Latin1_General_CP1_CI_AS;
    PRINT 'Base de datos PCMFULL creada exitosamente.';
END
ELSE
BEGIN
    PRINT 'Base de datos PCMFULL ya existe.';
END
GO

-- Crear base de datos adc (secundaria)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'adc')
BEGIN
    CREATE DATABASE adc
    COLLATE SQL_Latin1_General_CP1_CI_AS;
    PRINT 'Base de datos adc creada exitosamente.';
END
ELSE
BEGIN
    PRINT 'Base de datos adc ya existe.';
END
GO

PRINT 'Script 01: Bases de datos creadas exitosamente.';
GO

