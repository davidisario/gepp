-- =====================================================
-- PCM - Portal de Cambios de Mercado
-- Script 02: Crear Usuarios y Permisos
-- =====================================================

USE master;
GO

-- Crear login para usuario de aplicación (PCMFULL)
IF NOT EXISTS (SELECT name FROM sys.sql_logins WHERE name = 'usrPCM')
BEGIN
    CREATE LOGIN usrPCM WITH PASSWORD = 'PCM_P@ssw0rd_2024!';
    PRINT 'Login usrPCM creado exitosamente.';
END
ELSE
BEGIN
    PRINT 'Login usrPCM ya existe.';
END
GO

-- Asignar permisos a PCMFULL
USE PCMFULL;
GO

IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = 'usrPCM')
BEGIN
    CREATE USER usrPCM FOR LOGIN usrPCM;
    PRINT 'Usuario usrPCM creado en base PCMFULL.';
END
GO

-- Dar permisos de db_owner al usuario (para desarrollo)
-- En producción, usar permisos más granulares
ALTER ROLE db_owner ADD MEMBER usrPCM;
GO

PRINT 'Permisos asignados a usrPCM en PCMFULL.';
GO

-- Asignar permisos a adc (usa SA directamente según el código)
USE adc;
GO

-- El código usa SA directamente para adc, no se necesita crear usuario adicional
PRINT 'Base de datos adc configurada (usa SA).';
GO

PRINT 'Script 02: Usuarios y permisos configurados exitosamente.';
GO

