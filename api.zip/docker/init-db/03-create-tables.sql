-- =====================================================
-- PCM - Portal de Cambios de Mercado
-- Script 03: Crear Tablas y Estructura
-- =====================================================
-- NOTA: Este es un esquema básico basado en la documentación
-- Ajustar según el schema real de producción
-- =====================================================

USE PCMFULL;
GO

-- =====================================================
-- Tablas Organizacionales
-- =====================================================

-- Tabla: region
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'region')
BEGIN
    CREATE TABLE region (
        idRegion INT IDENTITY(1,1) PRIMARY KEY,
        region VARCHAR(100) NOT NULL,
        estatus BIT NOT NULL DEFAULT 1
    );
    PRINT 'Tabla region creada.';
END
GO

-- Tabla: zona
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'zona')
BEGIN
    CREATE TABLE zona (
        idzona INT IDENTITY(1,1) PRIMARY KEY,
        zona VARCHAR(100) NOT NULL,
        idRegion INT NOT NULL,
        zonaHoraria VARCHAR(50) NOT NULL DEFAULT 'America/Mexico_City',
        CONSTRAINT FK_zona_region FOREIGN KEY (idRegion) REFERENCES region(idRegion)
    );
    PRINT 'Tabla zona creada.';
END
GO

-- Tabla: Deposito
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Deposito')
BEGIN
    CREATE TABLE Deposito (
        idDeposito INT IDENTITY(1,1) PRIMARY KEY,
        deposito VARCHAR(100) NOT NULL,
        idzona INT NOT NULL,
        direccion VARCHAR(255) NULL,
        dom BIT NOT NULL DEFAULT 0,
        lun BIT NOT NULL DEFAULT 1,
        mar BIT NOT NULL DEFAULT 1,
        mie BIT NOT NULL DEFAULT 1,
        jue BIT NOT NULL DEFAULT 1,
        vie BIT NOT NULL DEFAULT 1,
        sab BIT NOT NULL DEFAULT 0,
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_Deposito_zona FOREIGN KEY (idzona) REFERENCES zona(idzona)
    );
    PRINT 'Tabla Deposito creada.';
END
GO

-- Tabla: Operaciones
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Operaciones')
BEGIN
    CREATE TABLE Operaciones (
        idoperacion INT IDENTITY(1,1) PRIMARY KEY,
        idDeposito INT NOT NULL,
        descripcion VARCHAR(100) NOT NULL,
        tipoMercado TINYINT NOT NULL DEFAULT 0, -- 0=Tradicional, 1=Moderno
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_Operaciones_Deposito FOREIGN KEY (idDeposito) REFERENCES Deposito(idDeposito)
    );
    PRINT 'Tabla Operaciones creada.';
END
GO

-- =====================================================
-- Tablas de Seguridad
-- =====================================================

-- Tabla: UsrCambios
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UsrCambios')
BEGIN
    CREATE TABLE UsrCambios (
        NumEmpleado INT PRIMARY KEY,
        Nombre VARCHAR(100) NOT NULL,
        Psw VARCHAR(32) NOT NULL, -- MD5 hash
        nivel TINYINT NOT NULL, -- 1-8
        idoperacion INT NOT NULL,
        ppp INT NULL,
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_UsrCambios_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion)
    );
    PRINT 'Tabla UsrCambios creada.';
END
GO

-- =====================================================
-- Tablas Operacionales
-- =====================================================

-- Tabla: gruposupervision
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'gruposupervision')
BEGIN
    CREATE TABLE gruposupervision (
        idgruposupervision INT IDENTITY(1,1) PRIMARY KEY,
        NumEmpleado INT NOT NULL,
        idoperacion INT NOT NULL,
        descripcion VARCHAR(100) NOT NULL,
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_gruposupervision_UsrCambios FOREIGN KEY (NumEmpleado) REFERENCES UsrCambios(NumEmpleado),
        CONSTRAINT FK_gruposupervision_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion)
    );
    PRINT 'Tabla gruposupervision creada.';
END
GO

-- Tabla: rutascambios
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rutascambios')
BEGIN
    CREATE TABLE rutascambios (
        idruta INT IDENTITY(1,1) PRIMARY KEY,
        ruta INT NOT NULL,
        idoperacion INT NOT NULL,
        tipo TINYINT NOT NULL, -- 1=Fijo, 2=Dinámico
        tmercado TINYINT NOT NULL, -- 0=Tradicional, 1=Moderno, 2=Otro
        idgruposupervision INT NULL,
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_rutascambios_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion),
        CONSTRAINT FK_rutascambios_gruposupervision FOREIGN KEY (idgruposupervision) REFERENCES gruposupervision(idgruposupervision)
    );
    PRINT 'Tabla rutascambios creada.';
END
GO

-- Tabla: RutaTeleventa
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'RutaTeleventa')
BEGIN
    CREATE TABLE RutaTeleventa (
        idRutaTeleventa INT IDENTITY(1,1) PRIMARY KEY,
        numEmpleado INT NOT NULL,
        ruta INT NOT NULL,
        idoperacion INT NOT NULL,
        CONSTRAINT FK_RutaTeleventa_UsrCambios FOREIGN KEY (numEmpleado) REFERENCES UsrCambios(NumEmpleado),
        CONSTRAINT FK_RutaTeleventa_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion)
    );
    PRINT 'Tabla RutaTeleventa creada.';
END
GO

-- =====================================================
-- Tablas de Catálogos
-- =====================================================

-- Tabla: Producto
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Producto')
BEGIN
    CREATE TABLE Producto (
        sku VARCHAR(20) PRIMARY KEY,
        descripcion VARCHAR(200) NOT NULL,
        marca VARCHAR(50) NULL,
        categoria VARCHAR(50) NULL,
        presentacion VARCHAR(50) NULL,
        unidadesPorCaja INT NULL,
        estatus BIT NOT NULL DEFAULT 1
    );
    PRINT 'Tabla Producto creada.';
END
GO

-- Tabla: productoscambios
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'productoscambios')
BEGIN
    CREATE TABLE productoscambios (
        idProductoCambio INT IDENTITY(1,1) PRIMARY KEY,
        sku VARCHAR(20) NOT NULL,
        idoperacion INT NOT NULL,
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_productoscambios_Producto FOREIGN KEY (sku) REFERENCES Producto(sku),
        CONSTRAINT FK_productoscambios_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion)
    );
    PRINT 'Tabla productoscambios creada.';
END
GO

-- Tabla: Cliente
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Cliente')
BEGIN
    CREATE TABLE Cliente (
        CLAVE_CLIENTE INT NOT NULL,
        CLAVE_BODEGA INT NOT NULL,
        NOMBRE_CLIENTE VARCHAR(200) NOT NULL,
        DIRECCION VARCHAR(255) NULL,
        TELEFONO VARCHAR(20) NULL,
        RFC VARCHAR(13) NULL,
        TIPO_MERCADO TINYINT NULL, -- 0=Tradicional, 1=Moderno, 2=Otro
        estatus BIT NOT NULL DEFAULT 1,
        CONSTRAINT PK_Cliente PRIMARY KEY (CLAVE_CLIENTE, CLAVE_BODEGA)
    );
    PRINT 'Tabla Cliente creada.';
END
GO

-- Tabla: CambiosMotivos
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'CambiosMotivos')
BEGIN
    CREATE TABLE CambiosMotivos (
        idcambiosmotivos INT IDENTITY(1,1) PRIMARY KEY,
        descripcion VARCHAR(100) NOT NULL,
        agrupador VARCHAR(50) NOT NULL,
        estatus BIT NOT NULL DEFAULT 1,
        restcedis VARCHAR(100) NULL, -- CSV de IDs de CEDIS
        requiere_aut BIT NOT NULL DEFAULT 0
    );
    PRINT 'Tabla CambiosMotivos creada.';
END
GO

-- =====================================================
-- Tablas Transaccionales
-- =====================================================

-- Tabla: capturacambios (Principal)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'capturacambios')
BEGIN
    CREATE TABLE capturacambios (
        idcambios INT IDENTITY(1,1) PRIMARY KEY,
        nud INT NOT NULL,
        idBodega INT NOT NULL,
        sku VARCHAR(20) NOT NULL,
        cantidad INT NOT NULL,
        idcambiosmotivos INT NOT NULL,
        idoperacion INT NOT NULL,
        pppcaptura INT NOT NULL,
        FechaCambio DATE NOT NULL,
        tiempoCambio DATETIME NOT NULL DEFAULT GETDATE(),
        numCapturo INT NOT NULL,
        statusAutorizado BIT NOT NULL DEFAULT 0,
        numAutorizador INT NULL,
        tiempoAutorizado DATETIME NULL,
        idruta INT NULL,
        estatusDis BIT NOT NULL DEFAULT 0,
        pzasconfirmar INT NULL,
        pzaentregadas INT NULL,
        comentario VARCHAR(255) NULL,
        idProductoCambio INT NULL,
        CONSTRAINT FK_capturacambios_Producto FOREIGN KEY (sku) REFERENCES Producto(sku),
        CONSTRAINT FK_capturacambios_CambiosMotivos FOREIGN KEY (idcambiosmotivos) REFERENCES CambiosMotivos(idcambiosmotivos),
        CONSTRAINT FK_capturacambios_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion),
        CONSTRAINT FK_capturacambios_UsrCambios FOREIGN KEY (numCapturo) REFERENCES UsrCambios(NumEmpleado)
    );
    
    -- Índices para performance
    CREATE INDEX IX_capturacambios_fecha_operacion ON capturacambios(FechaCambio, idoperacion);
    CREATE INDEX IX_capturacambios_ruta_fecha ON capturacambios(pppcaptura, FechaCambio);
    CREATE INDEX IX_capturacambios_status ON capturacambios(statusAutorizado, FechaCambio);
    CREATE INDEX IX_capturacambios_cliente ON capturacambios(nud, idBodega);
    
    PRINT 'Tabla capturacambios creada con índices.';
END
GO

-- =====================================================
-- Datos Iniciales de Prueba
-- =====================================================

-- Insertar región de prueba
IF NOT EXISTS (SELECT * FROM region WHERE region = 'Centro')
BEGIN
    INSERT INTO region (region, estatus) VALUES ('Centro', 1);
    PRINT 'Región Centro insertada.';
END
GO

-- Insertar zona de prueba
IF NOT EXISTS (SELECT * FROM zona WHERE zona = 'CDMX')
BEGIN
    INSERT INTO zona (zona, idRegion, zonaHoraria) 
    VALUES ('CDMX', (SELECT idRegion FROM region WHERE region = 'Centro'), 'America/Mexico_City');
    PRINT 'Zona CDMX insertada.';
END
GO

-- Insertar depósito de prueba
IF NOT EXISTS (SELECT * FROM Deposito WHERE deposito = 'CEDIS CDMX')
BEGIN
    INSERT INTO Deposito (deposito, idzona, lun, mar, mie, jue, vie, estatus)
    VALUES ('CEDIS CDMX', (SELECT idzona FROM zona WHERE zona = 'CDMX'), 1, 1, 1, 1, 1, 1);
    PRINT 'Depósito CEDIS CDMX insertado.';
END
GO

-- Insertar operación de prueba
IF NOT EXISTS (SELECT * FROM Operaciones WHERE descripcion = 'CDMX Tradicional')
BEGIN
    INSERT INTO Operaciones (idDeposito, descripcion, tipoMercado, estatus)
    VALUES ((SELECT idDeposito FROM Deposito WHERE deposito = 'CEDIS CDMX'), 'CDMX Tradicional', 0, 1);
    PRINT 'Operación CDMX Tradicional insertada.';
END
GO

-- Insertar usuario administrador de prueba
-- Usuario: 99999, Contraseña: admin123 (MD5: 0192023a7bbd73250516f069df18b500)
IF NOT EXISTS (SELECT * FROM UsrCambios WHERE NumEmpleado = 99999)
BEGIN
    INSERT INTO UsrCambios (NumEmpleado, Nombre, Psw, nivel, idoperacion, estatus)
    VALUES (99999, 'Administrador Test', '0192023a7bbd73250516f069df18b500', 4, 
            (SELECT idoperacion FROM Operaciones WHERE descripcion = 'CDMX Tradicional'), 1);
    PRINT 'Usuario administrador de prueba insertado (99999 / admin123).';
END
GO

-- Insertar productos de prueba
IF NOT EXISTS (SELECT * FROM Producto WHERE sku = 'PEPSI600')
BEGIN
    INSERT INTO Producto (sku, descripcion, marca, categoria, presentacion, estatus)
    VALUES ('PEPSI600', 'Pepsi 600ml', 'Pepsi', 'Bebidas', '600ml', 1);
    PRINT 'Producto PEPSI600 insertado.';
END
GO

IF NOT EXISTS (SELECT * FROM Producto WHERE sku = 'DORITOS150')
BEGIN
    INSERT INTO Producto (sku, descripcion, marca, categoria, presentacion, estatus)
    VALUES ('DORITOS150', 'Doritos Nacho 150g', 'Doritos', 'Snacks', '150g', 1);
    PRINT 'Producto DORITOS150 insertado.';
END
GO

-- Insertar motivos de prueba
IF NOT EXISTS (SELECT * FROM CambiosMotivos WHERE descripcion = 'Producto Caducado')
BEGIN
    INSERT INTO CambiosMotivos (descripcion, agrupador, estatus, requiere_aut)
    VALUES ('Producto Caducado', 'Producto Caducado', 1, 1);
    PRINT 'Motivo "Producto Caducado" insertado.';
END
GO

IF NOT EXISTS (SELECT * FROM CambiosMotivos WHERE descripcion = 'Producto Dañado')
BEGIN
    INSERT INTO CambiosMotivos (descripcion, agrupador, estatus, requiere_aut)
    VALUES ('Producto Dañado', 'Producto Dañado', 1, 1);
    PRINT 'Motivo "Producto Dañado" insertado.';
END
GO

-- Insertar cliente de prueba
IF NOT EXISTS (SELECT * FROM Cliente WHERE CLAVE_CLIENTE = 10001)
BEGIN
    INSERT INTO Cliente (CLAVE_CLIENTE, CLAVE_BODEGA, NOMBRE_CLIENTE, TIPO_MERCADO, estatus)
    VALUES (10001, 1, 'Tienda de Prueba', 0, 1);
    PRINT 'Cliente de prueba insertado (NUD: 10001).';
END
GO

PRINT '=====================================================';
PRINT 'Script 03: Tablas creadas y datos de prueba insertados exitosamente.';
PRINT '=====================================================';
PRINT 'Usuario de prueba:';
PRINT '  NumEmpleado: 99999';
PRINT '  Contraseña: admin123';
PRINT '  Nivel: 4 (Administrador)';
PRINT '=====================================================';
GO

