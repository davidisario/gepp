-- =====================================================
-- PCM API - Nuevas Tablas para la API
-- Script 04: Crear Tablas de la API (Tickets, etc.)
-- =====================================================

USE PCMFULL;
GO

PRINT '=====================================================';
PRINT 'Creando tablas de la API de Cambio de Mercado...';
PRINT '=====================================================';

-- Tabla: Tickets
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Tickets')
BEGIN
    CREATE TABLE Tickets (
        folio VARCHAR(10) PRIMARY KEY,
        ID_Bodega INT NOT NULL,
        NUD VARCHAR(20) NOT NULL,
        idoperacion INT NOT NULL,
        estado VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
        created_by INT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME NOT NULL DEFAULT GETDATE(),
        version INT NOT NULL DEFAULT 1,
        fecha_cambio_estimado DATETIME NULL,
        sent_at DATETIME NULL,
        sent_by INT NULL,
        cancelled_at DATETIME NULL,
        cancelled_by INT NULL,
        cancellation_reason VARCHAR(255) NULL,
        CONSTRAINT FK_Tickets_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion),
        INDEX IX_Tickets_Bodega_NUD (ID_Bodega, NUD),
        INDEX IX_Tickets_Estado (estado),
        INDEX IX_Tickets_CreatedAt (created_at)
    );
    PRINT 'Tabla Tickets creada.';
END
ELSE
BEGIN
    PRINT 'Tabla Tickets ya existe.';
END
GO

-- Tabla: TicketItems
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TicketItems')
BEGIN
    CREATE TABLE TicketItems (
        id_item INT IDENTITY(1,1) PRIMARY KEY,
        folio VARCHAR(10) NOT NULL,
        clave_producto VARCHAR(20) NOT NULL,
        id_motivo INT NOT NULL,
        piezas INT NOT NULL,
        justificacion VARCHAR(255) NULL,
        created_at DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_TicketItems_Tickets FOREIGN KEY (folio) REFERENCES Tickets(folio) ON DELETE CASCADE,
        CONSTRAINT FK_TicketItems_Producto FOREIGN KEY (clave_producto) REFERENCES Producto(sku),
        CONSTRAINT FK_TicketItems_Motivo FOREIGN KEY (id_motivo) REFERENCES CambiosMotivos(idcambiosmotivos),
        INDEX IX_TicketItems_Folio (folio),
        INDEX IX_TicketItems_Producto (clave_producto)
    );
    PRINT 'Tabla TicketItems creada.';
END
ELSE
BEGIN
    PRINT 'Tabla TicketItems ya existe.';
END
GO

-- Tabla: IdempotencyKeys
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'IdempotencyKeys')
BEGIN
    CREATE TABLE IdempotencyKeys (
        id INT IDENTITY(1,1) PRIMARY KEY,
        idempotency_key UNIQUEIDENTIFIER UNIQUE NOT NULL,
        folio VARCHAR(10) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT GETDATE(),
        expires_at DATETIME NOT NULL,
        CONSTRAINT FK_IdempotencyKeys_Tickets FOREIGN KEY (folio) REFERENCES Tickets(folio) ON DELETE CASCADE,
        INDEX IX_IdempotencyKeys_Key (idempotency_key),
        INDEX IX_IdempotencyKeys_ExpiresAt (expires_at)
    );
    PRINT 'Tabla IdempotencyKeys creada.';
END
ELSE
BEGIN
    PRINT 'Tabla IdempotencyKeys ya existe.';
END
GO

-- Tabla: ApiKeys (para futura gestión de API Keys en DB)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ApiKeys')
BEGIN
    CREATE TABLE ApiKeys (
        id INT IDENTITY(1,1) PRIMARY KEY,
        [key] UNIQUEIDENTIFIER UNIQUE NOT NULL,
        name VARCHAR(100) NOT NULL,
        description VARCHAR(255) NULL,
        permissions NVARCHAR(500) NOT NULL, -- JSON array
        idoperacion INT NULL,
        nivel INT NULL,
        isActive BIT NOT NULL DEFAULT 1,
        createdAt DATETIME NOT NULL DEFAULT GETDATE(),
        updatedAt DATETIME NOT NULL DEFAULT GETDATE(),
        lastUsedAt DATETIME NULL,
        expiresAt DATETIME NULL,
        CONSTRAINT FK_ApiKeys_Operaciones FOREIGN KEY (idoperacion) REFERENCES Operaciones(idoperacion),
        INDEX IX_ApiKeys_Key ([key]),
        INDEX IX_ApiKeys_Active (isActive)
    );
    PRINT 'Tabla ApiKeys creada.';
END
ELSE
BEGIN
    PRINT 'Tabla ApiKeys ya existe.';
END
GO

PRINT '=====================================================';
PRINT 'Tablas de la API creadas exitosamente.';
PRINT '=====================================================';
GO

