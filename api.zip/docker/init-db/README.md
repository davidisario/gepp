# Inicialización de Base de Datos PCM

## Descripción

Este directorio contiene scripts para inicializar las bases de datos del sistema PCM.

## Estructura

```
init-db/
├── README.md              (este archivo)
├── 01-create-databases.sql   (crear bases de datos PCMFULL y adc)
├── 02-create-users.sql       (crear usuarios y permisos)
└── 03-create-tables.sql      (crear tablas y estructura)
```

## Pasos de Inicialización

### 1. Levantar el contenedor de SQL Server

```bash
docker-compose up -d sqlserver
```

### 2. Esperar a que SQL Server esté listo

```bash
docker-compose logs -f sqlserver
# Esperar hasta ver: "SQL Server is now ready for client connections"
```

### 3. Ejecutar los scripts de inicialización

```bash
# Opción A: Ejecutar todos los scripts automáticamente
docker exec -it pcm_sqlserver /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P 'YourStrong!Passw0rd' \
  -i /docker-entrypoint-initdb.d/01-create-databases.sql

docker exec -it pcm_sqlserver /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P 'YourStrong!Passw0rd' \
  -i /docker-entrypoint-initdb.d/02-create-users.sql

docker exec -it pcm_sqlserver /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P 'YourStrong!Passw0rd' \
  -i /docker-entrypoint-initdb.d/03-create-tables.sql
```

```bash
# Opción B: Conectarse manualmente
docker exec -it pcm_sqlserver /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P 'YourStrong!Passw0rd'
```

### 4. Verificar la creación

```sql
-- Verificar bases de datos
SELECT name FROM sys.databases WHERE name IN ('PCMFULL', 'adc');
GO

-- Verificar tablas en PCMFULL
USE PCMFULL;
GO
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES;
GO
```

## Migración desde Azure

Si tienes acceso a la base de datos de Azure, puedes exportar e importar:

```bash
# 1. Exportar schema desde Azure (requiere acceso)
sqlcmd -S 40.76.88.88,21433 -U usrPCM -P 'password' -d PCMFULL \
  -Q "SELECT * FROM INFORMATION_SCHEMA.TABLES" -o schema.txt

# 2. Generar scripts de CREATE TABLE
# (Usar herramientas como SQL Server Management Studio o Azure Data Studio)

# 3. Importar a contenedor local
docker exec -i pcm_sqlserver /opt/mssql-tools/bin/sqlcmd \
  -S localhost -U sa -P 'YourStrong!Passw0rd' < schema.sql
```

## Datos de Prueba

Para desarrollo local, considera crear datos de prueba mínimos:

- Al menos 1 usuario administrador
- Al menos 1 operación/depósito
- Al menos 1 cliente de prueba
- Catálogo básico de productos
- Motivos de cambio básicos

Ver archivo `04-insert-test-data.sql` (crear si es necesario).

## Troubleshooting

### Error: Login failed for user 'usrPCM'

Verifica que el usuario fue creado correctamente:

```sql
USE master;
GO
SELECT name FROM sys.sql_logins WHERE name = 'usrPCM';
GO
```

### Error: Cannot open database "PCMFULL"

Verifica que la base de datos existe:

```sql
SELECT name FROM sys.databases;
GO
```

### Reiniciar desde cero

```bash
# Detener y eliminar volúmenes
docker-compose down -v

# Volver a levantar
docker-compose up -d

# Ejecutar scripts de inicialización nuevamente
```

## Notas de Seguridad

- Las contraseñas en estos scripts son para **desarrollo local únicamente**
- **NUNCA** usar estas contraseñas en producción
- En producción, usar Azure Key Vault o similar para gestionar secretos
