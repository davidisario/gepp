# 🔍 Análisis de Factibilidad: pppcaptura Automático

## 📋 Propuesta

**Contrato Actual:**

```json
{
  "ID_Bodega": 1,
  "NUD": "10001",
  "pppcaptura": 123,  // ← Usuario envía esto
  "items": [...]
}
```

**Contrato Propuesto:**

```json
{
  "ID_Bodega": 1,
  "NUD": "10001",
  // pppcaptura se obtiene automáticamente de NUD + ID_Bodega
  "items": [...]
}
```

---

## ❌ CONCLUSIÓN: **NO ES FACTIBLE**

### Razones Principales

1. ⚠️ **Ambigüedad**: Un NUD puede tener hasta 3 rutas diferentes
2. ⚠️ **Contexto de negocio**: `pppcaptura` define QUIÉN captura, no solo DÓNDE está el cliente
3. ⚠️ **Agrupación**: Múltiples NUDs en un mismo request deben compartir la misma ruta
4. ⚠️ **Folio virtual**: Se necesita `pppcaptura` para generar el folio y validar grupos activos
5. ⚠️ **Validación temprana**: Reglas de negocio requieren conocer la ruta ANTES de procesar items

---

## 🔍 Análisis Detallado

### Problema 1: Ambigüedad - Un NUD Puede Tener Múltiples Rutas

#### Estructura de Datos en BD

```sql
SELECT
  CLAVE_CLIENTE as NUD,
  CLAVE_RUTA_PREVENTA,    -- Ruta tipo 0
  CLAVE_RUTA_TELEVENTA,   -- Ruta tipo 1
  CLAVE_RUTA_DESARROLLO   -- Ruta tipo 2
FROM Cliente
WHERE CLAVE_CLIENTE = 10001
  AND CLAVE_BODEGA = 1
```

#### Resultado Posible

| NUD   | PREVENTA | TELEVENTA | DESARROLLO |
| ----- | -------- | --------- | ---------- |
| 10001 | 123      | 456       | 789        |

**Pregunta:** ¿Cuál ruta usar? **No hay forma de determinarlo automáticamente.**

#### Ejemplo Real del Sistema Legacy

```php
// De: pcm/mostrarNombreCliente.php
// El sistema NECESITA saber el ppp (pppcaptura) para determinar tipoPPP

$qryTipoRuta = "SELECT tipoPPP FROM dbo.Rutascambios
                WHERE idoperacion = $idop AND ruta = $ppp";  // ← Requiere $ppp

if($rowTipoRuta['tipoPPP'] == 0){
    $condicion = " AND c.CLAVE_RUTA_PREVENTA = ".$ppp;
} else if ($rowTipoRuta['tipoPPP'] == 1) {
    $condicion = " AND c.CLAVE_RUTA_TELEVENTA = ".$ppp;
} else if ($rowTipoRuta['tipoPPP'] == 2) {
    $condicion = " AND c.CLAVE_RUTA_DESARROLLO = ".$ppp;
}
```

**El flujo es:** `pppcaptura → tipoPPP → campo_cliente_validar`

**NO:** `NUD → pppcaptura` (porque hay múltiples opciones)

---

### Problema 2: pppcaptura Define QUIÉN Captura

#### Concepto Clave

`pppcaptura` NO es un atributo del cliente, sino **del promotor/ruta que está realizando la captura**.

```
┌─────────────────────────────────────────────┐
│  ¿Quién está capturando este cambio?       │
│  Respuesta: La RUTA 123 (pppcaptura)       │
└─────────────────────────────────────────────┘
                    ↓
         Puede atender a múltiples NUDs:
                    ↓
            NUD 10001, 10002, 10003...
```

#### Flujo de Negocio Real

1. **Promotor de ruta 123** inicia su día
2. Visita varios clientes (NUDs) en su ruta
3. Captura cambios para múltiples clientes
4. **TODOS los cambios del día** se agrupan por `pppcaptura-fecha`

**Lógica:** "El promotor de la ruta 123 capturó cambios para 5 clientes el día de hoy"

**NO:** "El cliente 10001 tuvo un cambio, ¿de qué ruta vino?"

---

### Problema 3: Un Request Puede Tener Múltiples NUDs

#### Contrato Actual Permite

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "items": [
    {
      "NUD": "10001", // Cliente A de la ruta 123
      "clave_producto": 100,
      "piezas": 10,
      "id_motivo": 1
    },
    {
      "NUD": "10002", // Cliente B de la ruta 123
      "clave_producto": 200,
      "piezas": 5,
      "id_motivo": 1
    },
    {
      "NUD": "10003", // Cliente C de la ruta 123
      "clave_producto": 300,
      "piezas": 8,
      "id_motivo": 2
    }
  ]
}
```

#### ¿Qué pasa si derivamos pppcaptura de NUD?

**Escenario Problemático:**

```
NUD 10001:
  - CLAVE_RUTA_PREVENTA = 123
  - CLAVE_RUTA_TELEVENTA = 456

NUD 10002:
  - CLAVE_RUTA_PREVENTA = 123
  - CLAVE_RUTA_TELEVENTA = NULL

NUD 10003:
  - CLAVE_RUTA_PREVENTA = 789  // ← ¡Diferente ruta!
  - CLAVE_RUTA_TELEVENTA = 456
```

**Preguntas sin respuesta:**

1. ¿Cuál ruta usar para NUD 10001? (¿123 o 456?)
2. ¿Usar la misma ruta para todos o diferente por NUD?
3. Si NUD 10003 no está en ruta 123, ¿rechazar solo ese item o todo el request?

**Resultado:** **Ambigüedad total** y lógica de negocio inconsistente.

---

### Problema 4: Folio Virtual y Grupo Activo

#### Flujo Actual (Correcto)

```
1. Request llega con pppcaptura=123
        ↓
2. Validar: ¿Existe grupo activo para ruta 123 hoy?
   SQL: SELECT * FROM CapturaCambios
        WHERE pppcaptura = 123
          AND FechaCambio = '2025-11-04'
          AND statusAutorizado = 0
        ↓
3a. Si existe → 409 Conflict (solo un grupo activo por ruta/día)
3b. Si NO existe → Continuar
        ↓
4. Crear grupo con pppcaptura=123
        ↓
5. Folio virtual = "123-2025-11-04"
```

#### Flujo Propuesto (Problemático)

```
1. Request llega con NUD=10001
        ↓
2. Consultar rutas del NUD:
   - CLAVE_RUTA_PREVENTA = 123
   - CLAVE_RUTA_TELEVENTA = 456
   - CLAVE_RUTA_DESARROLLO = NULL
        ↓
3. ??? ¿Cuál usar? No hay criterio
        ↓
4. Supongamos que elegimos 123...
        ↓
5. ¿Validar grupo activo para 123 o para 456?
        ↓
6. Si el usuario QUERÍA usar ruta 456, estaríamos validando la ruta incorrecta
```

**Resultado:** **No se puede validar correctamente** sin conocer la ruta de antemano.

---

### Problema 5: Validación Temprana en Flujo

#### Reglas de Negocio que Requieren pppcaptura

| #   | Validación                   | ¿Requiere pppcaptura? | Cuándo                     |
| --- | ---------------------------- | --------------------- | -------------------------- |
| 1   | Ruta existe y activa         | ✅ SÍ                 | Antes de procesar items    |
| 2   | Ruta pertenece a operación   | ✅ SÍ                 | Antes de procesar items    |
| 3   | No hay grupo activo          | ✅ SÍ                 | Antes de procesar items    |
| 4   | Tipo de ruta (fijo/dinámico) | ✅ SÍ                 | Para calcular fechaEntrega |
| 5   | Cliente pertenece a ruta     | ✅ SÍ                 | Por cada item              |
| 6   | Obtener tipoPPP              | ✅ SÍ                 | Para validar NUD           |

**Flujo de Validación Actual:**

```typescript
async createCambios(dto: CreateCambioDTO, apiKeyData: ApiKeyData) {
  // 1. Validar operación
  const operacion = await this.validateOperacion(dto.ID_Bodega);

  // 2. Validar ruta (REQUIERE pppcaptura)
  const ruta = await this.validateRuta(dto.pppcaptura, dto.ID_Bodega);

  // 3. Validar grupo único (REQUIERE pppcaptura)
  await this.validateNoActiveGroup(dto.pppcaptura, fechaCambio, dto.ID_Bodega);

  // 4. Validar catálogo
  const catalogo = await this.validateCatalog(dto.items, dto.ID_Bodega);

  // 5. Por cada item, validar que NUD pertenece a ruta (REQUIERE tipoPPP de la ruta)
  for (const item of dto.items) {
    await this.validateNudBelongsToRuta(item.NUD, dto.pppcaptura, ruta.tipoPPP);
  }

  // 6. Calcular fechaEntrega (REQUIERE tipo de ruta)
  const fechaEntrega = await this.calcularFechaEntrega(ruta, fechaCambio);

  // 7. Crear registros...
}
```

**Si eliminamos pppcaptura del request:**

```typescript
async createCambios(dto: CreateCambioDTO, apiKeyData: ApiKeyData) {
  // 1. Validar operación
  const operacion = await this.validateOperacion(dto.ID_Bodega);

  // 2. ??? ¿Cómo validar ruta sin pppcaptura?

  // 3. ??? ¿Cómo validar grupo único sin pppcaptura?

  // 4. Validar catálogo
  const catalogo = await this.validateCatalog(dto.items, dto.ID_Bodega);

  // 5. Por cada item...
  for (const item of dto.items) {
    // ??? ¿De dónde sacamos pppcaptura para validar?
    // Opción A: Consultar del primer NUD (¿cuál ruta si tiene 3?)
    // Opción B: Consultar por cada NUD (podrían ser diferentes)
  }
}
```

**Resultado:** **No se puede mantener la lógica de validación actual**.

---

## 🔄 Escenarios de Uso Real

### Escenario 1: Promotor con Múltiples Tipos de Ruta

**Contexto:**

- Cliente 10001 puede recibir de 3 tipos de rutas
- Hoy, el promotor de **televenta** (ruta 456) visita al cliente

**Con pppcaptura explícito:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 456,  // ← Explícito: es televenta
  "items": [
    { "NUD": "10001", ... }
  ]
}
```

✅ Sistema valida:

- Ruta 456 es televenta (tipoPPP=1)
- Cliente tiene CLAVE_RUTA_TELEVENTA = 456
- ✅ Válido

**Sin pppcaptura (propuesta):**

```json
{
  "ID_Bodega": 1,
  "items": [
    { "NUD": "10001", ... }
  ]
}
```

Sistema consulta:

```sql
SELECT CLAVE_RUTA_PREVENTA, CLAVE_RUTA_TELEVENTA, CLAVE_RUTA_DESARROLLO
FROM Cliente WHERE CLAVE_CLIENTE = 10001

Resultado:
  PREVENTA: 123
  TELEVENTA: 456
  DESARROLLO: 789
```

❌ **¿Cuál elegir?** No hay forma de saberlo.

---

### Escenario 2: Múltiples Clientes en un Request

**Contexto:**

- Promotor de ruta 123 visita 3 clientes
- Todos están en su ruta de preventa

**Con pppcaptura explícito:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,  // ← Todos los NUDs deben estar en esta ruta
  "items": [
    { "NUD": "10001", ... },
    { "NUD": "10002", ... },
    { "NUD": "10003", ... }
  ]
}
```

✅ Sistema valida:

- Ruta 123 es preventa
- Cliente 10001: CLAVE_RUTA_PREVENTA = 123 ✅
- Cliente 10002: CLAVE_RUTA_PREVENTA = 123 ✅
- Cliente 10003: CLAVE_RUTA_PREVENTA = 123 ✅
- Todos pertenecen a la misma ruta ✅

**Sin pppcaptura (propuesta):**

```json
{
  "ID_Bodega": 1,
  "items": [
    { "NUD": "10001", ... },
    { "NUD": "10002", ... },
    { "NUD": "10003", ... }
  ]
}
```

Sistema consulta cada NUD:

```
10001: PREVENTA=123, TELEVENTA=456, DESARROLLO=NULL
10002: PREVENTA=123, TELEVENTA=NULL, DESARROLLO=789
10003: PREVENTA=123, TELEVENTA=456, DESARROLLO=789
```

**Preguntas sin respuesta:**

1. ¿Usar PREVENTA para todos porque es la única ruta compartida?
2. ¿Qué pasa si 10002 y 10003 no comparten ninguna ruta?
3. ¿Rechazar todo el request o solo los items incompatibles?

❌ **Lógica demasiado compleja** y propensa a errores.

---

### Escenario 3: Validación de Grupo Activo

**Contexto:**

- Cliente 10001 ya tiene un cambio pendiente capturado por ruta 456 (televenta)
- Ahora queremos capturar para la misma cliente pero desde ruta 123 (preventa)

**Con pppcaptura explícito:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,  // ← Ruta diferente a la que tiene grupo activo
  "items": [
    { "NUD": "10001", ... }
  ]
}
```

Sistema valida:

```sql
SELECT * FROM CapturaCambios
WHERE pppcaptura = 123  -- Buscando grupo de ruta 123
  AND FechaCambio = '2025-11-04'
  AND statusAutorizado = 0
```

✅ **No hay grupo activo para ruta 123** → Puede crear nuevo grupo

Resultado:

- Grupo activo de ruta 456 (televenta) sigue pendiente
- Nuevo grupo de ruta 123 (preventa) se crea correctamente
- Ambos pueden coexistir porque son rutas diferentes

**Sin pppcaptura (propuesta):**

```json
{
  "ID_Bodega": 1,
  "items": [
    { "NUD": "10001", ... }
  ]
}
```

Sistema consulta NUD:

```
10001: PREVENTA=123, TELEVENTA=456
```

**¿Qué hacer?**

- Opción A: Buscar grupo activo para ambas rutas (123 y 456)
  - Encuentra grupo de 456 → ❌ Error 409
  - Pero el usuario quería usar ruta 123 (que no tiene grupo activo)
- Opción B: Elegir automáticamente ruta 123
  - ¿Por qué 123 y no 456? No hay criterio
- Opción C: Usar la ruta que NO tenga grupo activo
  - Complejo y no refleja la intención del usuario

❌ **No se puede validar correctamente** sin saber qué ruta usar.

---

## 📊 Comparación de Enfoques

### Enfoque Actual (Con pppcaptura explícito)

| Aspecto                   | Resultado                                         |
| ------------------------- | ------------------------------------------------- |
| **Ambigüedad**            | ✅ Sin ambigüedad - Usuario especifica la ruta    |
| **Validación**            | ✅ Directa - Ruta → tipoPPP → validar NUD         |
| **Grupo activo**          | ✅ Claro - Validar por ruta específica            |
| **Múltiples NUDs**        | ✅ Coherente - Todos deben estar en la misma ruta |
| **Intención del usuario** | ✅ Explícita - Usuario dice qué ruta usar         |
| **Complejidad**           | ✅ Baja - Flujo lineal                            |
| **Performance**           | ✅ Óptimo - Una consulta por validación           |

### Enfoque Propuesto (Sin pppcaptura)

| Aspecto                   | Resultado                                        |
| ------------------------- | ------------------------------------------------ |
| **Ambigüedad**            | ❌ Alta - Un NUD puede tener 3 rutas             |
| **Validación**            | ❌ Compleja - ¿Cuál tipoPPP usar?                |
| **Grupo activo**          | ❌ Ambiguo - ¿Validar todas las rutas?           |
| **Múltiples NUDs**        | ❌ Problemático - Podrían tener rutas diferentes |
| **Intención del usuario** | ❌ Desconocida - Sistema debe adivinar           |
| **Complejidad**           | ❌ Alta - Lógica de selección compleja           |
| **Performance**           | ❌ Peor - Múltiples consultas por NUD            |

---

## 🎯 Alternativas Consideradas

### Alternativa 1: Seleccionar Primera Ruta No Nula

**Lógica:**

```typescript
const rutas = [
  cliente.CLAVE_RUTA_PREVENTA,
  cliente.CLAVE_RUTA_TELEVENTA,
  cliente.CLAVE_RUTA_DESARROLLO,
].filter((r) => r !== null);

const pppcaptura = rutas[0]; // Tomar la primera
```

**Problemas:**

- ❌ Arbitrario - No refleja intención del usuario
- ❌ Inconsistente - Depende del orden de campos en BD
- ❌ Frágil - Cambios en BD rompen lógica

---

### Alternativa 2: Usar Ruta con Grupo Activo

**Lógica:**

```typescript
// Si existe grupo activo, usar esa ruta
const grupoActivo = await buscarGrupoActivo(NUD, fechaCambio);
if (grupoActivo) {
  pppcaptura = grupoActivo.pppcaptura;
} else {
  // ??? ¿Cuál ruta usar para nuevo grupo?
}
```

**Problemas:**

- ❌ Limita flexibilidad - Solo puede extender grupos existentes
- ❌ No resuelve caso de nuevo grupo
- ❌ Usuario pierde control

---

### Alternativa 3: Agregar "Tipo de Ruta" al Request

**Contrato:**

```json
{
  "ID_Bodega": 1,
  "NUD": "10001",
  "tipoRuta": 0,  // 0=preventa, 1=televenta, 2=desarrollo
  "items": [...]
}
```

**Lógica:**

```typescript
const pppcaptura =
  tipoRuta === 0
    ? cliente.CLAVE_RUTA_PREVENTA
    : tipoRuta === 1
      ? cliente.CLAVE_RUTA_TELEVENTA
      : cliente.CLAVE_RUTA_DESARROLLO;
```

**Problemas:**

- ⚠️ Complejo - Usuario debe conocer tipos de ruta
- ⚠️ Indirecto - Más fácil enviar pppcaptura directamente
- ⚠️ Sigue sin resolver múltiples NUDs en un request

**Comparado con el actual:**

- Enviar `pppcaptura: 123` es **más simple y directo**
- Enviar `tipoRuta: 0` es **más complejo e indirecto**

---

### Alternativa 4: Derivar de API Key (Mejor)

**Concepto:**

```typescript
// API Key tiene userId (numCapturo)
// ¿También podría tener rutaId (pppcaptura)?

interface ApiKeyData {
  key: string;
  name: string;
  userId: number; // numCapturo - Ya implementado ✅
  rutaId?: number; // pppcaptura - Nueva propiedad
  idoperacion?: number;
}
```

**Configuración:**

```typescript
keys: [
  {
    key: 'a1b2c3d4...',
    name: 'Promotor Ruta 123',
    userId: 99999,
    rutaId: 123, // ← Ruta fija para esta API Key
    idoperacion: 1,
  },
];
```

**Ventajas:**

- ✅ Elimina ambigüedad - Cada key tiene una ruta
- ✅ Seguro - Usuario no puede falsificar ruta
- ✅ Simple - Se obtiene automáticamente

**Desventajas:**

- ⚠️ Inflexible - Una API Key solo sirve para una ruta
- ⚠️ Muchas keys - Necesitas una key por cada ruta
- ⚠️ Gestión compleja - Crear/mantener keys por ruta

**Evaluación:**

- **Factible:** ✅ SÍ
- **Recomendado:** ⚠️ Depende del caso de uso
  - **SÍ** si cada promotor usa siempre la misma ruta
  - **NO** si un promotor puede capturar para múltiples rutas

---

## 💡 Recomendación Final

### ✅ **MANTENER el Contrato Actual**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123, // ← MANTENER EXPLÍCITO
  "items": [
    {
      "NUD": "10001",
      "clave_producto": 123456,
      "id_motivo": 1,
      "piezas": 25,
      "justificacion": "..."
    }
  ]
}
```

### Razones

1. ✅ **Sin ambigüedad** - Usuario especifica claramente qué ruta usa
2. ✅ **Validaciones simples** - Flujo lineal y directo
3. ✅ **Flexibilidad** - Un cliente puede tener cambios de múltiples rutas
4. ✅ **Performance** - Consultas directas sin lógica compleja
5. ✅ **Compatible** - Con el sistema legacy PHP
6. ✅ **Intención clara** - El usuario sabe qué ruta está usando
7. ✅ **Múltiples NUDs** - Todos en la misma ruta de forma coherente

---

## 🚀 Mejora Propuesta: Validación Mejorada

En lugar de eliminar `pppcaptura`, **mejorar la validación** para ayudar al usuario:

### Endpoint Helper: GET /captura_cambios/rutas-disponibles

```typescript
GET /api/v2/captura_cambios/rutas-disponibles?NUD=10001&idBodega=1

Response:
{
  "result": {
    "data": {
      "nud": "10001",
      "nombreCliente": "Tienda Center",
      "rutas_disponibles": [
        {
          "pppcaptura": 123,
          "tipo": "PREVENTA",
          "tipoPPP": 0,
          "nombreRuta": "Ruta Norte MTY",
          "tiene_grupo_activo": false
        },
        {
          "pppcaptura": 456,
          "tipo": "TELEVENTA",
          "tipoPPP": 1,
          "nombreRuta": "Televenta Centro",
          "tiene_grupo_activo": true  // ← Ya tiene grupo pendiente
        },
        {
          "pppcaptura": 789,
          "tipo": "DESARROLLO",
          "tipoPPP": 2,
          "nombreRuta": "Desarrollo Zona Norte",
          "tiene_grupo_activo": false
        }
      ]
    },
    "successful": true
  }
}
```

**Beneficios:**

- ✅ Usuario ve qué rutas puede usar
- ✅ Ve cuáles tienen grupos activos
- ✅ Puede tomar decisión informada
- ✅ **Mantiene `pppcaptura` en el request de creación**

---

## 📋 Checklist de Decisión

| Criterio              | Con pppcaptura | Sin pppcaptura |
| --------------------- | -------------- | -------------- |
| Sin ambigüedad        | ✅             | ❌             |
| Validación simple     | ✅             | ❌             |
| Performance óptimo    | ✅             | ❌             |
| Compatible con legacy | ✅             | ⚠️             |
| Flexible              | ✅             | ❌             |
| Intención clara       | ✅             | ❌             |
| Fácil de mantener     | ✅             | ❌             |
| Múltiples NUDs        | ✅             | ❌             |
| **TOTAL**             | **8/8**        | **0/8**        |

---

## 🎯 Conclusión Final

**NO es factible ni recomendable** eliminar `pppcaptura` del request porque:

1. ❌ Introduce ambigüedad cuando un NUD tiene múltiples rutas
2. ❌ Rompe la lógica de validación actual
3. ❌ Complica el manejo de múltiples NUDs en un request
4. ❌ Impide validar grupos activos correctamente
5. ❌ Aumenta la complejidad y reduce el performance
6. ❌ El usuario pierde control sobre qué ruta usar

**Recomendación:**

- ✅ **MANTENER** `pppcaptura` como campo requerido en el request
- ✅ **AGREGAR** endpoint helper para consultar rutas disponibles por NUD
- ✅ **MEJORAR** mensajes de error cuando NUD no pertenece a la ruta

---

**Fecha de Análisis:** 2025-11-04  
**Analista:** Equipo Técnico GEPP/Draweb  
**Conclusión:** **Mantener diseño actual**
