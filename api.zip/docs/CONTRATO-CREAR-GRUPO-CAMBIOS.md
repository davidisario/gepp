# 📋 Contrato API - Crear Grupo de Cambios

## 🎯 Endpoint

```
POST /api/v2/captura_cambios
```

**Propósito:** Capturar un nuevo grupo de cambios de mercado para uno o más clientes atendidos por una ruta específica.

---

## 📦 Estructura del Contrato (Request Body)

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "FechaCambio": "2025-11-04",
  "fechaEntrega": "2025-11-06",
  "items": [
    {
      "NUD": "10001",
      "clave_producto": 123456,
      "id_motivo": 1,
      "piezas": 25,
      "justificacion": "Producto llegó dañado en transporte"
    }
  ]
}
```

**⚠️ IMPORTANTES:**

- El campo `numCapturo` (número de empleado que captura) **NO** se envía en el request. Se obtiene automáticamente de la API Key.
- El campo `fechaEntrega` está en el **nivel raíz** del grupo - TODOS los items comparten la misma fecha de entrega.
- Cada item debe especificar su **`NUD`** (cliente).
- El campo `FechaCambio` es opcional y por defecto usa la fecha actual (HOY).

---

## 🔍 Descripción Detallada de Campos

### Nivel Raíz (Grupo)

#### 1. `ID_Bodega` (number) - REQUERIDO ✅

**Descripción:** Identificador de la operación/bodega/CEDIS donde se realiza la captura.

**Para qué sirve:**

- Identifica el centro de distribución (CEDIS) o bodega donde se originan los cambios
- Se usa para validar que la ruta pertenezca a esa operación
- Define el contexto de productos disponibles en el catálogo
- Se mapea a `idoperacion` en la tabla `CapturaCambios`
- Se mapea a `idBodega` calculado desde `depositos.CLAVE_BODEGA`

**Validaciones:**

- ✅ **Tipo:** Número entero positivo
- ✅ **Obligatorio:** Sí
- ✅ **Debe existir:** En tabla `Operaciones` con `activo = 1`
- ✅ **Debe tener depósito:** Con `activo = 1` en tabla `Depositos`

**Ejemplos:**

```json
"ID_Bodega": 1     // ✅ CEDIS Monterrey
"ID_Bodega": 2     // ✅ CEDIS Guadalajara
"ID_Bodega": 0     // ❌ Inválido
"ID_Bodega": "1"   // ❌ Debe ser número
```

**Errores Comunes:**

```json
{
  "statusCode": 404,
  "message": "Operación no encontrada o inactiva",
  "error": "Not Found"
}
```

---

#### 2. `pppcaptura` (number) - REQUERIDO ✅

**Descripción:** Número de ruta del promotor que está capturando los cambios.

**Para qué sirve:**

- Identifica qué ruta/promotor está realizando la captura
- Se usa para validar que la ruta exista y esté activa
- Define qué clientes (NUDs) pueden ser incluidos en el grupo
- Se usa para generar el **folio virtual** del grupo: `{pppcaptura}-{fecha}`
- Agrupa todos los cambios del día por ruta

**Validaciones:**

- ✅ **Tipo:** Número entero positivo
- ✅ **Obligatorio:** Sí
- ✅ **Debe existir:** En tabla `Rutascambios` con `activo = 1`
- ✅ **Debe pertenecer:** A la operación especificada en `ID_Bodega`
- ✅ **Solo un grupo activo:** No puede haber otro grupo pendiente para la misma ruta y fecha

**Relación con NUD:**

```
pppcaptura 123 → Ruta de Preventa
  ↓
Debe validarse según tipoPPP:
  - tipoPPP = 0 → Cliente.CLAVE_RUTA_PREVENTA = 123
  - tipoPPP = 1 → Cliente.CLAVE_RUTA_TELEVENTA = 123
  - tipoPPP = 2 → Cliente.CLAVE_RUTA_DESARROLLO = 123
```

**Ejemplos:**

```json
"pppcaptura": 123    // ✅ Ruta 123
"pppcaptura": 0      // ❌ Inválido
"pppcaptura": "123"  // ❌ Debe ser número
```

**Errores Comunes:**

```json
// Ruta no encontrada o inactiva
{
  "statusCode": 404,
  "message": "Ruta no encontrada o inactiva",
  "error": "Not Found"
}

// Ya existe un grupo activo
{
  "statusCode": 409,
  "message": "Ya existe un grupo activo para esta ruta y fecha",
  "error": "Conflict"
}
```

---

#### 3.5. `fechaEntrega` (string) - REQUERIDO ✅

**Descripción:** Fecha programada de entrega de TODOS los items del grupo al cliente (formato ISO 8601: YYYY-MM-DD).

**Para qué sirve:**

- Define la fecha en que se entregarán **todos los cambios del grupo**
- Todos los items (productos/clientes) comparten la misma fecha de entrega
- Se almacena en la BD para programación de despachos y entregas
- El usuario/sistema que hace el request determina esta fecha
- Debe ser una fecha válida y preferiblemente un día hábil

**Validaciones:**

- ✅ **Tipo:** String en formato ISO 8601 (`YYYY-MM-DD`)
- ✅ **Obligatorio:** Sí
- ✅ **Formato válido:** Debe ser una fecha válida
- ⚠️ **Recomendación:** Debería ser un día hábil del depósito
- ⚠️ **Aplica a todos los items:** Un solo grupo = una sola fecha de entrega

**Ejemplos:**

```json
// ✅ Casos válidos
"fechaEntrega": "2025-11-06"      // OK - Fecha válida
"fechaEntrega": "2025-12-25"      // OK - Aunque sea festivo (no se valida)

// ❌ Casos inválidos
"fechaEntrega": "2025-13-01"      // ❌ Mes inválido
"fechaEntrega": "06/11/2025"      // ❌ Formato incorrecto
"fechaEntrega": "tomorrow"        // ❌ No es fecha válida
```

**Errores Comunes:**

```json
{
  "statusCode": 400,
  "message": "Validation failed",
  "error": "Bad Request",
  "details": [
    {
      "field": "fechaEntrega",
      "error": "fechaEntrega must be a valid ISO 8601 date string"
    }
  ]
}
```

**Consideraciones:**

- El sistema **NO calcula** automáticamente esta fecha
- El cliente (app móvil, web, etc.) es responsable de calcularla según las reglas de negocio
- Si necesitas calcular la fecha de entrega, consulta la documentación de días hábiles de la ruta
- **Todos los items del grupo se entregarán en esta fecha**
- Si necesitas diferentes fechas de entrega, crea grupos separados

**Lógica Recomendada para Calcular `fechaEntrega`:**

Ver archivo `FECHACAMBIO-Y-FECHAENTREGA.md` para detalles completos sobre cómo el cliente debe calcular esta fecha basándose en:

- Tipo de ruta (Fija vs Dinámica)
- Días de operación de la ruta
- Días hábiles del depósito
- Festivos y días inhábiles

---

### Nivel Items (Detalle de Cambios)

#### 4. `items` (array) - REQUERIDO ✅

**Descripción:** Array de items/productos que conforman el grupo de cambios.

**Para qué sirve:**

- Contiene el detalle de cada cambio capturado
- Puede incluir múltiples clientes (NUDs) en un solo grupo
- Cada item representa un producto específico para un cliente específico

**Validaciones:**

- ✅ **Tipo:** Array de objetos
- ✅ **Obligatorio:** Sí
- ✅ **Mínimo:** 1 item
- ✅ **Máximo:** 50 items por grupo
- ✅ **No duplicados:** No puede haber dos items con el mismo `NUD + clave_producto` en el mismo request

**Estructura de cada item:**

---

##### 4.1. `items[].NUD` (string) - REQUERIDO ✅

**Descripción:** Número Único de Distribuidor - Identificador del cliente/tienda para este cambio específico.

**Para qué sirve:**

- Identifica al cliente que recibirá el cambio
- Se valida contra la tabla `Cliente`
- Debe pertenecer a la ruta especificada en `pppcaptura`
- Se usa para buscar el nombre del cliente en respuestas
- Define el contexto de validación según tipo de ruta

**Validaciones:**

- ✅ **Tipo:** String (aunque en BD es numérico, se envía como string)
- ✅ **Obligatorio:** Sí
- ✅ **Debe existir:** En tabla `Cliente` con `CLAVE_CLIENTE = NUD`
- ✅ **Debe pertenecer a la ruta:** Según `tipoPPP` de la ruta
- ✅ **Mismo CEDIS:** El cliente debe pertenecer a la misma operación (`CLAVE_BODEGA = ID_Bodega`)

**Validación de Pertenencia a Ruta:**

```sql
-- Si ruta tiene tipoPPP = 0 (PREVENTA):
SELECT * FROM Cliente
WHERE CLAVE_CLIENTE = '10001'
  AND CLAVE_RUTA_PREVENTA = 123
  AND CLAVE_BODEGA = 1

-- Si ruta tiene tipoPPP = 1 (TELEVENTA):
SELECT * FROM Cliente
WHERE CLAVE_CLIENTE = '10001'
  AND CLAVE_RUTA_TELEVENTA = 123
  AND CLAVE_BODEGA = 1

-- Si ruta tiene tipoPPP = 2 (DESARROLLO):
SELECT * FROM Cliente
WHERE CLAVE_CLIENTE = '10001'
  AND CLAVE_RUTA_DESARROLLO = 123
  AND CLAVE_BODEGA = 1
```

**Ejemplos:**

```json
"NUD": "10001"    // ✅ Correcto
"NUD": "0"        // ❌ Cliente no existe
"NUD": 10001      // ❌ Debe ser string
```

**Errores Comunes:**

```json
// Cliente no encontrado
{
  "statusCode": 404,
  "message": "Cliente con NUD 10001 no encontrado",
  "error": "Not Found"
}

// Cliente no pertenece a la ruta
{
  "statusCode": 400,
  "message": "El cliente 10001 no pertenece a la ruta 123",
  "error": "Bad Request"
}
```

---

##### 4.2. `items[].clave_producto` (number) - REQUERIDO ✅

**Descripción:** SKU o código del producto que se está cambiando.

**Para qué sirve:**

- Identifica el producto específico del cambio
- Se valida contra el catálogo de productos elegibles
- Se usa para buscar información del producto (nombre, límites)
- Determina los límites de cantidad permitida
- Se usa para validar restricciones por motivo (restsku)

**Validaciones:**

- ✅ **Tipo:** Número entero positivo
- ✅ **Obligatorio:** Sí
- ✅ **Debe existir:** En tabla `ProductosCambios` para esa operación
- ✅ **Debe estar activo:** `activo = 1`
- ✅ **No restringido por motivo:** Si el motivo tiene `restsku`, validar que el SKU no esté en la lista
- ✅ **No restringido por CEDIS:** Si el motivo tiene `restcedis`, validar que el CEDIS no esté en la lista

**Ejemplo de Validación:**

```sql
-- Validar que el producto existe y está activo
SELECT sku, descripcion, minimo_permitido, maximo_permitido, maximo_para_alerta
FROM ProductosCambios WITH (NOLOCK)
WHERE sku = 123456
  AND idoperacion = 1
  AND activo = 1
```

**Restricciones por Motivo:**

**restsku** (Restricción por SKU):

```json
// Motivo 5 tiene: restsku = "100,200,300"
{
  "id_motivo": 5,
  "clave_producto": 200 // ❌ ERROR: SKU restringido para este motivo
}
```

**restcedis** (Restricción por CEDIS):

```json
// Motivo 3 tiene: restcedis = "1,2,5"
{
  "ID_Bodega": 1, // ❌ ERROR: CEDIS restringido para este motivo
  "items": [
    {
      "id_motivo": 3
    }
  ]
}
```

**Ejemplos:**

```json
"clave_producto": 123456     // ✅ Correcto
"clave_producto": 0          // ❌ Inválido
"clave_producto": "123456"   // ❌ Debe ser número
```

**Errores Comunes:**

```json
// Producto no encontrado en catálogo
{
  "statusCode": 422,
  "message": "Producto 123456 no está en el catálogo de cambios",
  "error": "Unprocessable Entity"
}

// SKU restringido para el motivo
{
  "statusCode": 422,
  "message": "El SKU 123456 no es elegible para el motivo seleccionado",
  "error": "Unprocessable Entity",
  "details": {
    "code": "SKU_NOT_ELIGIBLE_FOR_MOTIVO"
  }
}

// CEDIS restringido para el motivo
{
  "statusCode": 422,
  "message": "El CEDIS 1 no es elegible para el motivo seleccionado",
  "error": "Unprocessable Entity",
  "details": {
    "code": "CEDIS_NOT_ELIGIBLE_FOR_MOTIVO"
  }
}
```

---

##### 4.3. `items[].id_motivo` (number) - REQUERIDO ✅

**Descripción:** ID del motivo de cambio (razón por la que se solicita el cambio).

**Para qué sirve:**

- Indica la razón del cambio (producto dañado, vencido, etc.)
- Se valida contra el catálogo de motivos activos
- Puede tener restricciones de SKUs (`restsku`)
- Puede tener restricciones de CEDIS (`restcedis`)
- Se usa para reportes y análisis de cambios
- Determina si se requiere justificación adicional

**Validaciones:**

- ✅ **Tipo:** Número entero positivo
- ✅ **Obligatorio:** Sí
- ✅ **Debe existir:** En tabla `CambiosMotivos` con `activo = 1`
- ✅ **Validar restsku:** Si tiene restricciones, validar SKU
- ✅ **Validar restcedis:** Si tiene restricciones, validar CEDIS

**Motivos Comunes:**

| ID  | Motivo               | Descripción                  | Restricciones     |
| --- | -------------------- | ---------------------------- | ----------------- |
| 1   | Producto Dañado      | Mercancía dañada físicamente | Ninguna           |
| 2   | Producto Vencido     | Fecha de caducidad expirada  | restsku posible   |
| 3   | Error de Facturación | Error en la factura original | restcedis posible |
| 4   | Producto Incompleto  | Falta contenido del producto | Ninguna           |
| 5   | Cambio de Temporada  | Cambio por nueva temporada   | restsku posible   |

**Ejemplos:**

```json
"id_motivo": 1       // ✅ Producto Dañado
"id_motivo": 0       // ❌ Inválido
"id_motivo": "1"     // ❌ Debe ser número
```

**Errores Comunes:**

```json
// Motivo no encontrado o inactivo
{
  "statusCode": 404,
  "message": "Motivo 99 no encontrado o inactivo",
  "error": "Not Found"
}
```

---

##### 4.4. `items[].piezas` (number) - REQUERIDO ✅

**Descripción:** Cantidad de piezas/unidades del producto que se están cambiando.

**Para qué sirve:**

- Define cuántas unidades del producto se solicitan en el cambio
- Se valida contra los límites del producto en el catálogo
- Determina si se requiere justificación (si excede el umbral de alerta)
- Se usa para cálculos de inventario y logística
- Aparece en reportes y autorizaciones

**Validaciones:**

- ✅ **Tipo:** Número entero positivo
- ✅ **Obligatorio:** Sí
- ✅ **Mínimo absoluto:** 1 pieza
- ✅ **Máximo absoluto:** 999 piezas
- ✅ **Mínimo del producto:** >= `minimo_permitido` del catálogo (típicamente 1)
- ✅ **Máximo del producto:** <= `maximo_permitido` del catálogo (típicamente 999)
- ✅ **Umbral de alerta:** Si > `maximo_para_alerta` (típicamente 30), **requiere justificación**

**Límites Típicos por Producto:**

```sql
SELECT
    sku,
    descripcion,
    minimo_permitido,      -- Típicamente: 1
    maximo_permitido,      -- Típicamente: 999
    maximo_para_alerta     -- Típicamente: 30
FROM ProductosCambios
WHERE sku = 123456
```

**Regla de Justificación:**

```javascript
if (piezas > maximo_para_alerta) {
  // REQUIERE campo "justificacion"
  // Si no se proporciona → ERROR 422
}
```

**Ejemplos:**

```json
// ✅ Casos válidos
"piezas": 5              // OK - Dentro del rango normal
"piezas": 25             // OK - Dentro del rango normal
"piezas": 35             // OK - Pero REQUIERE justificacion

// ❌ Casos inválidos
"piezas": 0              // ❌ Mínimo es 1
"piezas": 1000           // ❌ Excede máximo permitido (999)
"piezas": -5             // ❌ No puede ser negativo
"piezas": "25"           // ❌ Debe ser número
"piezas": 35             // ❌ Sin justificacion (excede 30)
```

**Errores Comunes:**

```json
// Cantidad fuera de rango
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "items.0.piezas",
      "error": "La cantidad debe estar entre 1 y 999"
    }
  ]
}

// Requiere justificación
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "items.0.justificacion",
      "error": "Se requiere justificación para cantidades mayores a 30 piezas"
    }
  ]
}
```

---

##### 4.5. `items[].justificacion` (string) - CONDICIONAL ⚠️

**Descripción:** Texto explicativo del cambio, especialmente cuando se exceden los límites normales.

**Para qué sirve:**

- Documenta la razón específica del cambio
- **REQUERIDO** cuando las piezas exceden el umbral de alerta
- Opcional en otros casos, pero recomendado
- Se guarda en la columna `comentario` de la tabla `CapturaCambios`
- Visible para supervisores durante la autorización

**Cuándo es OBLIGATORIO:**

```javascript
if (piezas > producto.maximo_para_alerta) {
  // Típicamente: piezas > 30
  justificacion = REQUERIDA;
}
```

**Validaciones:**

- ✅ **Tipo:** String
- ✅ **Obligatorio:** Solo si `piezas > maximo_para_alerta`
- ✅ **Longitud mínima:** 5 caracteres (cuando se proporciona)
- ✅ **Longitud máxima:** 500 caracteres
- ✅ **No puede ser solo espacios:** Debe tener contenido real

**Ejemplos:**

```json
// ✅ Casos válidos
{
  "piezas": 25,
  "justificacion": "Producto llegó dañado en transporte"  // ✅ Opcional pero válido
}

{
  "piezas": 35,
  "justificacion": "Promoción especial requiere mayor cantidad"  // ✅ Requerido y válido
}

{
  "piezas": 10
  // ✅ No se requiere justificacion
}

// ❌ Casos inválidos
{
  "piezas": 35
  // ❌ Falta justificacion (piezas > 30)
}

{
  "piezas": 35,
  "justificacion": "Ok"  // ❌ Muy corta (< 5 caracteres)
}

{
  "piezas": 35,
  "justificacion": "     "  // ❌ Solo espacios
}
```

**Ejemplos de Buenas Justificaciones:**

```json
"justificacion": "Producto llegó dañado durante el transporte desde CEDIS"
"justificacion": "Cliente requiere cantidad mayor por promoción especial"
"justificacion": "Mercancía vencida encontrada en inventario durante auditoría"
"justificacion": "Solicitud especial autorizada por supervisor de zona"
"justificacion": "Reposición de lote completo por defecto de fábrica"
```

**Errores Comunes:**

```json
// Justificación requerida pero no proporcionada
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "items.0.justificacion",
      "error": "Se requiere justificación para cantidades mayores a 30 piezas"
    }
  ]
}

// Justificación muy corta
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "items.0.justificacion",
      "error": "La justificación debe tener al menos 5 caracteres"
    }
  ]
}
```

---

## 📅 Cálculo Automático de Fecha de Entrega

### Propósito

**Objetivo:** Calcular automáticamente cuándo se entregará el cambio al cliente, considerando:

- Tipo de ruta (fijo o dinámico)
- Días de operación de la ruta
- Días hábiles (excluye domingos)
- Días festivos configurados en el sistema

### Flujo de Cálculo

```
Request recibido
  ↓
1. FechaCambio = Fecha actual del sistema (hoy)
  ↓
2. Consultar información de la ruta:
   - tipo (1=fijo, 2=dinámico)
   - idruta (para rutas fijas)
   - días de operación
  ↓
3. ¿Es ruta fija (tipo=1) o dinámica (tipo=2)?
  ↓
┌─────────────┴─────────────┐
│                           │
RUTA FIJA                  RUTA DINÁMICA
(tipo = 1)                 (tipo = 2)
│                           │
↓                           ↓
Buscar próximo día         Sumar 2 días hábiles
de operación de esa        (excluyendo domingos
ruta específica            y festivos)
│                           │
└─────────────┬─────────────┘
              ↓
        fechaEntrega calculada
              ↓
        Guardar en BD
```

---

### Tipo 1: Ruta Fija (Despacho Programado)

**Características:**

- Tienen días específicos de operación
- Cada ruta tiene su propio calendario
- El despacho se hace en días programados
- Requiere tabla auxiliar con días de operación

**Lógica de Cálculo:**

```typescript
// Pseudo-código
if (ruta.tipo === 1) {  // Ruta Fija
  // 1. Buscar próximo día de operación de esta ruta
  const diasOperacion = await obtenerDiasOperacion(ruta.idruta);

  // diasOperacion = [1, 3, 5]  // Ejemplo: Lunes, Miércoles, Viernes

  // 2. Empezar desde mañana
  let fechaActual = hoy + 1 día;

  // 3. Buscar el próximo día que:
  //    - Sea día de operación de la ruta
  //    - No sea domingo
  //    - No sea festivo
  while (true) {
    const diaSemana = fechaActual.getDayOfWeek(); // 0=Domingo, 1=Lunes, ..., 6=Sábado

    if (diasOperacion.includes(diaSemana) &&
        diaSemana !== 0 &&
        !esFestivo(fechaActual)) {
      fechaEntrega = fechaActual;
      break;
    }

    fechaActual = fechaActual + 1 día;
  }
}
```

**Ejemplo Real:**

```
Hoy: Martes 2025-10-28
Ruta 123 (Fija) opera: Lunes, Miércoles, Viernes

Cálculo:
  - Mañana: Miércoles 29 → ✅ Es día de operación → fechaEntrega = 2025-10-29

Hoy: Viernes 2025-10-31
Ruta 123 (Fija) opera: Lunes, Miércoles, Viernes

Cálculo:
  - Mañana: Sábado 01 → ❌ No opera
  - Siguiente: Domingo 02 → ❌ Domingo
  - Siguiente: Lunes 03 → ✅ Es día de operación → fechaEntrega = 2025-11-03
```

**Campos Guardados en BD:**

```sql
INSERT INTO CapturaCambios (
  ...,
  FechaCambio,     -- 2025-10-28 (hoy)
  fechaEntrega,    -- 2025-10-29 (calculada)
  idruta,          -- 456 (ID interno de la ruta)
  estatusDis,      -- 2 (cerrado - para rutas fijas)
  ...
)
```

---

### Tipo 2: Ruta Dinámica (Despacho Inmediato)

**Características:**

- No tienen días específicos de operación
- El despacho es más flexible
- Se calcula sumando días hábiles
- Típicamente: +2 días hábiles

**Lógica de Cálculo:**

```typescript
// Pseudo-código
if (ruta.tipo === 2) {  // Ruta Dinámica
  const DIAS_HABILES_SUMAR = 2;

  let diasSumados = 0;
  let fechaActual = hoy + 1 día;

  while (diasSumados < DIAS_HABILES_SUMAR) {
    const diaSemana = fechaActual.getDayOfWeek();

    // ¿Es día hábil? (no domingo, no festivo)
    if (diaSemana !== 0 && !esFestivo(fechaActual)) {
      diasSumados++;
    }

    if (diasSumados < DIAS_HABILES_SUMAR) {
      fechaActual = fechaActual + 1 día;
    }
  }

  fechaEntrega = fechaActual;
}
```

**Ejemplo Real:**

```
Hoy: Martes 2025-10-28
Ruta 456 (Dinámica) - Sumar 2 días hábiles

Cálculo:
  - Mañana: Miércoles 29 → ✅ Día hábil 1
  - Siguiente: Jueves 30 → ✅ Día hábil 2
  → fechaEntrega = 2025-10-30

Hoy: Viernes 2025-10-31
Ruta 456 (Dinámica) - Sumar 2 días hábiles

Cálculo:
  - Mañana: Sábado 01 → ✅ Día hábil 1
  - Siguiente: Domingo 02 → ❌ Domingo (no cuenta)
  - Siguiente: Lunes 03 → ✅ Día hábil 2
  → fechaEntrega = 2025-11-03
```

**Campos Guardados en BD:**

```sql
INSERT INTO CapturaCambios (
  ...,
  FechaCambio,     -- 2025-10-28 (hoy)
  fechaEntrega,    -- 2025-10-30 (calculada)
  idruta,          -- NULL (no aplica para dinámicas)
  estatusDis,      -- NULL (no aplica para dinámicas)
  horadinamico,    -- GETDATE() (timestamp de captura)
  ...
)
```

---

### Consideración de Festivos

**Tabla de Festivos:**

```sql
-- Tabla: Festivos (ejemplo)
CREATE TABLE Festivos (
  fecha DATE PRIMARY KEY,
  descripcion VARCHAR(100),
  activo BIT
)

-- Ejemplos
INSERT INTO Festivos VALUES
  ('2025-01-01', 'Año Nuevo', 1),
  ('2025-02-05', 'Día de la Constitución', 1),
  ('2025-03-21', 'Natalicio de Benito Juárez', 1),
  ('2025-05-01', 'Día del Trabajo', 1),
  ('2025-09-16', 'Día de la Independencia', 1),
  ('2025-11-20', 'Revolución Mexicana', 1),
  ('2025-12-25', 'Navidad', 1)
```

**Validación de Festivos:**

```typescript
function esFestivo(fecha: Date): boolean {
  // Consultar en tabla Festivos
  const festivo = await db.query(
    'SELECT 1 FROM Festivos WHERE fecha = ? AND activo = 1',
    [fecha],
  );

  return festivo.length > 0;
}
```

**Ejemplo con Festivo:**

```
Hoy: Jueves 2025-12-24
Ruta Dinámica - Sumar 2 días hábiles
Festivo: 2025-12-25 (Navidad)

Cálculo:
  - Mañana: Viernes 25 → ❌ Es festivo (Navidad)
  - Siguiente: Sábado 26 → ✅ Día hábil 1
  - Siguiente: Domingo 27 → ❌ Domingo
  - Siguiente: Lunes 28 → ✅ Día hábil 2
  → fechaEntrega = 2025-12-28
```

---

### Diferencias Clave entre Tipo 1 y Tipo 2

| Aspecto               | Tipo 1 (Fijo)              | Tipo 2 (Dinámico)         |
| --------------------- | -------------------------- | ------------------------- |
| **Días de operación** | Definidos por ruta         | Todos los días hábiles    |
| **Cálculo**           | Próximo día de operación   | Hoy + 2 días hábiles      |
| **idruta en BD**      | Se guarda (ej: 456)        | NULL                      |
| **estatusDis**        | 2 (cerrado)                | NULL                      |
| **horadinamico**      | NULL                       | GETDATE()                 |
| **Flexibilidad**      | Baja (días fijos)          | Alta (cualquier día)      |
| **Uso típico**        | Rutas grandes, programadas | Rutas pequeñas, flexibles |

---

## 🔒 Reglas de Negocio Completas

### 1. Validación de Operación y Ruta

#### 1.1. Operación Activa

```
✅ La operación (ID_Bodega) debe existir y estar activa
❌ Si no existe o está inactiva → 404 Not Found
```

**SQL:**

```sql
SELECT idoperacion
FROM Operaciones
WHERE idoperacion = @ID_Bodega
  AND activo = 1
```

---

#### 1.2. Ruta Activa y Pertenece a Operación

```
✅ La ruta (pppcaptura) debe existir y estar activa
✅ Debe pertenecer a la operación especificada
❌ Si no cumple → 404 Not Found
```

**SQL:**

```sql
SELECT ruta, nombre, tipoPPP, tipo
FROM Rutascambios
WHERE ruta = @pppcaptura
  AND idoperacion = @ID_Bodega
  AND activo = 1
```

---

### 2. Validación de Grupo Único

#### 2.1. No Grupos Activos Duplicados

```
✅ Solo puede existir UN grupo pendiente por ruta y fecha
❌ Si ya existe un grupo con statusAutorizado = 0 → 409 Conflict
```

**SQL:**

```sql
SELECT COUNT(*) as total
FROM CapturaCambios
WHERE pppcaptura = @pppcaptura
  AND FechaCambio = @hoy
  AND idoperacion = @ID_Bodega
  AND statusAutorizado = 0  -- Pendiente

-- Si total > 0 → ERROR 409
```

**Lógica:**

- Un promotor solo puede tener **un grupo pendiente por día**
- Si quiere agregar más cambios, debe:
  - **Opción A:** Usar `GET /active` para obtener el grupo existente y editarlo
  - **Opción B:** Esperar a que se autorice el grupo actual
  - **Opción C:** Usar `PUT /:folio` para actualizar el grupo existente

---

### 3. Validación de Clientes (NUDs)

#### 3.1. Cliente Existe y Está Activo

```
✅ Cada NUD debe existir en la tabla Cliente
✅ Debe pertenecer a la misma operación (CLAVE_BODEGA = ID_Bodega)
❌ Si no existe → 404 Not Found
```

**SQL:**

```sql
SELECT CLAVE_CLIENTE, NOM_CLIENTE, CLAVE_BODEGA
FROM Cliente
WHERE CLAVE_CLIENTE = @NUD
  AND CLAVE_BODEGA = @ID_Bodega
```

---

#### 3.2. Cliente Pertenece a la Ruta

```
✅ El cliente debe pertenecer a la ruta según tipoPPP
❌ Si no pertenece → 400 Bad Request
```

**Validación por tipoPPP:**

```sql
-- Obtener tipoPPP de la ruta
DECLARE @tipoPPP INT
SELECT @tipoPPP = tipoPPP
FROM Rutascambios
WHERE ruta = @pppcaptura

-- Validar según tipo
IF @tipoPPP = 0  -- PREVENTA
  SELECT * FROM Cliente
  WHERE CLAVE_CLIENTE = @NUD
    AND CLAVE_RUTA_PREVENTA = @pppcaptura

ELSE IF @tipoPPP = 1  -- TELEVENTA
  SELECT * FROM Cliente
  WHERE CLAVE_CLIENTE = @NUD
    AND CLAVE_RUTA_TELEVENTA = @pppcaptura

ELSE IF @tipoPPP = 2  -- DESARROLLO
  SELECT * FROM Cliente
  WHERE CLAVE_CLIENTE = @NUD
    AND CLAVE_RUTA_DESARROLLO = @pppcaptura
```

---

### 4. Validación de Productos

#### 4.1. Producto en Catálogo

```
✅ El SKU debe existir en ProductosCambios para esa operación
✅ Debe estar activo (activo = 1)
❌ Si no existe → 422 Unprocessable Entity
```

**SQL:**

```sql
SELECT
  sku,
  descripcion,
  minimo_permitido,
  maximo_permitido,
  maximo_para_alerta
FROM ProductosCambios
WHERE sku = @clave_producto
  AND idoperacion = @ID_Bodega
  AND activo = 1
```

---

#### 4.2. Límites de Cantidad

```
✅ piezas >= minimo_permitido (típicamente 1)
✅ piezas <= maximo_permitido (típicamente 999)
✅ 1 <= piezas <= 999 (límite absoluto)
❌ Si no cumple → 422 Unprocessable Entity
```

**Validación:**

```typescript
if (piezas < producto.minimo_permitido || piezas > producto.maximo_permitido) {
  throw new UnprocessableEntityException(
    `Cantidad debe estar entre ${minimo} y ${maximo}`,
  );
}
```

---

#### 4.3. Justificación por Cantidad Alta

```
✅ Si piezas > maximo_para_alerta → justificacion REQUERIDA
✅ justificacion.length >= 5 && justificacion.length <= 500
❌ Si falta justificacion → 422 Unprocessable Entity
```

**Validación:**

```typescript
if (piezas > producto.maximo_para_alerta && !justificacion) {
  throw new UnprocessableEntityException(
    'Se requiere justificación para cantidades altas',
  );
}

if (justificacion && justificacion.trim().length < 5) {
  throw new UnprocessableEntityException(
    'Justificación debe tener al menos 5 caracteres',
  );
}
```

---

### 5. Validación de Motivos

#### 5.1. Motivo Activo

```
✅ El id_motivo debe existir y estar activo
❌ Si no existe → 404 Not Found
```

**SQL:**

```sql
SELECT idcambiosmotivos, motivoCambio, restsku, restcedis
FROM CambiosMotivos
WHERE idcambiosmotivos = @id_motivo
  AND activo = 1
```

---

#### 5.2. Restricción por SKU (restsku)

```
✅ Si el motivo tiene restsku, validar que el SKU NO esté en la lista
❌ Si está restringido → 422 Unprocessable Entity (SKU_NOT_ELIGIBLE_FOR_MOTIVO)
```

**Ejemplo:**

```sql
-- Motivo tiene: restsku = "100,200,300"
-- Request trae: clave_producto = 200

-- Validación:
IF CHARINDEX(','+CAST(@clave_producto AS VARCHAR)+',', ','+@restsku+',') > 0
  -- ERROR: SKU restringido
```

**Implementación en servicio:**

```typescript
if (motivo.restsku) {
  const skusRestringidos = motivo.restsku.split(',').map((s) => parseInt(s));

  if (skusRestringidos.includes(item.clave_producto)) {
    throw new UnprocessableEntityException({
      code: 'SKU_NOT_ELIGIBLE_FOR_MOTIVO',
      message: `El SKU ${item.clave_producto} no es elegible para este motivo`,
    });
  }
}
```

---

#### 5.3. Restricción por CEDIS (restcedis)

```
✅ Si el motivo tiene restcedis, validar que el CEDIS NO esté en la lista
❌ Si está restringido → 422 Unprocessable Entity (CEDIS_NOT_ELIGIBLE_FOR_MOTIVO)
```

**Ejemplo:**

```sql
-- Motivo tiene: restcedis = "1,2,5"
-- Request trae: ID_Bodega = 1

-- Validación:
IF CHARINDEX(','+CAST(@ID_Bodega AS VARCHAR)+',', ','+@restcedis+',') > 0
  -- ERROR: CEDIS restringido
```

**Implementación en servicio:**

```typescript
if (motivo.restcedis) {
  const cedisRestringidos = motivo.restcedis.split(',').map((c) => parseInt(c));

  if (cedisRestringidos.includes(dto.ID_Bodega)) {
    throw new UnprocessableEntityException({
      code: 'CEDIS_NOT_ELIGIBLE_FOR_MOTIVO',
      message: `El CEDIS ${dto.ID_Bodega} no es elegible para este motivo`,
    });
  }
}
```

---

### 6. Validación de Items

#### 6.1. Cantidad de Items

```
✅ Mínimo: 1 item
✅ Máximo: 50 items por grupo
❌ Si no cumple → 422 Unprocessable Entity
```

---

#### 6.2. No Duplicados en Request

```
✅ No puede haber dos items con el mismo NUD + clave_producto en el mismo request
❌ Si hay duplicados → 422 Unprocessable Entity
```

**Validación:**

```typescript
const combinaciones = new Set();

for (const item of dto.items) {
  const key = `${item.NUD}-${item.clave_producto}`;

  if (combinaciones.has(key)) {
    throw new UnprocessableEntityException(
      `Producto ${item.clave_producto} duplicado para cliente ${item.NUD}`,
    );
  }

  combinaciones.add(key);
}
```

---

### 7. Transaccionalidad

#### 7.1. Todo o Nada

```
✅ Si alguna validación falla, NO se crea NINGÚN registro
✅ Se usa transacción de base de datos
✅ Rollback automático en caso de error
```

**Implementación:**

```typescript
await this.dataSource.transaction(async (manager) => {
  // Crear todos los items
  for (const item of dto.items) {
    const cambio = manager.create(CapturaCambio, {...});
    await manager.save(cambio);
  }

  // Si llega aquí → COMMIT
  // Si hay error → ROLLBACK automático
});
```

---

### 8. Idempotencia

#### 8.1. Header X-Idempotency-Key

```
✅ Si se proporciona, previene duplicados
✅ Si se reintenta con el mismo key, retorna el grupo existente
✅ No es obligatorio pero RECOMENDADO
```

**Implementación:**

```typescript
if (idempotencyKey) {
  // Buscar si ya existe un grupo con ese key
  const existing = await cache.get(idempotencyKey);

  if (existing) {
    // Ya se procesó, retornar el resultado guardado
    return existing;
  }

  // Procesar y guardar resultado
  const result = await crearGrupo(dto);
  await cache.set(idempotencyKey, result, TTL_24_HOURS);

  return result;
}
```

---

## 📊 Campos Calculados y Auto-generados

### Campos que NO se envían en el Request

Estos campos son calculados/generados automáticamente por el sistema:

| Campo                 | Tipo     | Cómo se calcula                        | Ejemplo                        |
| --------------------- | -------- | -------------------------------------- | ------------------------------ |
| `FechaCambio`         | datetime | Fecha actual del servidor              | `2025-10-28`                   |
| `fechaEntrega`        | datetime | Calculada según tipo de ruta           | `2025-10-30`                   |
| `horaCaptura`         | datetime | Timestamp actual `GETDATE()`           | `2025-10-28 14:35:22`          |
| `tiempoCambio`        | datetime | Timestamp actual `GETDATE()`           | `2025-10-28 14:35:22`          |
| `numCapturo`          | int      | Usuario de la API Key                  | `99999`                        |
| `numAutorizador`      | int      | NULL (se llena al autorizar)           | `NULL`                         |
| `statusAutorizado`    | int      | Siempre 0 (Pendiente) al crear         | `0`                            |
| `tiempoAutorizado`    | datetime | NULL (se llena al autorizar)           | `NULL`                         |
| `pedidopromsio`       | bit      | Siempre 1 (sí es pedido)               | `1`                            |
| `idruta`              | int      | Para rutas fijas, buscado en BD        | `456` o `NULL`                 |
| `estatusDis`          | int      | Para rutas fijas: 2, dinámicas: NULL   | `2` o `NULL`                   |
| `horadinamico`        | datetime | Para rutas dinámicas: `GETDATE()`      | `2025-10-28 14:35:22` o `NULL` |
| `idBodega`            | int      | Buscado desde `depositos.CLAVE_BODEGA` | `101`                          |
| `skuConver`           | int      | NULL (legacy field)                    | `NULL`                         |
| `numSupervisor`       | int      | Para rutas fijas, de la ruta           | `88888` o `NULL`               |
| `numGrupoSupervision` | int      | Para rutas fijas, de la ruta           | `5` o `NULL`                   |
| `skuPadre`            | int      | Buscado en `ProductoCambios`           | `123000` o `NULL`              |
| `idProductoCambio`    | int      | Buscado en `ProductoCambios`           | `789` o `NULL`                 |

---

## 📝 Ejemplo Completo con Todos los Campos

### Request Real

```json
POST /api/v2/captura_cambios
Content-Type: application/json
x-api-key: a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d
x-idempotency-key: 550e8400-e29b-41d4-a716-446655440001

{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "items": [
    {
      "NUD": "10001",
      "clave_producto": 123456,
      "id_motivo": 1,
      "piezas": 25,
      "justificacion": "Producto llegó dañado en transporte"
    },
    {
      "NUD": "10002",
      "clave_producto": 789012,
      "id_motivo": 2,
      "piezas": 35,
      "justificacion": "Lote completo vencido, requiere reposición urgente"
    },
    {
      "NUD": "10002",
      "clave_producto": 456789,
      "id_motivo": 1,
      "piezas": 10
    }
  ]
}
```

---

### Response Exitoso (201 Created)

```json
{
  "result": {
    "data": {
      "folio_virtual": "123-2025-10-28",
      "pppcaptura": 123,
      "FechaCambio": "2025-10-28",
      "fechaEntrega": "2025-10-30",
      "idoperacion": 1,
      "statusAutorizado": 0,
      "statusTexto": "Pendiente",
      "totalItems": 3,
      "totalPiezas": 70,
      "items": [
        {
          "NUD": "10001",
          "nombreCliente": "Tienda Center",
          "sku": 123456,
          "nombreProducto": "Refresco Pepsi 600ml",
          "piezas": 25,
          "motivo": "Producto Dañado",
          "justificacion": "Producto llegó dañado en transporte",
          "fechaEntrega": "2025-10-30"
        },
        {
          "NUD": "10002",
          "nombreCliente": "Súper Express",
          "sku": 789012,
          "nombreProducto": "Jugo Del Valle Naranja 1L",
          "piezas": 35,
          "motivo": "Producto Vencido",
          "justificacion": "Lote completo vencido, requiere reposición urgente",
          "fechaEntrega": "2025-10-30"
        },
        {
          "NUD": "10002",
          "nombreCliente": "Súper Express",
          "sku": 456789,
          "nombreProducto": "Agua Ciel 1.5L",
          "piezas": 10,
          "motivo": "Producto Dañado",
          "justificacion": null,
          "fechaEntrega": "2025-10-30"
        }
      ]
    },
    "successful": true,
    "message": "Grupo de cambios creado correctamente."
  }
}
```

---

### Registros Creados en BD

```sql
-- Tabla: CapturaCambios (3 registros)

-- Registro 1
INSERT INTO CapturaCambios (
  idoperacion, numCapturo, idcambiosmotivos, idProductoCambio,
  FechaCambio, cantidad, nud, fechaEntrega,
  horaCaptura, pppcaptura, comentario, idBodega,
  sku, skuConver, statusAutorizado, tiempoCambio,
  idruta, estatusDis, pedidopromsio, skuPadre,
  numSupervisor, numGrupoSupervision
) VALUES (
  1,           -- idoperacion (ID_Bodega)
  99999,       -- numCapturo (de API Key)
  1,           -- idcambiosmotivos (id_motivo)
  789,         -- idProductoCambio (buscado)
  '2025-10-28', -- FechaCambio (hoy)
  25,          -- cantidad (piezas)
  10001,       -- nud (NUD)
  '2025-10-30', -- fechaEntrega (calculada)
  GETDATE(),   -- horaCaptura
  123,         -- pppcaptura
  'Producto llegó dañado en transporte', -- comentario (justificacion)
  101,         -- idBodega (de depositos)
  123456,      -- sku (clave_producto)
  NULL,        -- skuConver
  0,           -- statusAutorizado (Pendiente)
  GETDATE(),   -- tiempoCambio
  456,         -- idruta (si es ruta fija)
  2,           -- estatusDis (si es ruta fija)
  1,           -- pedidopromsio
  123000,      -- skuPadre
  88888,       -- numSupervisor
  5            -- numGrupoSupervision
);

-- Registro 2 (similar para NUD 10002, SKU 789012)
-- Registro 3 (similar para NUD 10002, SKU 456789)
```

---

## ❌ Casos de Error Comunes

### Error 1: Operación No Encontrada

**Request:**

```json
{
  "ID_Bodega": 999,
  ...
}
```

**Response (404):**

```json
{
  "statusCode": 404,
  "message": "Operación no encontrada o inactiva",
  "error": "Not Found"
}
```

---

### Error 2: Ruta No Pertenece a Operación

**Request:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 999,
  ...
}
```

**Response (404):**

```json
{
  "statusCode": 404,
  "message": "Ruta no encontrada o inactiva en esta operación",
  "error": "Not Found"
}
```

---

### Error 3: Grupo Activo Duplicado

**Request:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  ...
}
```

**Response (409):**

```json
{
  "statusCode": 409,
  "message": "Ya existe un grupo activo para esta ruta y fecha",
  "error": "Conflict",
  "details": {
    "folio_existente": "123-2025-10-28",
    "sugerencia": "Use PUT /captura_cambios/123-2025-10-28 para actualizar el grupo existente"
  }
}
```

---

### Error 4: Cliente No Pertenece a Ruta

**Request:**

```json
{
  "pppcaptura": 123,
  "items": [{
    "NUD": "99999",
    ...
  }]
}
```

**Response (400):**

```json
{
  "statusCode": 400,
  "message": "El cliente 99999 no pertenece a la ruta 123",
  "error": "Bad Request",
  "details": {
    "ruta": 123,
    "tipoPPP": 0,
    "campo_validado": "CLAVE_RUTA_PREVENTA"
  }
}
```

---

### Error 5: Producto No en Catálogo

**Request:**

```json
{
  "items": [{
    "clave_producto": 999999,
    ...
  }]
}
```

**Response (422):**

```json
{
  "statusCode": 422,
  "message": "Producto 999999 no está en el catálogo de cambios para esta operación",
  "error": "Unprocessable Entity"
}
```

---

### Error 6: SKU Restringido por Motivo

**Request:**

```json
{
  "items": [
    {
      "clave_producto": 200,
      "id_motivo": 5
    }
  ]
}
```

**Response (422):**

```json
{
  "statusCode": 422,
  "message": "El SKU 200 no es elegible para el motivo seleccionado",
  "error": "Unprocessable Entity",
  "details": {
    "code": "SKU_NOT_ELIGIBLE_FOR_MOTIVO",
    "motivo": "Cambio de Temporada",
    "skus_restringidos": "100,200,300"
  }
}
```

---

### Error 7: Falta Justificación

**Request:**

```json
{
  "items": [
    {
      "piezas": 35
      // Falta justificacion
    }
  ]
}
```

**Response (422):**

```json
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "items.0.justificacion",
      "error": "Se requiere justificación para cantidades mayores a 30 piezas"
    }
  ]
}
```

---

### Error 8: Productos Duplicados

**Request:**

```json
{
  "items": [
    {
      "NUD": "10001",
      "clave_producto": 123456,
      ...
    },
    {
      "NUD": "10001",
      "clave_producto": 123456,  // ❌ Duplicado
      ...
    }
  ]
}
```

**Response (422):**

```json
{
  "statusCode": 422,
  "message": "Producto 123456 duplicado para cliente 10001",
  "error": "Unprocessable Entity",
  "details": {
    "combinacion_duplicada": "10001-123456"
  }
}
```

---

## 🎯 Resumen de Validaciones

| #   | Validación                        | Tipo      | Código Error |
| --- | --------------------------------- | --------- | ------------ |
| 1   | Operación existe y activa         | Operación | 404          |
| 2   | Ruta existe y activa              | Ruta      | 404          |
| 3   | Ruta pertenece a operación        | Ruta      | 404          |
| 4   | No hay grupo activo duplicado     | Grupo     | 409          |
| 5   | Cliente existe                    | Cliente   | 404          |
| 6   | Cliente pertenece a ruta          | Cliente   | 400          |
| 7   | Producto en catálogo              | Producto  | 422          |
| 8   | Cantidad dentro de límites        | Producto  | 422          |
| 9   | Justificación cuando es necesaria | Producto  | 422          |
| 10  | Motivo existe y activo            | Motivo    | 404          |
| 11  | SKU no restringido por motivo     | Motivo    | 422          |
| 12  | CEDIS no restringido por motivo   | Motivo    | 422          |
| 13  | Mínimo 1 item, máximo 50          | Items     | 422          |
| 14  | No productos duplicados           | Items     | 422          |
| 15  | API Key válida                    | Auth      | 401          |

---

## 📚 Referencias

- **Endpoint:** `POST /api/v2/captura_cambios`
- **Documentación Swagger:** http://localhost:3000/api/docs
- **DTOs:**
  - `CreateCambioDTO` - DTO principal
  - `CambioItemDTO` - DTO de items
  - `CambioGroupResponseDTO` - Response
- **Servicios:**
  - `CapturaCambioService` - Lógica de negocio
  - `FechaEntregaService` - Cálculo de fechas
- **Entities:**
  - `CapturaCambio` - Tabla principal
  - `Rutascambios` - Info de rutas
  - `Cliente` - Info de clientes
  - `ProductosCambios` - Catálogo
  - `CambiosMotivos` - Motivos

---

**Última actualización:** 2025-11-04  
**Autor:** Equipo Técnico GEPP/Draweb  
**Versión API:** 2.0.1
