# Endpoint: Actualizar Grupo de Cambios (PUT)

## Información General

- **Ruta**: `PUT /api/v2/captura_cambios/:folio`
- **Autenticación**: API Key requerida (Header: `x-api-key`)
- **Flujo**: 5.5 - Actualizar grupo de cambios pendiente

## Descripción

Permite actualizar un grupo de cambios existente mientras esté en estado **Pendiente**. Al actualizar, se reemplazan TODOS los items del grupo con los nuevos.

## Reglas de Negocio

### ✅ Se PUEDE actualizar si:

1. El grupo está en estado `Pendiente` (statusAutorizado = 0)
2. El despacho NO ha sido cerrado (estatusDis != 1)
3. El pppcaptura del request coincide con el del grupo original

### ❌ NO se puede actualizar si:

1. El grupo ya fue **Autorizado** (statusAutorizado = 1)
2. El grupo fue **Declinado** (statusAutorizado = 2)
3. El **despacho ya fue cerrado** (estatusDis = 1)
4. El pppcaptura no coincide con el grupo original

## Request

### Parámetros de Ruta

| Parámetro | Tipo   | Descripción             | Ejemplo          |
| --------- | ------ | ----------------------- | ---------------- |
| `folio`   | string | Folio virtual del grupo | `123-2025-10-30` |

### Headers

| Header              | Requerido | Descripción                                   |
| ------------------- | --------- | --------------------------------------------- |
| `x-api-key`         | Sí        | API Key de autenticación                      |
| `x-idempotency-key` | No        | UUID para prevenir actualizaciones duplicadas |
| `Content-Type`      | Sí        | `application/json`                            |

### Body (JSON)

```json
{
  "NUD": 10001,
  "pppcaptura": 123,
  "ID_Bodega": 1,
  "items": [
    {
      "clave_producto": 123456,
      "id_motivo": 1,
      "piezas": 30,
      "justificacion": "Cantidad corregida después de revisión"
    },
    {
      "clave_producto": 654321,
      "id_motivo": 2,
      "piezas": 15,
      "justificacion": "Producto adicional encontrado dañado"
    }
  ],
  "comentario": "Actualización por revisión de inventario"
}
```

### Validaciones del Body

| Campo                    | Tipo   | Validaciones                        | Descripción                              |
| ------------------------ | ------ | ----------------------------------- | ---------------------------------------- |
| `NUD`                    | number | Requerido, entero                   | Número de cliente                        |
| `pppcaptura`             | number | Requerido, entero                   | Debe coincidir con el folio              |
| `ID_Bodega`              | number | Requerido, entero                   | ID de operación/bodega                   |
| `items`                  | array  | Requerido, mínimo 1 item            | Items del cambio                         |
| `items[].clave_producto` | number | Requerido, debe existir en catálogo | SKU del producto                         |
| `items[].id_motivo`      | number | Requerido, debe existir             | ID del motivo                            |
| `items[].piezas`         | number | Requerido, entre 1 y 999            | Cantidad de piezas                       |
| `items[].justificacion`  | string | Opcional, 5-255 chars               | Justificación (requerida si piezas > 30) |
| `comentario`             | string | Opcional, 5-500 chars               | Comentario general del grupo             |

## Response

### 200 OK - Grupo actualizado correctamente

```json
{
  "result": {
    "data": {
      "folio_virtual": "123-2025-10-30",
      "pppcaptura": 123,
      "FechaCambio": "2025-10-30",
      "idoperacion": 1,
      "clientes_total": 1,
      "piezas_total": 45,
      "items_total": 2,
      "statusAutorizado": 0,
      "fecha_creacion": "2025-10-30T14:30:00Z",
      "fecha_autorizacion": null,
      "items": [
        {
          "idcambios": 501,
          "nud": 10001,
          "nombre_cliente": "Tienda de Prueba",
          "sku": 123456,
          "descripcion_producto": "Pepsi 600ml",
          "cantidad": 30,
          "id_motivo": 1,
          "descripcion_motivo": "Producto Dañado",
          "comentario": "Cantidad corregida después de revisión",
          "fecha_entrega": "2025-11-02"
        },
        {
          "idcambios": 502,
          "nud": 10001,
          "sku": 654321,
          "descripcion_producto": "7UP 2L",
          "cantidad": 15,
          "id_motivo": 2,
          "descripcion_motivo": "Próximo a Vencer",
          "comentario": "Producto adicional encontrado dañado",
          "fecha_entrega": "2025-11-02"
        }
      ]
    },
    "successful": true,
    "message": "Grupo actualizado correctamente."
  }
}
```

### 403 Forbidden - PPP no coincide

```json
{
  "result": {
    "data": {},
    "successful": false,
    "errors": {
      "code": "FORBIDDEN",
      "detail": "El pppcaptura no coincide con el grupo original."
    }
  }
}
```

### 404 Not Found - Grupo no encontrado

```json
{
  "result": {
    "data": {},
    "successful": false,
    "errors": {
      "code": "GROUP_NOT_FOUND",
      "detail": "Grupo 123-2025-10-30 no encontrado"
    }
  }
}
```

### 409 Conflict - Grupo ya autorizado o despacho cerrado

```json
{
  "result": {
    "data": {},
    "successful": false,
    "errors": {
      "code": "GROUP_ALREADY_AUTHORIZED",
      "detail": "El grupo no puede actualizarse porque ya fue autorizado o declinado."
    }
  }
}
```

```json
{
  "result": {
    "data": {},
    "successful": false,
    "errors": {
      "code": "DISPATCH_CLOSED",
      "detail": "El grupo no puede actualizarse porque el despacho ya fue cerrado."
    }
  }
}
```

### 422 Unprocessable Entity - Errores de validación

```json
{
  "result": {
    "data": {},
    "successful": false,
    "errors": {
      "code": "VALIDATION_FAILED",
      "detail": "Errores en los items del grupo",
      "items": [
        {
          "item": 0,
          "error": "SKU 999999 no está en el catálogo"
        },
        {
          "item": 1,
          "error": "Cantidad 50 excede umbral (30) y requiere justificación"
        }
      ]
    }
  }
}
```

## Ejemplos de Uso

### Ejemplo 1: Actualizar cantidades

**Escenario**: Promotor capturó 50 Pepsis, pero después de revisar son 30.

```bash
curl -X PUT "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30" \
  -H "x-api-key: your-api-key-here" \
  -H "Content-Type: application/json" \
  -H "x-idempotency-key: 550e8400-e29b-41d4-a716-446655440001" \
  -d '{
    "NUD": 10001,
    "pppcaptura": 123,
    "ID_Bodega": 1,
    "items": [
      {
        "clave_producto": 123456,
        "id_motivo": 1,
        "piezas": 30,
        "justificacion": "Corrección: eran 30, no 50"
      }
    ]
  }'
```

### Ejemplo 2: Agregar productos al grupo

**Escenario**: Promotor capturó Pepsis dañadas, pero también encontró Doritos dañados.

```bash
curl -X PUT "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30" \
  -H "x-api-key: your-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{
    "NUD": 10001,
    "pppcaptura": 123,
    "ID_Bodega": 1,
    "items": [
      {
        "clave_producto": 123456,
        "id_motivo": 1,
        "piezas": 25,
        "justificacion": "Producto dañado en transporte"
      },
      {
        "clave_producto": 789012,
        "id_motivo": 1,
        "piezas": 12,
        "justificacion": "También dañados, encontrados después"
      }
    ],
    "comentario": "Se agregaron Doritos dañados encontrados en segunda revisión"
  }'
```

### Ejemplo 3: Cambiar motivos

**Escenario**: El motivo original era incorrecto, se actualiza.

```bash
curl -X PUT "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30" \
  -H "x-api-key: your-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{
    "NUD": 10001,
    "pppcaptura": 123,
    "ID_Bodega": 1,
    "items": [
      {
        "clave_producto": 123456,
        "id_motivo": 3,
        "piezas": 25,
        "justificacion": "Motivo corregido: Error de entrega, no producto dañado"
      }
    ]
  }'
```

## Flujo Completo de Actualización

```
1. Usuario detecta error en grupo pendiente
   ↓
2. GET /captura_cambios/123-2025-10-30
   → Verifica que statusAutorizado = 0 (Pendiente)
   ↓
3. PUT /captura_cambios/123-2025-10-30
   Body: { pppcaptura, NUD, ID_Bodega, items: [...nuevos items...] }
   ↓
4. Sistema valida:
   ✓ Grupo existe
   ✓ Está en estado Pendiente
   ✓ Despacho NO está cerrado
   ✓ pppcaptura coincide
   ✓ Items son válidos
   ↓
5. En transacción:
   - Elimina items antiguos
   - Crea items nuevos
   - Recalcula fechas de entrega
   ↓
6. Retorna grupo actualizado con nuevo contenido
   ↓
7. Usuario puede:
   - Seguir editando (otro PUT)
   - Autorizar (POST :folio/submit)
   - Declinar (DELETE :folio)
```

## Diferencias con Crear (POST)

| Aspecto          | POST (Crear)                 | PUT (Actualizar)               |
| ---------------- | ---------------------------- | ------------------------------ |
| **Grupo**        | Crea nuevo grupo             | Modifica grupo existente       |
| **Validación**   | No debe existir grupo activo | Debe existir y estar Pendiente |
| **Items**        | Crea items nuevos            | Elimina antiguos, crea nuevos  |
| **pppcaptura**   | Se extrae de DTO             | Debe coincidir con folio       |
| **Folio**        | Se genera nuevo              | Se mantiene el existente       |
| **numCapturo**   | Se toma de DTO o default     | Se mantiene el original        |
| **tiempoCambio** | Timestamp de creación        | Timestamp de actualización     |

## Compatibilidad con Legacy

Este endpoint replica el comportamiento de:

- **PHP**: `actualizarCmotivos.php`

**Lógica Legacy**:

```php
// 1. Consultar cambios existentes
$consultaCambios = "SELECT * FROM CapturaCambios
  WHERE idoperacion = $idop
  AND nud = $nud
  AND FechaCambio = '$fechaO'
  AND estatusDis = 0
  AND pppcaptura = '$ppp'";

// 2. Eliminar cambios antiguos
$consultaCambios = "DELETE FROM CapturaCambios
  WHERE idoperacion = $idop
  AND nud = $nud
  AND FechaCambio = '$fechaO'
  AND estatusDis = 0
  AND pppcaptura='$ppp'";

// 3. Insertar nuevos (se hace en otro flujo)
```

## Notas Técnicas

### Idempotencia

Si se envía el mismo `x-idempotency-key`, la operación:

- Se ejecuta solo una vez
- Retorna el mismo resultado
- No genera duplicados

### Transaccionalidad

La actualización es **atómica**:

- Si falla alguna validación, NO se aplican cambios
- Si falla al crear un item, se hace rollback de todos
- Garantiza consistencia de datos

### Performance

- **DELETE**: Elimina en batch por pppcaptura + fecha
- **INSERT**: Crea en batch dentro de transacción
- **Cálculo de fechas**: Se hace por item (puede ser lento con muchos items)

### Logging

Se registran los siguientes eventos:

- `UPDATE_GROUP_START`: Inicio de actualización
- `DELETE_OLD_ITEMS`: Items eliminados
- `UPDATE_GROUP_SUCCESS`: Actualización completada

## Testing

### Casos de Prueba

1. ✅ **Actualización exitosa**
   - Estado: Pendiente
   - Items válidos
   - pppcaptura coincide

2. ❌ **Grupo no encontrado**
   - Folio inexistente

3. ❌ **Grupo ya autorizado**
   - statusAutorizado = 1

4. ❌ **Despacho cerrado**
   - estatusDis = 1

5. ❌ **pppcaptura no coincide**
   - DTO.pppcaptura != folio.pppcaptura

6. ❌ **Items inválidos**
   - SKU no existe
   - Motivo no existe
   - Cantidad fuera de rango

## Troubleshooting

### Error: "El pppcaptura no coincide"

**Causa**: El `pppcaptura` en el body no coincide con el del folio.

**Solución**: Verificar que:

```
folio = "123-2025-10-30"
       ↓
pppcaptura = 123  (debe coincidir con el del body)
```

### Error: "Grupo ya fue autorizado"

**Causa**: El grupo ya pasó a estado Autorizado o Declinado.

**Solución**: Los grupos autorizados NO se pueden modificar. Si necesitas corregir, debes crear un nuevo grupo.

### Error: "Despacho ya fue cerrado"

**Causa**: El despacho dinámico ya fue cerrado (`estatusDis = 1`).

**Solución**: No se puede modificar después del cierre. Contactar supervisor para reabrir despacho si es crítico.

---

**Versión**: 2.0.0-refactor  
**Fecha**: 2025-01-06  
**Autor**: Equipo de Desarrollo PCM-API
