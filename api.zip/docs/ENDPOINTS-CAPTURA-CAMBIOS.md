# 📋 Endpoints de Captura Cambios - Guía Completa

## 🔐 Autenticación Requerida

**TODOS los endpoints de este módulo requieren autenticación mediante API Key.**

```http
x-api-key: pcm-mobile-app-key-2025
```

### ❌ Error de Autenticación (401)

Si no se proporciona el header o la API Key es inválida:

```json
{
  "statusCode": 401,
  "message": "API Key no proporcionada o inválida",
  "error": "Unauthorized"
}
```

---

## 📑 Índice de Endpoints

| #    | Método   | Ruta             | Descripción                             |
| ---- | -------- | ---------------- | --------------------------------------- |
| 1️⃣   | `GET`    | `/access`        | Verificar elegibilidad de acceso        |
| 2️⃣   | `GET`    | `/catalog`       | Obtener catálogo de productos y motivos |
| 3️⃣   | `POST`   | `/`              | Crear grupo de cambios                  |
| 4️⃣   | `GET`    | `/active`        | Consultar grupo activo                  |
| 🏥   | `GET`    | `/health`        | Health check del servicio               |
| 5️⃣   | `GET`    | `/:folio`        | Obtener grupo por folio                 |
| 5.5️⃣ | `PUT`    | `/:folio`        | Actualizar grupo de cambios             |
| 6️⃣   | `POST`   | `/:folio/submit` | Autorizar grupo (submit)                |
| 7️⃣   | `DELETE` | `/:folio`        | Declinar grupo                          |

---

## 1️⃣ GET /access - Verificar Elegibilidad

**Propósito:** Verificar si una ruta tiene acceso al módulo y detectar grupos activos.

### Request

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/access?idBodega=1&pppcaptura=123" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### Query Parameters

- `idBodega` (number): ID de operación/bodega - **REQUERIDO**
- `pppcaptura` (number): Número de ruta del promotor - **REQUERIDO**

### Responses

#### ✅ 200 - Acceso verificado

```json
{
  "result": {
    "data": {
      "access": true,
      "has_active_ticket": false
    },
    "successful": true,
    "message": "Acceso habilitado al módulo."
  }
}
```

#### ❌ 403 - No elegible

```json
{
  "result": {
    "data": { "access": false },
    "successful": false,
    "errors": {
      "code": "NOT_ELIGIBLE",
      "detail": "El usuario no es elegible para el módulo en esta operación/ruta."
    }
  }
}
```

---

## 2️⃣ GET /catalog - Obtener Catálogo

**Propósito:** Obtener productos y motivos disponibles para captura.

### Request

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/catalog?idBodega=1&pppcaptura=123" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### Query Parameters

- `idBodega` (number): ID de operación/bodega - **REQUERIDO**
- `pppcaptura` (number): Número de ruta del promotor - **REQUERIDO**
- `idMotivo` (number): ID del motivo para filtrar productos - **OPCIONAL**

### JavaScript Example

```javascript
const response = await fetch(
  '/api/v2/captura_cambios/catalog?idBodega=1&pppcaptura=123',
  {
    headers: { 'x-api-key': 'pcm-mobile-app-key-2025' },
  },
);
const { productos, motivos } = (await response.json()).result.data;
```

---

## 3️⃣ POST / - Crear Grupo de Cambios

**Propósito:** Capturar un nuevo grupo de cambios para múltiples clientes.

### Request

```bash
curl -X POST "http://localhost:3000/api/v2/captura_cambios" \
  -H "Content-Type: application/json" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: 550e8400-e29b-41d4-a716-446655440001" \
  -d '{
    "ID_Bodega": 1,
    "pppcaptura": 123,
    "FechaCambio": "2025-11-04",
    "fechaEntrega": "2025-11-06",
    "items": [
      {
        "NUD": "10001",
        "clave_producto": 123456,
        "piezas": 10,
        "id_motivo": 1,
        "justificacion": "Producto vencido"
      }
    ]
  }'
```

### Headers

- `x-api-key`: API Key de autenticación - **REQUERIDO**
- `x-idempotency-key`: UUID para prevenir duplicados - **RECOMENDADO**

### Body Schema

```typescript
{
  ID_Bodega: number; // ID de operación
  pppcaptura: number; // Ruta del promotor
  FechaCambio?: string; // Fecha de captura (opcional, default: HOY)
  fechaEntrega: string; // Fecha de entrega (REQUERIDA, todos los items)
  items: Array<{
    NUD: string; // Cliente
    clave_producto: number; // SKU del producto
    piezas: number; // Cantidad (1-999)
    id_motivo: number; // ID del motivo
    justificacion?: string; // Requerido si piezas > 30
  }>;
}
```

---

## 4️⃣ GET /active - Consultar Grupo Activo

**Propósito:** Verificar si existe un grupo pendiente para evitar duplicados, con filtrado opcional por cliente.

### Request (Grupo completo)

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### Request (Filtrado por cliente)

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### JavaScript Example

```javascript
// Sin filtro - Obtener grupo completo
const response = await fetch(
  '/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1',
  { headers: { 'x-api-key': 'pcm-mobile-app-key-2025' } },
);

if (response.status === 204) {
  console.log('No hay grupo activo');
} else {
  const { result } = await response.json();
  console.log('Grupo completo:', result.data);
}

// Con filtro - Solo items de un cliente específico
const responseFiltered = await fetch(
  '/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001',
  { headers: { 'x-api-key': 'pcm-mobile-app-key-2025' } },
);

if (responseFiltered.status === 204) {
  console.log('No hay items para el cliente 10001');
} else {
  const { result } = await responseFiltered.json();
  console.log('Items del cliente 10001:', result.data.items);
}
```

### Query Parameters

- `pppcaptura` (number): Ruta del promotor - **REQUERIDO**
- `fecha` (string): Fecha en formato YYYY-MM-DD - **REQUERIDO**
- `idoperacion` (number): ID de operación - **REQUERIDO**
- `nud` (string): NUD del cliente - **OPCIONAL**
  - Si se proporciona, solo retorna items de ese cliente
  - Si el grupo existe pero no tiene items del NUD, retorna 204

### Responses

- **200**: Grupo activo encontrado (completo o filtrado por NUD)
- **204**: No hay grupo activo o no hay items para el NUD especificado
- **401**: No autorizado

### Casos de Uso

#### 1. Validar antes de crear grupo nuevo

```javascript
// Verificar si ya existe grupo para esta ruta y fecha
const response = await fetch(
  '/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1',
);

if (response.status === 204) {
  // No existe, permitir crear nuevo grupo
  await crearNuevoGrupo();
} else {
  // Ya existe, mostrar para editar
  const { result } = await response.json();
  alert(`Ya existe grupo ${result.data.folio_virtual}`);
}
```

#### 2. Evitar duplicados por cliente

```javascript
// Antes de agregar item para cliente 10001, verificar si ya tiene
const response = await fetch(
  '/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001',
);

if (response.status === 200) {
  // Cliente ya tiene items en el grupo
  const { result } = await response.json();
  alert(
    `El cliente 10001 ya tiene ${result.data.items_total} items capturados`,
  );
} else {
  // Cliente no tiene items, permitir agregar
  await agregarItemCliente();
}
```

### Response Example (Con filtro por NUD)

```json
{
  "result": {
    "data": {
      "folio_virtual": "123-2025-11-04",
      "pppcaptura": 123,
      "FechaCambio": "2025-11-04",
      "idoperacion": 1,
      "clientes_total": 1,
      "piezas_total": 50,
      "items_total": 2,
      "statusAutorizado": 0,
      "items": [
        {
          "idcambios": 1234,
          "nud": 10001,
          "sku": "PEPSI600",
          "descripcion_producto": "Pepsi 600ml",
          "cantidad": 25,
          "id_motivo": 1,
          "descripcion_motivo": "Producto dañado",
          "fechaEntrega": "2025-11-06"
        },
        {
          "idcambios": 1235,
          "nud": 10001,
          "sku": "MIRINDA2000",
          "descripcion_producto": "Mirinda 2L",
          "cantidad": 25,
          "id_motivo": 1,
          "descripcion_motivo": "Producto dañado",
          "fechaEntrega": "2025-11-06"
        }
      ]
    },
    "successful": true,
    "message": "Grupo activo encontrado con items del cliente 10001."
  }
}
```

---

## 🏥 GET /health - Health Check

**Propósito:** Verificar disponibilidad del servicio.

### Request

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/health" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### Response

```json
{
  "status": "ok",
  "timestamp": "2025-11-04T12:00:00.000Z",
  "service": "captura-cambios-api",
  "version": "2.0.0-refactor"
}
```

---

## 5️⃣ GET /:folio - Obtener Grupo por Folio

**Propósito:** Recuperar detalles completos de un grupo existente.

### Request

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### JavaScript Example

```javascript
const response = await fetch('/api/v2/captura_cambios/123-2025-10-30', {
  headers: { 'x-api-key': 'pcm-mobile-app-key-2025' },
});
const grupo = await response.json();
```

### Path Parameters

- `folio` (string): Folio virtual en formato `{pppcaptura}-{fecha}` - **REQUERIDO**
  - Ejemplo: `123-2025-10-30`

---

## 5.5️⃣ PUT /:folio - Actualizar Grupo de Cambios

**Propósito:** Modificar un grupo de cambios existente mientras esté pendiente.

### Request

```bash
curl -X PUT "http://localhost:3000/api/v2/captura_cambios/123-2025-11-04" \
  -H "Content-Type: application/json" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: $(uuidgen)" \
  -d '{
    "ID_Bodega": 1,
    "pppcaptura": 123,
    "fechaEntrega": "2025-11-06",
    "items": [
      {
        "NUD": "10001",
        "clave_producto": 123456,
        "piezas": 15,
        "id_motivo": 1,
        "justificacion": "Actualización de cantidades"
      }
    ]
  }'
```

### Reglas de Negocio

1. ✅ Solo grupos en estado **Pendiente** (statusAutorizado = 0)
2. ✅ El `pppcaptura` del request debe coincidir con el del grupo
3. ✅ El despacho NO debe estar cerrado (estatusDis ≠ 1)
4. ✅ Se validan TODOS los items nuevamente
5. ⚠️ **ELIMINA todos los items anteriores y crea nuevos**
6. ✅ Mantiene el `numCapturo` original
7. ✅ Actualiza `tiempoCambio` al momento actual

---

## 6️⃣ POST /:folio/submit - Autorizar Grupo

**Propósito:** Aprobar un grupo pendiente para que sea procesado.

### Request

```bash
curl -X POST "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30/submit" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: $(uuidgen)"
```

### JavaScript Example

```javascript
const response = await fetch('/api/v2/captura_cambios/123-2025-10-30/submit', {
  method: 'POST',
  headers: {
    'x-api-key': 'pcm-mobile-app-key-2025',
    'x-idempotency-key': crypto.randomUUID(),
  },
});
```

### Reglas de Negocio

1. Solo grupos con `statusAutorizado = 0` (Pendiente)
2. Cambia estado a `statusAutorizado = 1` (Autorizado)
3. Registra `numAutorizador` y `tiempoAutorizado`
4. Operación **idempotente** (puede reintentarse)

### Responses

- **200**: Grupo autorizado correctamente
- **401**: No autorizado (API Key inválida)
- **404**: Grupo no encontrado
- **409**: Grupo ya autorizado o en estado incompatible

---

## 7️⃣ DELETE /:folio - Declinar Grupo

**Propósito:** Rechazar un grupo pendiente para que NO sea procesado.

### Request

```bash
curl -X DELETE "http://localhost:3000/api/v2/captura_cambios/123-2025-10-30" \
  -H "Content-Type: application/json" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: $(uuidgen)" \
  -d '{"motivo": "Cantidades excesivas sin justificación"}'
```

### JavaScript Example

```javascript
const response = await fetch('/api/v2/captura_cambios/123-2025-10-30', {
  method: 'DELETE',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': 'pcm-mobile-app-key-2025',
    'x-idempotency-key': crypto.randomUUID(),
  },
  body: JSON.stringify({
    motivo: 'Cantidades excesivas sin justificación',
  }),
});
```

### Body Schema

```typescript
{
  motivo?: string;  // Motivo opcional de la declinación
}
```

### Reglas de Negocio

1. Solo grupos con `statusAutorizado = 0` (Pendiente)
2. Cambia estado a `statusAutorizado = 2` (Declinado)
3. Registra el motivo y timestamp
4. Operación **idempotente**

---

## 🔒 Headers Comunes

### x-api-key (REQUERIDO en todos)

```http
x-api-key: pcm-mobile-app-key-2025
```

**Keys disponibles:**

- `pcm-mobile-app-key-2025` - Para aplicación móvil
- `pcm-web-portal-key-2025` - Para portal web
- `pcm-integration-key-2025` - Para integraciones

### x-idempotency-key (RECOMENDADO para POST/PUT/DELETE)

```http
x-idempotency-key: 550e8400-e29b-41d4-a716-446655440001
```

**¿Cómo generarlo?**

```javascript
// JavaScript/Browser
const key = crypto.randomUUID();

// Node.js
const { randomUUID } = require('crypto');
const key = randomUUID();

// Bash/Terminal
uuidgen;
```

**¿Para qué sirve?**

- Prevenir operaciones duplicadas si se reintenta el request
- Asegurar que una operación se ejecute solo una vez
- Evitar doble-captura por problemas de red

---

## 📖 Swagger UI

Para probar los endpoints interactivamente:

```
http://localhost:3000/api
```

**Paso 1:** Haz clic en **"Authorize"** (candado verde arriba a la derecha)

**Paso 2:** Ingresa tu API Key:

```
pcm-mobile-app-key-2025
```

**Paso 3:** Haz clic en **"Authorize"** y luego **"Close"**

**Paso 4:** Todos los endpoints ahora incluirán automáticamente el header `x-api-key` ✅

---

## 🎯 Flujo Completo de Uso

### 1. Verificar Acceso

```javascript
// ¿El promotor tiene acceso?
GET /access?idBodega=1&pppcaptura=123
```

### 2. Obtener Catálogo

```javascript
// ¿Qué productos y motivos están disponibles?
GET /catalog?idBodega=1&pppcaptura=123
```

### 3. Verificar Grupo Activo

```javascript
// ¿Ya existe un grupo pendiente hoy?
GET /active?pppcaptura=123&fecha=2025-10-30&idoperacion=1
```

### 4. Crear o Actualizar Grupo

```javascript
// Si NO existe grupo activo:
POST / + body

// Si existe y quieres modificarlo:
PUT /:folio + body
```

### 5. Consultar Grupo

```javascript
// Ver detalles del grupo capturado
GET / 123 - 2025 - 10 - 30;
```

### 6. Autorizar o Declinar

```javascript
// Aprobar para despacho:
POST / 123 - 2025 - 10 - 30 / submit;

// Rechazar grupo:
DELETE / 123 - 2025 - 10 - 30;
```

---

## ⚠️ Errores Comunes

### 401 Unauthorized

**Causa:** API Key faltante o inválida

**Solución:**

```bash
# ✅ Correcto
curl -H "x-api-key: pcm-mobile-app-key-2025" ...

# ❌ Incorrecto
curl ...  # Falta el header
```

### 409 Conflict

**Causa:** Intentar modificar un grupo ya autorizado o declinado

**Solución:** Solo puedes modificar grupos en estado **Pendiente** (statusAutorizado = 0)

### 422 Unprocessable Entity

**Causa:** Datos inválidos en el body

**Solución:** Verifica:

- Cantidades entre 1-999
- Justificación si piezas > 30
- SKUs y motivos válidos del catálogo
- No duplicar productos en el mismo request

---

## 📚 Documentos Relacionados

- [GUIA-API-COMPLETA.md](./GUIA-API-COMPLETA.md) - Guía técnica detallada
- [ENDPOINT-UPDATE-GROUP.md](./ENDPOINT-UPDATE-GROUP.md) - Detalles del PUT
- [GUIA-USO-API-KEY-SWAGGER.md](./GUIA-USO-API-KEY-SWAGGER.md) - Cómo usar Swagger

---

## ✅ Checklist de Seguridad

- [x] Todos los endpoints requieren `x-api-key`
- [x] Guard `ApiKeyGuard` aplicado a nivel de controlador
- [x] Documentación Swagger completa con headers
- [x] Ejemplos cURL y JavaScript en todos los endpoints
- [x] Response 401 documentado en todos los endpoints
- [x] Idempotency-key recomendado para operaciones de escritura

---

**Última actualización:** 2025-11-04  
**Versión API:** 2.0.0-refactor
