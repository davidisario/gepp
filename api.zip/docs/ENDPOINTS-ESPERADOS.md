# Endpoints Esperados en Swagger

## Total: 10 Endpoints

### Módulo: Captura de Cambios (8 endpoints)

**Controller:** `captura-cambio.controller.ts`  
**Base Path:** `/api/captura_cambios`

1. `GET /api/captura_cambios/access` - Verificar elegibilidad
2. `GET /api/captura_cambios/catalog` - Obtener catálogo
3. `POST /api/captura_cambios` - Crear grupo
4. `GET /api/captura_cambios/active` - Consultar grupo activo
5. `GET /api/captura_cambios/health` - Health check
6. `GET /api/captura_cambios/:folio` - Obtener por folio
7. `POST /api/captura_cambios/:folio/submit` - Autorizar
8. `DELETE /api/captura_cambios/:folio` - Declinar

### Módulo: Catálogos (2 endpoints)

**Controller:** `catalogos.controller.ts`  
**Base Path:** `/api/catalogos`

9. `GET /api/catalogos/operaciones` - Listar operaciones
10. `GET /api/catalogos/rutas` - Listar rutas

---

## Verificación

Si ves menos de 10 endpoints, verifica:

1. **AppModule** - Que `CatalogosModule` esté importado
2. **CatalogosModule** - Que `CatalogosController` esté registrado
3. **Build** - Que no haya errores de compilación
4. **Caché** - Limpia dist y recompila

## Comandos de Verificación

```bash
# 1. Limpiar y compilar
rm -rf dist && npm run build

# 2. Levantar servidor
npm run start:dev

# 3. Verificar endpoints (en otra terminal)
curl -s http://localhost:3000/api/docs-json | jq '.paths | keys | length'

# Debería retornar: 10
```
