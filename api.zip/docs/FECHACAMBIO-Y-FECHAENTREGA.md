# 📅 FechaCambio vs fechaEntrega - Explicación Completa

## 🎯 Resumen Ejecutivo

| Campo            | Tipo                | Descripción                      | ¿Se envía?   | ¿Se calcula?                          |
| ---------------- | ------------------- | -------------------------------- | ------------ | ------------------------------------- |
| **FechaCambio**  | `string` (ISO 8601) | Fecha de **PREVENTA** (captura)  | ✅ Opcional  | ⚠️ Default: HOY                       |
| **fechaEntrega** | `string` (ISO 8601) | Fecha de **ENTREGA** (del grupo) | ✅ Requerido | ❌ NO (se envía en nivel raíz de DTO) |

---

## 📋 FechaCambio - Fecha de Preventa

### ¿Qué es?

**`FechaCambio`** es la **fecha de preventa** o **fecha de captura**, es decir, **el día en que el promotor visita al cliente** y registra los cambios de mercado.

**NO es** la fecha en que se entregará el producto.

### ¿Para qué sirve?

```
┌──────────────────────────────────────────────┐
│  FechaCambio = Fecha de Preventa            │
│  ▼                                           │
│  Promotor visita cliente el 2025-11-04      │
│  y captura: "El cliente quiere cambiar      │
│  12 piezas de 7UP por Pepsi"                │
└──────────────────────────────────────────────┘
```

**Usos principales:**

1. **Agrupar cambios por día:** Todos los cambios capturados el mismo día se agrupan juntos
2. **Generar folio virtual:** `{pppcaptura}-{FechaCambio}` → `123-2025-11-04`
3. **Base para calcular fechaEntrega:** Se suman días hábiles a partir de esta fecha
4. **Validar grupo único:** Solo puede haber UN grupo pendiente por ruta + fecha
5. **Auditoría:** Registra CUÁNDO se capturó el cambio (independiente de cuándo se entregue)

---

## 🚛 fechaEntrega - Fecha de Entrega (Se Envía en el Request)

### ¿Qué es?

**`fechaEntrega`** es la fecha en que **todos los productos del grupo** se entregarán al cliente. **NO se calcula automáticamente**, sino que **se envía en el nivel raíz del request**.

**⚠️ IMPORTANTE:** Todos los items de un mismo grupo comparten la misma `fechaEntrega`. Si necesitas diferentes fechas de entrega, debes crear grupos separados.

### ¿Quién la determina?

El **cliente de la API** (app móvil, sistema web, etc.) es responsable de calcularla según las reglas de negocio:

- ✅ Días hábiles del depósito
- ✅ Tipo de ruta (fija o dinámica)
- ✅ Días de entrega configurados para la ruta

### ¿Cómo se envía?

El campo `fechaEntrega` se incluye en el **nivel raíz del DTO**, no en cada item individual:

**Ejemplo de Request:**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "FechaCambio": "2025-11-04",
  "fechaEntrega": "2025-11-06", // ← NIVEL RAÍZ: Todos los items se entregan esta fecha
  "items": [
    {
      "NUD": "10001",
      "clave_producto": "PEPSI600",
      "id_motivo": 1,
      "piezas": 25,
      "justificacion": "Producto dañado"
    },
    {
      "NUD": "10002",
      "clave_producto": "MIRINDA2000",
      "id_motivo": 1,
      "piezas": 10,
      "justificacion": "Envase roto"
    }
  ]
}
```

**✅ Un grupo = Una fecha de entrega para todos los items**

**Responsabilidad del Cliente:**

El sistema que consume la API (app móvil, web, etc.) debe:

1. Consultar la configuración de la ruta (tipo, días de entrega)
2. Consultar los días hábiles del depósito
3. Calcular la `fechaEntrega` según las reglas de negocio
4. Enviar la fecha calculada **en el nivel raíz** del grupo

---

## 🔄 Flujo Completo - Paso a Paso

### Escenario Real

**Contexto:**

- Promotor de ruta 123 visita cliente el **lunes 4 de noviembre de 2025**
- Cliente quiere cambiar 10 piezas de producto
- La ruta es tipo fijo con **2 días de entrega**
- Depósito: lunes a sábado hábiles (domingo cerrado)

### 1️⃣ Captura

```json
POST /api/v2/captura_cambios
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "FechaCambio": "2025-11-04",  // ← Lunes (día de preventa)
  "items": [
    {
      "NUD": "10001",
      "clave_producto": 100,
      "id_motivo": 1,
      "piezas": 10
    }
  ]
}
```

### 2️⃣ Cliente Determina fechaEntrega

```typescript
// El cliente de la API (app móvil, web, etc.) debe calcular:

// 1. FechaCambio = 2025-11-04 (Lunes - día de captura)
const fechaCambio = new Date('2025-11-04');

// 2. Consultar configuración de ruta
const ruta = await getRuta(123);
// ruta.tipo = 1 (fija)
// ruta.dias = 2

// 3. Calcular fecha base
let fechaEntrega = addDays(fechaCambio, 2);
// fechaEntrega = 2025-11-06 (Miércoles)

// 4. Validar día hábil
const deposito = await getDeposito(1);
// deposito.mie = 1 ✅ (abierto)

// 5. Enviar en el request
const request = {
  ID_Bodega: 1,
  pppcaptura: 123,
  FechaCambio: "2025-11-04",
  items: [{
    NUD: "10001",
    clave_producto: "PEPSI600",
    piezas: 25,
    fechaEntrega: "2025-11-06",  // ← Calculada por el cliente
    ...
  }]
};
```

### 3️⃣ Registro en Base de Datos

```sql
INSERT INTO CapturaCambios (
  idoperacion,
  numCapturo,
  idcambiosmotivos,
  FechaCambio,        -- ← 2025-11-04 (Fecha de CAPTURA)
  cantidad,
  nud,
  fechaEntrega,       -- ← 2025-11-06 (Fecha de ENTREGA calculada)
  horaCaptura,        -- ← 2025-11-04 08:30:00 (Timestamp exacto)
  pppcaptura,
  ...
) VALUES (
  1,
  99999,
  1,
  '2025-11-04',       -- FechaCambio
  10,
  10001,
  '2025-11-06',       -- fechaEntrega (calculada)
  GETDATE(),
  123,
  ...
);
```

### 4️⃣ Response

```json
{
  "result": {
    "data": {
      "folio_virtual": "123-2025-11-04", // ← Usa FechaCambio
      "pppcaptura": 123,
      "FechaCambio": "2025-11-04", // ← Fecha de captura
      "items": [
        {
          "idcambios": 45678,
          "nud": 10001,
          "sku": 100,
          "cantidad": 10,
          "fecha_entrega": "2025-11-06" // ← Fecha calculada
        }
      ]
    }
  }
}
```

---

## 🤔 Preguntas Frecuentes

### ❓ ¿Por qué enviar `FechaCambio` si se puede usar HOY?

**Respuesta:** Por flexibilidad y casos especiales:

1. **Capturas retroactivas:** Promotor captura cambios de ayer

   ```json
   {
     "FechaCambio": "2025-11-03" // Ayer
   }
   ```

2. **Capturas anticipadas:** Promotor captura preventa de mañana

   ```json
   {
     "FechaCambio": "2025-11-05" // Mañana
   }
   ```

3. **Migraciones:** Importar cambios históricos

   ```json
   {
     "FechaCambio": "2025-10-15" // Fecha pasada
   }
   ```

4. **Zona horaria:** Control explícito de la fecha sin depender del servidor
   ```json
   {
     "FechaCambio": "2025-11-04" // ← Explícito
   }
   ```

**Si no se envía:**

```typescript
const fechaCambio = dto.FechaCambio ? new Date(dto.FechaCambio) : new Date(); // ← DEFAULT: HOY
```

---

### ❓ ¿Se puede cambiar `FechaCambio` después de crear el grupo?

**Respuesta:** ❌ **NO**

`FechaCambio` es **inmutable** una vez creado el grupo porque:

1. **Es parte de la clave del grupo:** `{pppcaptura}-{FechaCambio}`
2. **Agrupa cambios:** Todos los cambios de un promotor en un día
3. **Auditoría:** Registra cuándo se capturó originalmente

Si necesitas cambiar la fecha, debes:

1. ❌ Cancelar el grupo existente (`DELETE`)
2. ✅ Crear nuevo grupo con la fecha correcta (`POST`)

---

### ❓ ¿Qué pasa si `FechaCambio` es un día inhábil?

**Respuesta:** ✅ **No hay problema**

`FechaCambio` es la fecha de **captura**, no de entrega. El promotor puede capturar cambios cualquier día (incluso domingo o festivo).

**El cálculo de `fechaEntrega` se ajustará automáticamente:**

```
FechaCambio: 2025-11-09 (Domingo - Depósito cerrado)
       ↓
   Ruta: dias = 2
       ↓
   2025-11-09 + 2 días = 2025-11-11 (Martes)
       ↓
   ¿Es día hábil? ✅ SÍ
       ↓
   fechaEntrega = 2025-11-11
```

---

### ❓ ¿Por qué se llama `FechaCambio` y no `FechaCaptura`?

**Respuesta:** Por **nomenclatura legacy** del sistema PHP.

En el sistema original, todos los campos usan `FechaCambio` para referirse a la fecha de preventa/captura:

```sql
-- Sistema Legacy
SELECT
  FechaCambio,      -- ← Fecha de captura
  fechaEntrega,     -- ← Fecha de entrega
  horaCaptura       -- ← Timestamp de captura
FROM CapturaCambios
```

Para mantener **compatibilidad** con:

- ✅ Base de datos existente
- ✅ Reportes y consultas legacy
- ✅ Integraciones externas

Se mantiene el nombre `FechaCambio`.

---

## 📊 Comparación Lado a Lado

| Aspecto                   | FechaCambio               | fechaEntrega                     |
| ------------------------- | ------------------------- | -------------------------------- |
| **Nombre completo**       | Fecha de Preventa/Captura | Fecha de Entrega al Cliente      |
| **¿Quién lo define?**     | Usuario (o default: HOY)  | Usuario/Cliente de la API        |
| **¿Se envía en request?** | ✅ Opcional               | ✅ Requerido (en cada item)      |
| **¿Se almacena en BD?**   | ✅ SÍ                     | ✅ SÍ                            |
| **¿Puede cambiar?**       | ❌ Inmutable              | ⚠️ Solo si se actualiza el grupo |
| **Formato**               | `YYYY-MM-DD` (string)     | `YYYY-MM-DD` (string)            |
| **Ejemplo**               | `2025-11-04`              | `2025-11-06`                     |
| **Parte del folio**       | ✅ SÍ (`123-2025-11-04`)  | ❌ NO                            |
| **Agrupador**             | ✅ SÍ (ruta + fecha)      | ❌ NO                            |
| **Validación día hábil**  | ❌ NO requerida           | ⚠️ Recomendado (no validado)     |

---

## 🔧 Cálculo de fechaEntrega - Responsabilidad del Cliente

### ⚠️ IMPORTANTE: El Sistema NO Calcula Automáticamente

El sistema **NO** calcula `fechaEntrega`. Es responsabilidad del **cliente de la API** (app móvil, web, etc.) calcularla según las reglas de negocio antes de enviar el request.

### Lógica Recomendada para el Cliente

```typescript
// El cliente debe implementar esta lógica para calcular la fecha de entrega del GRUPO:
async calcularFechaEntrega(
  fechaCambio: Date,      // ← Fecha de captura
  idBodega: number,       // ← Operación
  pppcaptura: number      // ← Ruta
): Promise<string> {

  // 1. Consultar configuración de ruta via API
  const ruta = await fetch(`/api/catalogos/rutas/${pppcaptura}`);

  // 2. Consultar días hábiles del depósito
  const deposito = await fetch(`/api/catalogos/operaciones/${idBodega}/deposito`);

  // 3. Calcular fecha base
  const diasBase = ruta.tipo === 1 ? ruta.dias : ruta.diasEntrega;
  let fechaEntrega = addDays(fechaCambio, diasBase);

  // 4. Ajustar por días inhábiles
  while (!esDiaHabil(fechaEntrega, deposito)) {
    fechaEntrega = addDays(fechaEntrega, 1);
  }

  // 5. Validar día siguiente
  const diaSiguiente = addDays(fechaEntrega, 1);
  if (!esDiaHabil(diaSiguiente, deposito)) {
    fechaEntrega = addDays(fechaEntrega, 1);
  }

  return fechaEntrega.toISOString().split('T')[0]; // "YYYY-MM-DD"
}
```

**⚠️ Nota:** La fecha calculada se aplica a **todos los items del grupo**. Si diferentes clientes requieren fechas distintas, deben crearse grupos separados.

### Endpoints de Apoyo para el Cálculo

El cliente puede usar estos endpoints para obtener la información necesaria:

1. **GET `/api/catalogos/rutas/:pppcaptura`** - Configuración de ruta (días, tipo)
2. **GET `/api/catalogos/operaciones/:idBodega`** - Información del depósito (días hábiles)

### Ejemplo de Implementación en App Móvil

```javascript
// Ejemplo: React Native / Expo
async function crearGrupoCambios(items) {
  // 1. Para cada item, calcular su fechaEntrega
  // 1. Calcular fechaEntrega para el grupo (una sola fecha para todos los items)
  const fechaEntrega = await calcularFechaEntrega(
    new Date(), // HOY (FechaCambio)
    1, // ID_Bodega
    123, // pppcaptura
  );

  // 2. Enviar request con fechaEntrega en el nivel raíz
  const response = await fetch('/api/v2/captura_cambios', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': 'pcm-mobile-app-key-2025',
    },
    body: JSON.stringify({
      ID_Bodega: 1,
      pppcaptura: 123,
      FechaCambio: '2025-11-04',
      fechaEntrega, // ← NIVEL RAÍZ: Aplica a todos los items
      items, // ← Los items NO incluyen fechaEntrega individual
    }),
  });
}
```

---

## 📝 Recomendaciones

### ✅ Buenas Prácticas

1. **Envía `FechaCambio` explícitamente** si:
   - ✅ Capturas retroactivas o anticipadas
   - ✅ Control de zona horaria
   - ✅ Migraciones de datos históricos

2. **Omite `FechaCambio`** si:
   - ✅ Captura en tiempo real (HOY)
   - ✅ Simplificar request

3. **Usa formato ISO 8601:**

   ```json
   "FechaCambio": "2025-11-04"  // ✅ CORRECTO
   "FechaCambio": "04/11/2025"  // ❌ INCORRECTO
   ```

4. **No intentes controlar `fechaEntrega`:**
   ```json
   {
     "FechaCambio": "2025-11-04",
     "fechaEntrega": "2025-11-10" // ❌ No existe, se calcula automáticamente
   }
   ```

### ⚠️ Casos Especiales

#### Cambiar fecha de entrega

Si necesitas que un cambio se entregue en una fecha específica:

✅ **Simplemente envía la fecha deseada:**

```json
{
  "items": [{
    "NUD": "10001",
    "clave_producto": "PEPSI600",
    "piezas": 25,
    "fechaEntrega": "2025-11-10",  // ← Fecha específica que necesitas
    ...
  }]
}
```

El sistema **NO valida** que la fecha sea calculada según las reglas. El cliente tiene total control sobre la `fechaEntrega`.

#### Validar grupo único por fecha

```typescript
// Sistema valida:
const grupoExistente = await buscarGrupo({
  pppcaptura: 123,
  FechaCambio: '2025-11-04',
  statusAutorizado: 0, // Pendiente
});

if (grupoExistente) {
  throw new ConflictException(
    'Ya existe un grupo activo para esta ruta y fecha',
  );
}
```

---

## 🎯 Resumen Final

| Concepto         | Descripción                                              | Valor Ejemplo                         |
| ---------------- | -------------------------------------------------------- | ------------------------------------- |
| **FechaCambio**  | Día que el promotor CAPTURA el cambio                    | `2025-11-04`                          |
| **fechaEntrega** | Día que se ENTREGA el producto al cliente                | `2025-11-06`                          |
| **Relación**     | El cliente calcula según: `FechaCambio + días + ajustes` | Calculada por cliente, no por API     |
| **Control**      | Usuario define AMBOS campos explícitamente               | Ambos son responsabilidad del usuario |
| **Mutabilidad**  | `FechaCambio` inmutable, `fechaEntrega` actualizable     | Fijo vs Actualizable                  |

---

## 📚 Referencias

- **Código Legacy:** `pcm/guardarCmotivos.php` (líneas 119-129)
- **API Service:** `pcm-api/src/modules/captura-cambio/services/captura-cambio.service.ts`
- **Cálculo de fechas:** `pcm-api/src/modules/captura-cambio/services/fecha-entrega.service.ts`
- **Documentación de Contrato:** `pcm-api/CONTRATO-CREAR-GRUPO-CAMBIOS.md`

---

**Última actualización:** 2025-11-04
