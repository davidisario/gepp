# 🔐 Guía de Uso: API Key en Swagger

## 📋 Índice

1. [Acceder a Swagger](#acceder-a-swagger)
2. [Configurar API Key Global](#configurar-api-key-global)
3. [Usar API Key en un Endpoint](#usar-api-key-en-un-endpoint)
4. [Visualizar Headers en Swagger](#visualizar-headers-en-swagger)
5. [Ejemplos de Prueba](#ejemplos-de-prueba)
6. [Troubleshooting](#troubleshooting)

---

## 1. Acceder a Swagger

### Iniciar el Servicio

```bash
cd pcm-api
npm run start:dev
```

### Abrir Swagger UI

Abre en tu navegador:

```
http://localhost:3000/api
```

Deberías ver la interfaz de Swagger con todos los endpoints documentados.

---

## 2. Configurar API Key Global

### Opción A: Configuración Global (Recomendada)

**Paso 1**: En la parte superior derecha de Swagger, busca el botón **"Authorize"** 🔓

**Paso 2**: Haz clic en "Authorize"

**Paso 3**: Se abre un modal con el campo `api-key (apiKey)`

**Paso 4**: Ingresa tu API Key:

```
pcm-mobile-app-key-2025
```

**Paso 5**: Haz clic en **"Authorize"**

**Paso 6**: Cierra el modal

✅ **¡Listo!** Ahora TODOS los endpoints usarán automáticamente esta API Key.

### Visual:

```
┌─────────────────────────────────────────────────┐
│  Swagger UI                      [Authorize 🔓] │
├─────────────────────────────────────────────────┤
│                                                  │
│  Available authorizations                        │
│                                                  │
│  api-key (apiKey)                               │
│  ┌─────────────────────────────────────────┐   │
│  │ pcm-mobile-app-key-2025                 │   │
│  └─────────────────────────────────────────┘   │
│                                                  │
│  [Authorize]  [Close]                           │
└─────────────────────────────────────────────────┘
```

---

## 3. Usar API Key en un Endpoint

### Método 1: Con Autorización Global (Ya Configurada)

Si ya configuraste la API Key globalmente (paso 2), simplemente:

1. Expande el endpoint que quieras probar
2. Haz clic en **"Try it out"**
3. Completa el body/parámetros
4. Haz clic en **"Execute"**

✅ La API Key se envía automáticamente.

### Método 2: Por Endpoint (Sin Autorización Global)

Si NO configuraste la API Key globalmente:

1. Expande el endpoint
2. Haz clic en **"Try it out"**
3. En la sección **"Parameters"**, busca el header `x-api-key`
4. Ingresa tu API Key manualmente:
   ```
   pcm-mobile-app-key-2025
   ```
5. Completa el resto del body/parámetros
6. Haz clic en **"Execute"**

---

## 4. Visualizar Headers en Swagger

### Dónde Ver los Headers

Al expandir un endpoint en Swagger, verás:

```
┌────────────────────────────────────────────────────────┐
│ POST /api/v2/captura_cambios                           │
│ 3️⃣ Crear grupo de cambios                              │
├────────────────────────────────────────────────────────┤
│                                                         │
│ Parameters                                              │
│                                                         │
│ x-api-key * (header)                                   │
│ 🔐 API Key para autenticación (REQUERIDO)              │
│ ┌─────────────────────────────────────────────────┐   │
│ │ pcm-mobile-app-key-2025                         │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│ x-idempotency-key (header)                             │
│ 🔒 UUID para prevenir duplicados (RECOMENDADO)         │
│ ┌─────────────────────────────────────────────────┐   │
│ │ 550e8400-e29b-41d4-a716-446655440001            │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│ Request body                                            │
│ {                                                       │
│   "ID_Bodega": 1,                                      │
│   "NUD": "10001",                                      │
│   ...                                                   │
│ }                                                       │
└────────────────────────────────────────────────────────┘
```

### Información del Header `x-api-key`

Al hacer clic en el header `x-api-key` verás:

```
🔐 API Key para autenticación (REQUERIDO)

Cómo obtenerla:
Contacta al administrador del sistema para obtener tu API Key.

Keys disponibles por defecto:
- pcm-mobile-app-key-2025 - Para app móvil
- pcm-web-portal-key-2025 - Para portal web
- pcm-integration-key-2025 - Para integraciones

Ejemplo de uso:
x-api-key: pcm-mobile-app-key-2025
```

### Información del Header `x-idempotency-key`

```
🔒 UUID para prevenir operaciones duplicadas (RECOMENDADO)

¿Qué es?
Identificador único que garantiza que si envías la misma petición dos veces,
solo se procesa una vez.

¿Cómo generarlo?

JavaScript/TypeScript:
const idempotencyKey = crypto.randomUUID();
// Ejemplo: "550e8400-e29b-41d4-a716-446655440001"

Python:
import uuid
idempotency_key = str(uuid.uuid4())

Bash/cURL:
IDEMPOTENCY_KEY=$(uuidgen)
```

---

## 5. Ejemplos de Prueba

### Ejemplo 1: Crear Grupo de Cambios

**Endpoint**: `POST /api/v2/captura_cambios`

**Pasos en Swagger:**

1. Expandir el endpoint **"3️⃣ Crear grupo de cambios"**
2. Clic en **"Try it out"**
3. Verificar que `x-api-key` tenga valor (o usar autorización global)
4. (Opcional) Generar UUID para `x-idempotency-key`:
   - Puedes usar: https://www.uuidgenerator.net/
   - O dejar el ejemplo: `550e8400-e29b-41d4-a716-446655440001`
5. Editar el Request Body:

```json
{
  "ID_Bodega": 1,
  "NUD": "10001",
  "pppcaptura": 123,
  "FechaCambio": "2025-01-06",
  "items": [
    {
      "clave_producto": "PEPSI600",
      "id_motivo": 1,
      "piezas": 25,
      "justificacion": "Producto dañado en transporte"
    }
  ]
}
```

6. Clic en **"Execute"**

**Respuesta Esperada (201 Created):**

```json
{
  "result": {
    "data": {
      "folio_virtual": "123-2025-01-06",
      "pppcaptura": 123,
      "FechaCambio": "2025-01-06",
      "idoperacion": 1,
      "clientes_total": 1,
      "piezas_total": 25,
      "items_total": 1,
      "statusAutorizado": 0,
      "fecha_creacion": "2025-01-06T10:30:00Z",
      "items": [...]
    },
    "successful": true,
    "message": "Grupo de cambios creado correctamente."
  }
}
```

### Ejemplo 2: Actualizar Grupo

**Endpoint**: `PUT /api/v2/captura_cambios/{folio}`

**Pasos en Swagger:**

1. Expandir el endpoint **"5.5️⃣ Actualizar grupo de cambios"**
2. Clic en **"Try it out"**
3. Ingresar folio: `123-2025-01-06` (del grupo que creaste antes)
4. Verificar headers (api-key, idempotency-key)
5. Editar Request Body:

```json
{
  "NUD": "10001",
  "pppcaptura": 123,
  "ID_Bodega": 1,
  "items": [
    {
      "clave_producto": "PEPSI600",
      "id_motivo": 1,
      "piezas": 30,
      "justificacion": "Corrección: eran 30, no 25"
    }
  ]
}
```

6. Clic en **"Execute"**

### Ejemplo 3: Consultar Grupo

**Endpoint**: `GET /api/v2/captura_cambios/{folio}`

**Pasos en Swagger:**

1. Expandir el endpoint **"5️⃣ Obtener grupo por folio virtual"**
2. Clic en **"Try it out"**
3. Ingresar folio: `123-2025-01-06`
4. Clic en **"Execute"**

✅ **No necesita idempotency-key** (solo lectura)

---

## 6. Troubleshooting

### Error 401: Unauthorized

**Síntoma:**

```json
{
  "statusCode": 401,
  "message": "API Key no proporcionada o inválida",
  "error": "Unauthorized"
}
```

**Solución:**

1. Verifica que ingresaste la API Key
2. Revisa que la API Key sea correcta: `pcm-mobile-app-key-2025`
3. Si usaste autorización global, verifica que el candado 🔒 esté cerrado en la esquina superior derecha

### La API Key No Aparece en el Request

**Síntoma:**
En la sección "Request headers" no aparece `x-api-key`

**Solución:**

1. Haz clic en **"Authorize"** en la parte superior
2. Configura la API Key
3. Haz clic en **"Authorize"** dentro del modal
4. Cierra el modal
5. Vuelve a ejecutar el request

### Error: "API Key inválida"

**Solución:**
Verifica que estés usando una de las keys válidas:

- `pcm-mobile-app-key-2025`
- `pcm-web-portal-key-2025`
- `pcm-integration-key-2025`

### No Puedo Generar UUID para Idempotency Key

**Soluciones:**

1. **Online**: https://www.uuidgenerator.net/
2. **Consola del navegador** (F12):
   ```javascript
   crypto.randomUUID();
   ```
3. **Terminal Mac/Linux**:
   ```bash
   uuidgen
   ```
4. **Python**:
   ```bash
   python3 -c "import uuid; print(uuid.uuid4())"
   ```
5. **Usar el ejemplo**: `550e8400-e29b-41d4-a716-446655440001`

---

## 📸 Capturas Visuales

### 1. Botón Authorize

```
┌────────────────────────────────────────────────┐
│  pcm-api v2.0.1           [Authorize 🔓]       │
└────────────────────────────────────────────────┘
                                    ↑
                              Haz clic aquí
```

### 2. Modal de Autorización

```
┌─────────────────────────────────────────────────┐
│  Available authorizations                        │
│                                                  │
│  api-key (apiKey)                               │
│  Name: x-api-key                                │
│  In: header                                      │
│                                                  │
│  Value:                                         │
│  ┌─────────────────────────────────────────┐   │
│  │ pcm-mobile-app-key-2025           ←     │   │
│  └─────────────────────────────────────────┘   │
│                                     Ingresa aquí│
│                                                  │
│  [Authorize]  [Close]                           │
└─────────────────────────────────────────────────┘
```

### 3. Endpoint con Headers Visibles

```
POST /api/v2/captura_cambios

Parameters

▼ x-api-key * string (header)
  🔐 API Key para autenticación (REQUERIDO)
  [pcm-mobile-app-key-2025                    ]
                                               ↑
                                     Se completa automáticamente
                                     si usaste Authorize

▼ x-idempotency-key string (header)
  🔒 UUID para prevenir duplicados
  [550e8400-e29b-41d4-a716-446655440001       ]

▼ Request body * application/json
  {
    "ID_Bodega": 1,
    "NUD": "10001",
    ...
  }

[Execute]
```

---

## 🎯 Checklist Rápido

Antes de ejecutar un endpoint en Swagger:

- [ ] Servicio corriendo (`npm run start:dev`)
- [ ] Swagger abierto en `http://localhost:3000/api`
- [ ] API Key configurada (botón Authorize) ✅
- [ ] Endpoint expandido
- [ ] "Try it out" activado
- [ ] Headers verificados (x-api-key presente)
- [ ] Body/parámetros completados
- [ ] Presionar "Execute"

---

## 📚 Referencias

- **API Keys Disponibles**: Ver `src/config/apikey.config.ts`
- **Documentación Endpoints**: Ver archivos `ENDPOINT-*.md`
- **Swagger Official Docs**: https://swagger.io/docs/

---

## 🆘 Soporte

Si tienes problemas con la autenticación:

1. Verifica que el servicio esté corriendo
2. Revisa los logs en la consola del servidor
3. Contacta al equipo de desarrollo

---

**Versión**: 2.0.0  
**Última Actualización**: 2025-01-06  
**Autor**: Equipo PCM-API
