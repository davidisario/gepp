# 🔐 numCapturo y API Keys - Guía Técnica

## 📋 Resumen Ejecutivo

**`numCapturo`** es el número de empleado que **captura/crea** un grupo de cambios. A partir de la versión 2.0.1, este valor **se obtiene automáticamente de la API Key** y **NO** debe enviarse en el request body.

---

## 🎯 ¿Qué es numCapturo?

| Aspecto                 | Descripción                                |
| ----------------------- | ------------------------------------------ |
| **Nombre**              | `numCapturo`                               |
| **Tipo**                | `int` (número entero)                      |
| **Tabla BD**            | `CapturaCambios`                           |
| **Propósito**           | Identificar quién creó/capturó el registro |
| **Se envía en Request** | ❌ NO (se obtiene de API Key)              |
| **Se modifica**         | ❌ NO (se mantiene el original)            |

---

## 🔄 Flujo Actual (v2.0.1)

```
Usuario hace request con API Key
         ↓
x-api-key: a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d
         ↓
ApiKeyGuard valida el key
         ↓
Extrae datos de la configuración:
  - name: "GEPP Service"
  - userId: 99999  ← Este es el numCapturo
  - permissions: [...]
         ↓
Inyecta apiKeyData en el request
         ↓
Controller recibe:
  @CurrentApiKey() apiKeyData: ApiKeyData
         ↓
Service usa:
  numCapturo: apiKeyData.userId  // 99999
         ↓
Se guarda en BD:
  CapturaCambios.numCapturo = 99999
```

---

## 📦 Request Body (NUEVO)

### ❌ INCORRECTO (Ya NO se hace así)

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "numCapturo": 99999,  // ❌ NO enviar este campo
  "items": [...]
}
```

### ✅ CORRECTO (Versión actual)

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "items": [...]
}
```

**Headers requeridos:**

```http
x-api-key: a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d
```

El sistema **automáticamente** asigna `numCapturo = 99999` según la API Key.

---

## 🔑 Configuración de API Keys

### Archivo: `src/config/apikey.config.ts`

```typescript
keys: [
  {
    key: 'a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d',
    name: 'GEPP Service',
    description: 'API Key para servicio GEPP',
    permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
    userId: 99999, // ← numCapturo para esta key
    idoperacion: 1,
    nivel: 4,
  },
  {
    key: 'f1e2d3c4-b5a6-4978-8c6d-5e4f3a2b1c0d',
    name: 'External Service',
    description: 'API Key para servicio externo',
    permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
    userId: 88888, // ← Diferente userId
    idoperacion: 1,
    nivel: 4,
  },
  {
    key: 'b2c3d4e5-f6a7-4b8c-9d0e-1f2a3b4c5d6e',
    name: 'Development Service',
    description: 'API Key para desarrollo y testing',
    permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
    userId: 77777, // ← userId de desarrollo
    idoperacion: 1,
    nivel: 4,
  },
];
```

---

## 🔍 Interface ApiKeyData

### Archivo: `src/common/interfaces/api-key-data.interface.ts`

```typescript
export interface ApiKeyData {
  key: string;
  name: string;
  description: string;
  permissions: string[];
  userId: number; // ← NUEVO: numCapturo asociado a esta key
  idoperacion?: number;
  nivel?: number;
}
```

---

## 💻 Uso en el Código

### Controller

```typescript
@Post()
async createCambios(
  @Body() dto: CreateCambioDTO,
  @CurrentApiKey() apiKeyData: ApiKeyData,  // ← Decorador inyecta datos
  @Headers('x-idempotency-key') idempotencyKey?: string,
): Promise<ApiResponseType> {
  const grupo = await this.capturaCambioService.createCambios(
    dto,
    apiKeyData,  // ← Se pasa al servicio
    idempotencyKey,
  );

  return {
    result: {
      data: grupo,
      successful: true,
      message: 'Grupo de cambios creado correctamente.',
    },
  };
}
```

### Service

```typescript
async createCambios(
  dto: CreateCambioDTO,
  apiKeyData: ApiKeyData,  // ← Recibe datos de la key
  idempotencyKey?: string,
): Promise<CambioGroupResponseDTO> {

  // ... validaciones ...

  await this.dataSource.transaction(async (manager) => {
    for (const item of dto.items) {
      const cambio = manager.create(CapturaCambio, {
        idoperacion: dto.ID_Bodega,
        numCapturo: apiKeyData.userId,  // ← Usa userId de la API Key
        idcambiosmotivos: item.id_motivo,
        // ... más campos ...
      });

      await manager.save(cambio);
    }
  });

  // ...
}
```

---

## 📊 Tabla de Mapeo

| API Key       | name                | userId (numCapturo) | Uso típico             |
| ------------- | ------------------- | ------------------- | ---------------------- |
| `a1b2c3d4...` | GEPP Service        | 99999               | Promotor principal     |
| `f1e2d3c4...` | External Service    | 88888               | Integraciones externas |
| `b2c3d4e5...` | Development Service | 77777               | Testing y desarrollo   |

---

## 🔄 Actualización (PUT) - Mantiene Original

Cuando se **actualiza** un grupo existente, el `numCapturo` **NO cambia**:

```typescript
// En updateGroup service
const cambio = manager.create(CapturaCambio, {
  idoperacion: dto.ID_Bodega,
  numCapturo: cambiosExistentes[0].numCapturo, // ✅ Mantiene el original
  // ... resto de campos actualizados ...
  tiempoCambio: new Date(), // ✅ Actualiza timestamp
});
```

**Resultado:**

- `numCapturo` = 99999 (el que creó originalmente)
- `tiempoCambio` = 2025-11-04 15:30:00 (actualizado)

---

## 🆚 numCapturo vs numAutorizador

| Campo            | ¿Quién?                 | ¿Cuándo?                   | Origen                             |
| ---------------- | ----------------------- | -------------------------- | ---------------------------------- |
| `numCapturo`     | Promotor que CAPTURA    | Al crear (POST)            | API Key → `userId`                 |
| `numAutorizador` | Supervisor que AUTORIZA | Al autorizar (POST submit) | API Key → `userId` del autorizador |

**Ejemplo:**

```sql
-- Después de crear
INSERT INTO CapturaCambios (
  numCapturo,      -- 99999 (de API Key del promotor)
  numAutorizador,  -- NULL (aún no autorizado)
  ...
)

-- Después de autorizar (submit)
UPDATE CapturaCambios
SET
  numAutorizador = 88888,  -- De API Key del supervisor
  statusAutorizado = 1,
  tiempoAutorizado = GETDATE()
WHERE ...
```

---

## 📝 Swagger/OpenAPI

La documentación Swagger **NO muestra** el campo `numCapturo` en el request body porque:

1. ✅ No está en el DTO
2. ✅ Se calcula automáticamente
3. ✅ El usuario no debe enviarlo

**Documentación del header:**

```typescript
@ApiHeader({
  name: 'x-api-key',
  description: '🔐 API Key para autenticación (REQUERIDO). El userId asociado se usará como numCapturo.',
  required: true,
  schema: {
    type: 'string',
    format: 'uuid',
    default: 'a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d',
  },
})
```

---

## 🎯 Validaciones

### ✅ Validación Automática

El sistema valida que:

1. ✅ La API Key sea válida (UUID formato correcto)
2. ✅ La API Key exista en la configuración
3. ✅ La API Key tenga `userId` definido

### ❌ Errores Comunes

**Error 1: API Key sin userId**

```typescript
// ❌ Configuración incorrecta
{
  key: 'abc-123...',
  name: 'Test Key',
  // userId: ???  ← Falta userId
}

// Error al crear cambio:
// TypeError: Cannot read property 'userId' of undefined
```

**Solución:** Asegurar que TODAS las API Keys tengan `userId` definido.

---

## 🔧 Migración desde Versión Anterior

### Cambios Necesarios

#### 1. Actualizar Requests

**Antes (v2.0.0):**

```json
{
  "ID_Bodega": 1,
  "numCapturo": 99999,  // Se enviaba
  "pppcaptura": 123,
  "items": [...]
}
```

**Ahora (v2.0.1):**

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,  // numCapturo NO se envía
  "items": [...]
}
```

#### 2. Configurar API Keys

Agregar `userId` a cada API Key en `apikey.config.ts`:

```typescript
{
  key: '...',
  name: '...',
  userId: 99999,  // ← NUEVO campo requerido
  // ...
}
```

#### 3. Sin Cambios en BD

La tabla `CapturaCambios` **NO cambia**. El campo `numCapturo` sigue existiendo y funcionando igual.

---

## 📚 Beneficios del Cambio

### 🎯 Seguridad

✅ No se puede falsificar el `numCapturo` en el request  
✅ Autenticación y trazabilidad unificadas  
✅ Cada API Key tiene un usuario asociado único

### 🔧 Simplicidad

✅ Menos campos en el request  
✅ Menos validaciones manuales  
✅ Automático y consistente

### 📊 Auditoría

✅ Trazabilidad clara: API Key → userId → numCapturo  
✅ Imposible que un usuario suplante a otro  
✅ Log completo de acciones por API Key

---

## 🔍 Ejemplo de Auditoría

```sql
-- Ver quién capturó qué
SELECT
  cc.numCapturo,
  COUNT(*) as total_cambios,
  SUM(cc.cantidad) as total_piezas,
  MIN(cc.horaCaptura) as primer_cambio,
  MAX(cc.horaCaptura) as ultimo_cambio
FROM CapturaCambios cc
WHERE cc.FechaCambio >= '2025-11-01'
GROUP BY cc.numCapturo
ORDER BY total_cambios DESC
```

**Resultado:**

| numCapturo | total_cambios | total_piezas | primer_cambio       | ultimo_cambio       |
| ---------- | ------------- | ------------ | ------------------- | ------------------- |
| 99999      | 150           | 3,250        | 2025-11-01 08:00:00 | 2025-11-04 17:30:00 |
| 88888      | 85            | 1,800        | 2025-11-01 09:15:00 | 2025-11-04 16:45:00 |
| 77777      | 12            | 200          | 2025-11-03 10:00:00 | 2025-11-03 11:30:00 |

---

## 🚀 Testing

### Ejemplo de Test

```typescript
describe('CreateCambios with API Key userId', () => {
  it('should use userId from API Key as numCapturo', async () => {
    // Arrange
    const apiKeyData: ApiKeyData = {
      key: 'test-key',
      name: 'Test Service',
      description: 'Testing',
      permissions: [],
      userId: 99999, // ← userId de la key
      idoperacion: 1,
      nivel: 4,
    };

    const dto: CreateCambioDTO = {
      ID_Bodega: 1,
      pppcaptura: 123,
      items: [
        {
          NUD: '10001',
          clave_producto: 123456,
          id_motivo: 1,
          piezas: 10,
        },
      ],
    };

    // Act
    const result = await service.createCambios(dto, apiKeyData);

    // Assert
    const savedCambio = await repository.findOne({
      where: { pppcaptura: 123 },
    });

    expect(savedCambio.numCapturo).toBe(99999); // ✅ Del API Key
  });
});
```

---

## 📖 Referencias

### Archivos Modificados

| Archivo                                                         | Cambio                       |
| --------------------------------------------------------------- | ---------------------------- |
| `src/common/interfaces/api-key-data.interface.ts`               | Agregado `userId: number`    |
| `src/config/apikey.config.ts`                                   | Agregado `userId` a cada key |
| `src/modules/captura-cambio/dto/create-cambio.dto.ts`           | Eliminado `numCapturo`       |
| `src/modules/captura-cambio/services/captura-cambio.service.ts` | Usa `apiKeyData.userId`      |

### Documentación Relacionada

- [CONTRATO-CREAR-GRUPO-CAMBIOS.md](./CONTRATO-CREAR-GRUPO-CAMBIOS.md) - Actualizado
- [ENDPOINTS-CAPTURA-CAMBIOS.md](./ENDPOINTS-CAPTURA-CAMBIOS.md) - Referencia completa
- [GUIA-USO-API-KEY-SWAGGER.md](./GUIA-USO-API-KEY-SWAGGER.md) - Uso en Swagger

---

## ❓ FAQ

### ¿Puedo enviar numCapturo en el body?

❌ NO. El campo ya no está en el DTO y será ignorado si se envía.

### ¿Cómo sé qué numCapturo tendrá mi cambio?

✅ Depende de la API Key que uses. Ver tabla de mapeo arriba.

### ¿Se puede cambiar el numCapturo después de crear?

❌ NO. Se mantiene siempre el original, incluso al actualizar (PUT).

### ¿Qué pasa si mi API Key no tiene userId?

❌ Error en tiempo de ejecución. Todas las keys DEBEN tener `userId`.

### ¿Los grupos antiguos siguen funcionando?

✅ SÍ. Los registros existentes en BD no cambian. Solo afecta a nuevos cambios.

---

**Última actualización:** 2025-11-04  
**Versión API:** 2.0.1  
**Autor:** Equipo Técnico GEPP/Draweb
