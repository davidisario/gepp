# 📄 Exportación OpenAPI - Captura de Cambios

## 🎯 Descripción

Este directorio contiene la especificación OpenAPI 3.0 completa para todos los endpoints del módulo de **Captura de Cambios**.

## 📁 Archivos

### `openapi-captura-cambios.json`

Especificación OpenAPI 3.0.3 en formato JSON que incluye:

✅ **9 Endpoints completos:**

1. `GET /captura_cambios/access` - Verificar acceso
2. `GET /captura_cambios/catalog` - Obtener catálogo
3. `POST /captura_cambios` - Crear grupo de cambios
4. `GET /captura_cambios/active` - Consultar grupo activo
5. `GET /captura_cambios/health` - Health check
6. `GET /captura_cambios/{folio}` - Obtener grupo por folio
7. `PUT /captura_cambios/{folio}` - Actualizar grupo
8. `POST /captura_cambios/{folio}/submit` - Autorizar grupo
9. `DELETE /captura_cambios/{folio}` - Eliminar grupo

✅ **Todos los Schemas (DTOs):**

- `CreateCambioDTO` / `CambioItemDTO`
- `UpdateCambioDTO` / `UpdateCambioItemDTO`
- `CambioGroupResponse` / `CambioItemResponse`
- `AccessResponse`
- `CatalogResponse`
- `ErrorResponse` / `ValidationErrorResponse`
- Y más...

✅ **Seguridad configurada:**

- API Key authentication (`x-api-key` header)
- Ejemplos de keys disponibles

✅ **Ejemplos completos:**

- Request bodies con casos de uso reales
- Response bodies con datos de ejemplo
- Múltiples ejemplos por endpoint

---

## 🚀 Cómo Usar

### 1. Importar en Swagger UI

```bash
# Opción A: Usar Swagger Editor online
https://editor.swagger.io/

# Opción B: Usar Swagger UI local
docker run -p 8080:8080 -e SWAGGER_JSON=/openapi-captura-cambios.json \
  -v $(pwd):/usr/share/nginx/html swaggerapi/swagger-ui
```

### 2. Importar en Postman

1. Abrir Postman
2. Click en **Import**
3. Seleccionar el archivo `openapi-captura-cambios.json`
4. Postman creará automáticamente:
   - Una colección con todos los endpoints
   - Variables de entorno
   - Ejemplos de request/response
   - Documentación integrada

### 3. Importar en Insomnia

1. Abrir Insomnia
2. Click en **Create** → **Import From** → **File**
3. Seleccionar `openapi-captura-cambios.json`
4. Insomnia generará todos los requests automáticamente

### 4. Generar código cliente

Puedes generar SDKs en cualquier lenguaje usando herramientas como:

```bash
# Instalar OpenAPI Generator
npm install @openapitools/openapi-generator-cli -g

# Generar cliente TypeScript
openapi-generator-cli generate \
  -i openapi-captura-cambios.json \
  -g typescript-axios \
  -o ./client-typescript

# Generar cliente Python
openapi-generator-cli generate \
  -i openapi-captura-cambios.json \
  -g python \
  -o ./client-python

# Generar cliente Java
openapi-generator-cli generate \
  -i openapi-captura-cambios.json \
  -g java \
  -o ./client-java
```

### 5. Validar el archivo

```bash
# Instalar swagger-cli
npm install -g @apidevtools/swagger-cli

# Validar el archivo OpenAPI
swagger-cli validate openapi-captura-cambios.json
```

---

## 🔑 Configuración de API Keys

El archivo incluye la configuración de seguridad con las siguientes API Keys predefinidas:

| API Key                     | Descripción  | Usuario ID |
| --------------------------- | ------------ | ---------- |
| `pcm-mobile-app-key-2025`   | App móvil    | 99999      |
| `pcm-web-portal-key-2025`   | Portal web   | 88888      |
| `pcm-admin-portal-key-2025` | Portal admin | 77777      |

**Cómo usar:**

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/catalog?idBodega=1&pppcaptura=123" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

---

## 📊 Estructura del Archivo

```json
{
  "openapi": "3.0.3",
  "info": { ... },
  "servers": [ ... ],
  "tags": [ ... ],
  "paths": {
    "/captura_cambios/access": { ... },
    "/captura_cambios/catalog": { ... },
    "/captura_cambios": { ... },
    "/captura_cambios/active": { ... },
    "/captura_cambios/health": { ... },
    "/captura_cambios/{folio}": { ... },
    "/captura_cambios/{folio}/submit": { ... }
  },
  "components": {
    "securitySchemes": { ... },
    "schemas": { ... },
    "responses": { ... }
  }
}
```

---

## 🎨 Ejemplos de Uso

### Ejemplo 1: Crear grupo de cambios

```bash
curl -X POST "http://localhost:3000/api/v2/captura_cambios" \
  -H "Content-Type: application/json" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: $(uuidgen)" \
  -d '{
    "ID_Bodega": 1,
    "pppcaptura": 123,
    "FechaCambio": "2025-11-04",
    "fechaEntrega": "2025-11-06",
    "items": [
      {
        "NUD": "10001",
        "clave_producto": "PEPSI600",
        "id_motivo": 1,
        "piezas": 25,
        "justificacion": "Producto dañado"
      }
    ]
  }'
```

### Ejemplo 2: Consultar grupo activo

```bash
curl -X GET "http://localhost:3000/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1" \
  -H "x-api-key: pcm-mobile-app-key-2025"
```

### Ejemplo 3: Actualizar grupo

```bash
curl -X PUT "http://localhost:3000/api/v2/captura_cambios/123-2025-11-04" \
  -H "Content-Type: application/json" \
  -H "x-api-key: pcm-mobile-app-key-2025" \
  -H "x-idempotency-key: $(uuidgen)" \
  -d '{
    "pppcaptura": 123,
    "ID_Bodega": 1,
    "fechaEntrega": "2025-11-06",
    "items": [
      {
        "NUD": "10001",
        "clave_producto": "PEPSI600",
        "id_motivo": 1,
        "piezas": 30,
        "justificacion": "Corrección de cantidad"
      }
    ]
  }'
```

---

## 🔧 Personalización

### Cambiar URLs de servidor

Edita la sección `servers` en el archivo JSON:

```json
"servers": [
  {
    "url": "https://tu-servidor.com/api/v2",
    "description": "Tu Servidor"
  }
]
```

### Agregar autenticación adicional

Si necesitas agregar OAuth2, JWT u otro método:

```json
"components": {
  "securitySchemes": {
    "ApiKeyAuth": { ... },
    "OAuth2": {
      "type": "oauth2",
      "flows": { ... }
    }
  }
}
```

---

## 📝 Validación del Schema

El archivo cumple con:

- ✅ OpenAPI 3.0.3 specification
- ✅ Todos los endpoints documentados
- ✅ Schemas con validaciones (required, min, max, format)
- ✅ Ejemplos en request/response bodies
- ✅ Códigos de error HTTP estándar
- ✅ Security schemes configurados
- ✅ Tags organizados por módulo

---

## 🆘 Soporte

Para más información sobre:

- **OpenAPI Specification:** https://swagger.io/specification/
- **Swagger Editor:** https://editor.swagger.io/
- **OpenAPI Generator:** https://openapi-generator.tech/
- **Documentación del API:** Ver archivos `*.md` en este directorio

---

## 📌 Notas Importantes

1. **Idempotency Keys:**
   - Recomendado para operaciones POST/PUT/DELETE
   - Usar UUIDs únicos por operación
   - Formato: `550e8400-e29b-41d4-a716-446655440001`

2. **Fecha de Entrega:**
   - Se envía en el **nivel raíz** del DTO
   - Todos los items del grupo comparten la misma fecha
   - Formato: `YYYY-MM-DD` (ISO 8601)

3. **Validaciones:**
   - Cantidad de items: 1-50 por grupo
   - Piezas por item: 1-999
   - Justificación requerida si piezas > 30

4. **Estados del Grupo:**
   - `0` - Pendiente (puede editarse)
   - `1` - Autorizado (no puede editarse)
   - `2` - Declinado (no puede editarse)

---

## 🔄 Versionado

- **Versión actual:** 2.0.1
- **Fecha de última actualización:** 2025-11-05
- **Cambios recientes:**
  - ✅ `fechaEntrega` movida al nivel raíz del DTO
  - ✅ Agregado filtrado por NUD en `/active`
  - ✅ Todos los endpoints usan `x-api-key`
  - ✅ `numCapturo` se obtiene de la API Key

---

¿Necesitas ayuda? Revisa la documentación completa en los archivos:

- `ENDPOINTS-CAPTURA-CAMBIOS.md`
- `CONTRATO-CREAR-GRUPO-CAMBIOS.md`
- `FECHACAMBIO-Y-FECHAENTREGA.md`
- `PPPCAPTURA-Y-NUD.md`
