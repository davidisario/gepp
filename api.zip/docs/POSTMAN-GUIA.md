# 📮 Guía de Uso - Colección Postman

## 🎯 Archivos Incluidos

Este directorio contiene una colección completa de Postman lista para importar:

| Archivo                                   | Descripción                          |
| ----------------------------------------- | ------------------------------------ |
| `postman-collection-captura-cambios.json` | Colección con 9 endpoints + ejemplos |
| `postman-environment-dev.json`            | Variables de entorno para desarrollo |
| `postman-environment-prod.json`           | Variables de entorno para producción |

---

## 🚀 Instalación Rápida

### Paso 1: Importar Colección

1. Abre **Postman**
2. Click en **Import** (esquina superior izquierda)
3. Selecciona **File** → `postman-collection-captura-cambios.json`
4. Click **Import**

✅ La colección aparecerá en tu sidebar con 9 endpoints listos para usar

### Paso 2: Importar Entorno

1. En Postman, click en **Environments** (icono de engranaje arriba a la derecha)
2. Click **Import**
3. Selecciona **File** → `postman-environment-dev.json`
4. Click **Import**
5. Repite para `postman-environment-prod.json` (opcional)

### Paso 3: Activar Entorno

1. En la esquina superior derecha, selecciona el dropdown de entornos
2. Elige **"Captura Cambios - Development"**
3. ✅ ¡Listo para probar!

---

## 📋 Endpoints Incluidos

La colección incluye todos los endpoints del módulo:

1. **1️⃣ Verificar Acceso** - `GET /access`
2. **2️⃣ Obtener Catálogo** - `GET /catalog`
3. **3️⃣ Crear Grupo de Cambios** - `POST /`
4. **4️⃣ Consultar Grupo Activo** - `GET /active`
5. **5️⃣ Obtener Grupo por Folio** - `GET /:folio`
6. **5.5️⃣ Actualizar Grupo** - `PUT /:folio`
7. **6️⃣ Autorizar Grupo** - `POST /:folio/submit`
8. **7️⃣ Eliminar Grupo** - `DELETE /:folio`
9. **🏥 Health Check** - `GET /health`

---

## 🔑 Variables de Entorno

Cada entorno incluye las siguientes variables:

| Variable         | Descripción                            | Ejemplo                        |
| ---------------- | -------------------------------------- | ------------------------------ |
| `baseUrl`        | URL base del API                       | `http://localhost:3000/api/v2` |
| `apiKey`         | API Key para autenticación             | `pcm-mobile-app-key-2025`      |
| `idBodega`       | ID de bodega/operación                 | `1`                            |
| `pppcaptura`     | Número de ruta                         | `123`                          |
| `folioVirtual`   | Folio del grupo (auto-generado)        | `123-2025-11-04`               |
| `idempotencyKey` | UUID para idempotencia (auto-generado) | `550e8400-...`                 |

### Variables Auto-Generadas

La colección incluye **scripts automáticos** que generan:

- ✅ `idempotencyKey` - Se genera un UUID nuevo antes de cada POST/PUT/DELETE
- ✅ `folioVirtual` - Se guarda automáticamente después de crear un grupo

---

## 🎭 Ejemplos de Respuestas

Cada endpoint incluye **múltiples ejemplos** de respuestas:

### ✅ Respuestas Exitosas

- **200 OK** - Operación exitosa
- **201 Created** - Grupo creado
- **204 No Content** - No hay grupo activo

### ❌ Respuestas de Error

- **400 Bad Request** - Error de validación
- **401 Unauthorized** - API Key inválida
- **403 Forbidden** - Usuario no elegible
- **404 Not Found** - Recurso no encontrado
- **409 Conflict** - Grupo ya existe o ya fue autorizado

**Cada error incluye:**

- Código de estado HTTP
- Mensaje descriptivo
- Detalles específicos del error

---

## 🧪 Tests Automáticos

La colección incluye **tests automáticos** en varios endpoints:

```javascript
// Ejemplo: Test en "Crear Grupo"
pm.test('Status code is 201', function () {
  pm.response.to.have.status(201);
});

pm.test('Response has folio_virtual', function () {
  const jsonData = pm.response.json();
  pm.expect(jsonData.result.data).to.have.property('folio_virtual');

  // Guarda el folio para requests siguientes
  pm.environment.set('folioVirtual', jsonData.result.data.folio_virtual);
});
```

**Tests incluidos:**

- ✅ Validación de status codes
- ✅ Validación de estructura de respuesta
- ✅ Captura automática de variables (folios, etc.)

---

## 📖 Flujo de Trabajo Típico

### Caso 1: Crear un Grupo Nuevo

```
1. Verificar Acceso
   GET /access?idBodega=1&pppcaptura=123

2. Obtener Catálogo
   GET /catalog?idBodega=1&pppcaptura=123

3. Consultar si ya existe grupo
   GET /active?pppcaptura=123&fecha=2025-11-04&idoperacion=1

4. Crear Grupo (si no existe)
   POST /
   Body: { ID_Bodega, pppcaptura, fechaEntrega, items: [...] }

5. Autorizar Grupo
   POST /:folio/submit
```

### Caso 2: Actualizar un Grupo Existente

```
1. Obtener Grupo
   GET /:folio

2. Actualizar Items
   PUT /:folio
   Body: { pppcaptura, ID_Bodega, fechaEntrega, items: [...] }

3. Autorizar
   POST /:folio/submit
```

---

## 🔐 API Keys Disponibles

La colección está pre-configurada con estas API Keys:

| API Key                     | Usuario ID | Descripción         |
| --------------------------- | ---------- | ------------------- |
| `pcm-mobile-app-key-2025`   | 99999      | App móvil (default) |
| `pcm-web-portal-key-2025`   | 88888      | Portal web          |
| `pcm-admin-portal-key-2025` | 77777      | Portal admin        |

**Para cambiar la API Key:**

1. Ve a **Environments** → **Development**
2. Edita la variable `apiKey`
3. Guarda los cambios

---

## 🎨 Personalización

### Cambiar Base URL

**Para desarrollo local:**

```json
"baseUrl": "http://localhost:3000/api/v2"
```

**Para producción:**

```json
"baseUrl": "https://api.example.com/api/v2"
```

### Agregar Headers Personalizados

1. Selecciona cualquier request
2. Ve a la pestaña **Headers**
3. Agrega nuevos headers según necesites

### Modificar Body Templates

Cada request POST/PUT incluye un body de ejemplo. Puedes:

1. Editarlo directamente
2. Guardar como nuevo ejemplo
3. Usar **Snippets** para generar datos

---

## 🧩 Funcionalidades Avanzadas

### 1. Generación Automática de UUIDs

Los requests POST/PUT/DELETE incluyen un script que genera UUIDs automáticamente:

```javascript
// Pre-request Script
const uuid = require('uuid');
pm.environment.set('idempotencyKey', uuid.v4());
```

### 2. Captura Automática de Folios

El endpoint de crear grupo captura el folio automáticamente:

```javascript
// Test Script
const jsonData = pm.response.json();
pm.environment.set('folioVirtual', jsonData.result.data.folio_virtual);
```

### 3. Tests de Validación

Cada endpoint incluye tests que validan:

- Status code correcto
- Estructura de respuesta
- Propiedades requeridas

---

## 🐛 Troubleshooting

### Error 401 - Unauthorized

**Causa:** API Key no configurada o inválida

**Solución:**

1. Verifica que el entorno esté activo
2. Revisa que `apiKey` tenga un valor válido
3. Asegúrate que el header `x-api-key` esté presente

### Error 404 - Not Found

**Causa:** Base URL incorrecta o servidor no disponible

**Solución:**

1. Verifica que `baseUrl` apunte al servidor correcto
2. Asegúrate que el servidor esté corriendo
3. Prueba el health check primero

### Variables no se sustituyen

**Causa:** Entorno no está activo

**Solución:**

1. Click en el dropdown de entornos (arriba a la derecha)
2. Selecciona **"Captura Cambios - Development"**
3. Las variables `{{baseUrl}}`, `{{apiKey}}`, etc. deben aparecer en naranja

### Folio no se guarda automáticamente

**Causa:** El test script no se ejecutó correctamente

**Solución:**

1. Ve a la pestaña **Tests** del request
2. Verifica que el script esté presente
3. Ejecuta el request nuevamente
4. Revisa la consola de Postman (View → Show Postman Console)

---

## 📊 Ejecutar Toda la Colección

### Usar Collection Runner

1. Click derecho en la colección
2. Selecciona **Run collection**
3. Configura el orden de ejecución
4. Click **Run Captura de Cambios API**

**Nota:** Algunos endpoints dependen de otros (ej: actualizar requiere crear primero)

### Generar Documentación

1. Click en la colección
2. Click en los **"..."** (más opciones)
3. Selecciona **View documentation**
4. Click **Publish** para crear documentación pública

---

## 🔄 Actualizar la Colección

Si hay cambios en la API:

1. Descarga la nueva versión del archivo JSON
2. En Postman, click derecho en la colección
3. Selecciona **Replace**
4. Importa el nuevo archivo
5. ✅ La colección se actualizará manteniendo tus entornos

---

## 📝 Notas Importantes

### Sobre `fechaEntrega`

⚠️ **IMPORTANTE:** `fechaEntrega` está en el **nivel raíz** del DTO, no en cada item:

```json
{
  "ID_Bodega": 1,
  "pppcaptura": 123,
  "fechaEntrega": "2025-11-06", // ← Nivel raíz
  "items": [
    {
      "NUD": "10001",
      "clave_producto": "PEPSI600"
      // SIN fechaEntrega individual
    }
  ]
}
```

### Sobre `numCapturo`

⚠️ **NO enviar** `numCapturo` en el body. Se obtiene automáticamente de la API Key.

### Sobre Idempotencia

✅ Siempre usa `x-idempotency-key` en operaciones POST/PUT/DELETE para evitar duplicados.

---

## 🆘 Soporte

Para más información:

- **Documentación API:** Ver `ENDPOINTS-CAPTURA-CAMBIOS.md`
- **Contratos:** Ver `CONTRATO-CREAR-GRUPO-CAMBIOS.md`
- **Fechas:** Ver `FECHACAMBIO-Y-FECHAENTREGA.md`
- **OpenAPI:** Ver `openapi-captura-cambios.json`

---

## ✨ Características de esta Colección

✅ **9 endpoints completamente documentados**  
✅ **Variables de entorno pre-configuradas**  
✅ **Generación automática de UUIDs**  
✅ **Captura automática de folios**  
✅ **Tests automáticos incluidos**  
✅ **Múltiples ejemplos de respuestas (success + errors)**  
✅ **Headers pre-configurados**  
✅ **Documentación inline en cada request**  
✅ **Lista para usar inmediatamente**

---

¡Disfruta probando la API! 🚀
