# 🔍 Guía de Relación: pppcaptura y NUD

## 📋 Índice

1. [Conceptos Básicos](#conceptos-básicos)
2. [Relación entre pppcaptura y NUD](#relación-entre-pppcaptura-y-nud)
3. [Tipos de Rutas (tipoPPP)](#tipos-de-rutas-tipoppp)
4. [Cómo Obtener pppcaptura](#cómo-obtener-pppcaptura)
5. [Ejemplos de Consultas](#ejemplos-de-consultas)
6. [Casos de Uso Comunes](#casos-de-uso-comunes)
7. [Diagramas de Relación](#diagramas-de-relación)

---

## 📚 Conceptos Básicos

### 🏪 NUD (Número Único de Distribuidor)

**Definición:** Identificador único de un cliente/tienda en el sistema.

```typescript
NUD: string; // Ejemplo: "10001", "10002", "10003"
```

**Características:**

- ✅ Identifica de manera única a un cliente/punto de venta
- ✅ Es el `CLAVE_CLIENTE` en la tabla `Cliente`
- ✅ Un cliente puede ser atendido por diferentes tipos de rutas
- ✅ Es **REQUERIDO** al crear grupos de cambios

**Ubicación en BD:**

```sql
SELECT CLAVE_CLIENTE as NUD, NOM_CLIENTE, CLAVE_BODEGA
FROM Cliente
WHERE CLAVE_CLIENTE = 10001
```

---

### 🚚 pppcaptura (Promotor Punto de Preventa)

**Definición:** Identificador de la **ruta del promotor** que capturó un cambio.

```typescript
pppcaptura: number; // Ejemplo: 123, 456, 789
```

**Características:**

- ✅ Identifica la ruta que realizó la captura
- ✅ Es la columna `ruta` en la tabla `Rutascambios`
- ✅ Una ruta puede atender múltiples clientes (NUDs)
- ✅ Es **REQUERIDO** al crear grupos de cambios
- ✅ Se usa para agrupar cambios por ruta y fecha (folio virtual)

**Ubicación en BD:**

```sql
SELECT ruta as pppcaptura, nombre, tipoPPP, idoperacion
FROM Rutascambios
WHERE ruta = 123
```

---

## 🔗 Relación entre pppcaptura y NUD

### Modelo de Relación

```
┌─────────────────┐          ┌──────────────────┐          ┌─────────────────┐
│  Rutascambios   │          │     Cliente      │          │ CapturaCambios  │
│  (pppcaptura)   │ 1     N  │     (NUD)        │ 1     N  │   (registro)    │
├─────────────────┤◄─────────┤──────────────────┤◄─────────┤─────────────────┤
│ ruta (PK)       │          │ CLAVE_CLIENTE    │          │ pppcaptura (FK) │
│ nombre          │          │ NOM_CLIENTE      │          │ nud (FK)        │
│ tipoPPP         │          │ CLAVE_RUTA_PREV  │          │ FechaCambio     │
│ idoperacion     │          │ CLAVE_RUTA_TELEV │          │ sku             │
│ tipo (1=fijo,   │          │ CLAVE_RUTA_DESAR │          │ cantidad        │
│       2=dinám.) │          │ CLAVE_BODEGA     │          │ ...             │
└─────────────────┘          └──────────────────┘          └─────────────────┘
```

### Relación 1:N

**Una ruta (pppcaptura) puede atender múltiples clientes (NUDs):**

```
pppcaptura 123 → atiene a:
  - NUD 10001 (Cliente A)
  - NUD 10002 (Cliente B)
  - NUD 10003 (Cliente C)
  - NUD 10004 (Cliente D)
```

**Un cliente (NUD) puede tener múltiples rutas según el tipo:**

```
NUD 10001 (Cliente A):
  - CLAVE_RUTA_PREVENTA   = 123  (Ruta de preventa)
  - CLAVE_RUTA_TELEVENTA  = 456  (Ruta de televenta)
  - CLAVE_RUTA_DESARROLLO = 789  (Ruta de desarrollo)
```

### Campos de Relación en Tabla Cliente

| Campo                   | Descripción                      | Ejemplo |
| ----------------------- | -------------------------------- | ------- |
| `CLAVE_RUTA_PREVENTA`   | Ruta normal de preventa          | 123     |
| `CLAVE_RUTA_TELEVENTA`  | Ruta de televenta                | 456     |
| `CLAVE_RUTA_DESARROLLO` | Ruta de desarrollo de nuevos PDV | 789     |

---

## 🎯 Tipos de Rutas (tipoPPP)

La tabla `Rutascambios` define el **tipo de ruta** en el campo `tipoPPP`:

### Valores de tipoPPP

| Valor | Tipo       | Campo Cliente Correspondiente | Descripción                                    |
| ----- | ---------- | ----------------------------- | ---------------------------------------------- |
| **0** | NORMAL     | `CLAVE_RUTA_PREVENTA`         | Ruta de preventa estándar                      |
| **1** | TELEVENTA  | `CLAVE_RUTA_TELEVENTA`        | Ruta de ventas telefónicas                     |
| **2** | DESARROLLO | `CLAVE_RUTA_DESARROLLO`       | Ruta para desarrollo de nuevos puntos de venta |

### Código de Referencia (Legacy PHP)

```php
// De: pcm/mostrarNombreCliente.php y pcm/guardarCmotivos.php

/*
	tipoPPP
	0 NORMAL CLAVE_RUTA_PREVENTA
	1 TELEVENTA CLAVE_RUTA_TELEVENTA
	2 DESARROLLO CLAVE_RUTA_DESARROLLO
*/

$qryTipoRuta = "SELECT tipoPPP FROM dbo.Rutascambios
                WHERE idoperacion = $idop AND ruta = $ppp";

if($rowTipoRuta['tipoPPP'] == 0){
    $condicion = " AND c.CLAVE_RUTA_PREVENTA = ".$ppp;
} else if ($rowTipoRuta['tipoPPP'] == 1) {
    $condicion = " AND c.CLAVE_RUTA_TELEVENTA = ".$ppp;
} else if ($rowTipoRuta['tipoPPP'] == 2) {
    $condicion = " AND c.CLAVE_RUTA_DESARROLLO = ".$ppp;
}
```

---

## 🔎 Cómo Obtener pppcaptura

### Opción 1: Dado un NUD, obtener sus rutas disponibles

**Pregunta:** _"Tengo el NUD 10001, ¿qué rutas (pppcaptura) lo atienden?"_

#### SQL Query

```sql
SELECT
    c.CLAVE_CLIENTE as NUD,
    c.NOM_CLIENTE,
    c.CLAVE_RUTA_PREVENTA as ruta_preventa,
    c.CLAVE_RUTA_TELEVENTA as ruta_televenta,
    c.CLAVE_RUTA_DESARROLLO as ruta_desarrollo,
    c.CLAVE_BODEGA as idoperacion
FROM Cliente c WITH (NOLOCK)
WHERE c.CLAVE_CLIENTE = 10001
  AND c.CLAVE_BODEGA = 1  -- Operación específica
```

#### Resultado Ejemplo

| NUD   | NOM_CLIENTE   | ruta_preventa | ruta_televenta | ruta_desarrollo | idoperacion |
| ----- | ------------- | ------------- | -------------- | --------------- | ----------- |
| 10001 | Tienda Center | 123           | NULL           | NULL            | 1           |

**Interpretación:**

- El cliente `10001` es atendido por la **ruta 123** (preventa)
- No tiene rutas de televenta ni desarrollo asignadas

---

### Opción 2: Dado pppcaptura, obtener clientes (NUDs) que atiende

**Pregunta:** _"La ruta 123 (pppcaptura), ¿qué clientes (NUDs) atiende?"_

#### Paso 1: Obtener tipo de ruta (tipoPPP)

```sql
SELECT ruta, nombre, tipoPPP, idoperacion
FROM Rutascambios WITH (NOLOCK)
WHERE ruta = 123
  AND idoperacion = 1
```

**Resultado:**

| ruta | nombre         | tipoPPP | idoperacion |
| ---- | -------------- | ------- | ----------- |
| 123  | Ruta Norte MTY | 0       | 1           |

**tipoPPP = 0** → Es una ruta de **PREVENTA** → Buscar en `CLAVE_RUTA_PREVENTA`

#### Paso 2: Obtener clientes según tipoPPP

**Si tipoPPP = 0 (PREVENTA):**

```sql
SELECT
    c.CLAVE_CLIENTE as NUD,
    c.NOM_CLIENTE,
    c.CLAVE_RUTA_PREVENTA as pppcaptura,
    c.CLAVE_BODEGA as idoperacion
FROM Cliente c WITH (NOLOCK)
WHERE c.CLAVE_RUTA_PREVENTA = 123
  AND c.CLAVE_BODEGA = 1
ORDER BY c.CLAVE_CLIENTE
```

**Si tipoPPP = 1 (TELEVENTA):**

```sql
SELECT
    c.CLAVE_CLIENTE as NUD,
    c.NOM_CLIENTE,
    c.CLAVE_RUTA_TELEVENTA as pppcaptura,
    c.CLAVE_BODEGA as idoperacion
FROM Cliente c WITH (NOLOCK)
WHERE c.CLAVE_RUTA_TELEVENTA = 123
  AND c.CLAVE_BODEGA = 1
ORDER BY c.CLAVE_CLIENTE
```

**Si tipoPPP = 2 (DESARROLLO):**

```sql
SELECT
    c.CLAVE_CLIENTE as NUD,
    c.NOM_CLIENTE,
    c.CLAVE_RUTA_DESARROLLO as pppcaptura,
    c.CLAVE_BODEGA as idoperacion
FROM Cliente c WITH (NOLOCK)
WHERE c.CLAVE_RUTA_DESARROLLO = 123
  AND c.CLAVE_BODEGA = 1
ORDER BY c.CLAVE_CLIENTE
```

#### Resultado Ejemplo (tipoPPP = 0)

| NUD   | NOM_CLIENTE          | pppcaptura | idoperacion |
| ----- | -------------------- | ---------- | ----------- |
| 10001 | Tienda Center        | 123        | 1           |
| 10002 | Súper Express        | 123        | 1           |
| 10003 | Abarrotes Don Juan   | 123        | 1           |
| 10004 | Minisuper La Esquina | 123        | 1           |

---

### Opción 3: Obtener pppcaptura de un cambio existente

**Pregunta:** _"Ya existe un grupo de cambios, ¿qué ruta (pppcaptura) lo capturó?"_

```sql
SELECT DISTINCT
    cc.pppcaptura,
    cc.FechaCambio,
    cc.idoperacion,
    COUNT(*) as total_items
FROM CapturaCambios cc WITH (NOLOCK)
WHERE cc.nud = 10001
  AND cc.FechaCambio >= '2025-10-01'
GROUP BY cc.pppcaptura, cc.FechaCambio, cc.idoperacion
ORDER BY cc.FechaCambio DESC
```

#### Resultado Ejemplo

| pppcaptura | FechaCambio | idoperacion | total_items |
| ---------- | ----------- | ----------- | ----------- |
| 123        | 2025-10-30  | 1           | 5           |
| 123        | 2025-10-15  | 1           | 3           |
| 456        | 2025-10-01  | 1           | 2           |

---

## 💡 Ejemplos de Consultas

### Ejemplo 1: Validar que un NUD pertenece a una ruta (pppcaptura)

**Escenario:** Antes de crear un cambio, validar que el NUD 10001 puede ser atendido por la ruta 123.

```sql
DECLARE @pppcaptura INT = 123
DECLARE @nud INT = 10001
DECLARE @idoperacion INT = 1
DECLARE @tipoPPP INT

-- Paso 1: Obtener tipo de ruta
SELECT @tipoPPP = tipoPPP
FROM Rutascambios WITH (NOLOCK)
WHERE ruta = @pppcaptura
  AND idoperacion = @idoperacion

-- Paso 2: Validar según tipoPPP
IF @tipoPPP = 0 -- PREVENTA
BEGIN
    SELECT 'VÁLIDO' as resultado
    FROM Cliente WITH (NOLOCK)
    WHERE CLAVE_CLIENTE = @nud
      AND CLAVE_RUTA_PREVENTA = @pppcaptura
      AND CLAVE_BODEGA = @idoperacion
END
ELSE IF @tipoPPP = 1 -- TELEVENTA
BEGIN
    SELECT 'VÁLIDO' as resultado
    FROM Cliente WITH (NOLOCK)
    WHERE CLAVE_CLIENTE = @nud
      AND CLAVE_RUTA_TELEVENTA = @pppcaptura
      AND CLAVE_BODEGA = @idoperacion
END
ELSE IF @tipoPPP = 2 -- DESARROLLO
BEGIN
    SELECT 'VÁLIDO' as resultado
    FROM Cliente WITH (NOLOCK)
    WHERE CLAVE_CLIENTE = @nud
      AND CLAVE_RUTA_DESARROLLO = @pppcaptura
      AND CLAVE_BODEGA = @idoperacion
END
```

**Resultado esperado:**

- Si retorna `'VÁLIDO'` → El NUD puede ser atendido por esa ruta ✅
- Si no retorna nada → El NUD NO pertenece a esa ruta ❌

---

### Ejemplo 2: Obtener todos los cambios de una ruta en una fecha

```sql
SELECT
    cc.pppcaptura,
    cc.FechaCambio,
    cc.nud,
    c.NOM_CLIENTE,
    cc.sku,
    cc.cantidad,
    cm.motivoCambio,
    cc.statusAutorizado
FROM CapturaCambios cc WITH (NOLOCK)
INNER JOIN Cliente c WITH (NOLOCK)
    ON c.CLAVE_CLIENTE = cc.nud
    AND c.CLAVE_BODEGA = cc.idoperacion
LEFT JOIN CambiosMotivos cm WITH (NOLOCK)
    ON cm.idcambiosmotivos = cc.idcambiosmotivos
WHERE cc.pppcaptura = 123
  AND cc.FechaCambio = '2025-10-30'
  AND cc.idoperacion = 1
ORDER BY cc.nud, cc.sku
```

---

### Ejemplo 3: Listar rutas disponibles para un NUD con nombres

```sql
SELECT
    c.CLAVE_CLIENTE as NUD,
    c.NOM_CLIENTE,
    -- Ruta de Preventa
    c.CLAVE_RUTA_PREVENTA as ruta_preventa,
    r1.nombre as nombre_preventa,
    -- Ruta de Televenta
    c.CLAVE_RUTA_TELEVENTA as ruta_televenta,
    r2.nombre as nombre_televenta,
    -- Ruta de Desarrollo
    c.CLAVE_RUTA_DESARROLLO as ruta_desarrollo,
    r3.nombre as nombre_desarrollo
FROM Cliente c WITH (NOLOCK)
LEFT JOIN Rutascambios r1 WITH (NOLOCK)
    ON r1.ruta = c.CLAVE_RUTA_PREVENTA
    AND r1.idoperacion = c.CLAVE_BODEGA
    AND r1.tipoPPP = 0
LEFT JOIN Rutascambios r2 WITH (NOLOCK)
    ON r2.ruta = c.CLAVE_RUTA_TELEVENTA
    AND r2.idoperacion = c.CLAVE_BODEGA
    AND r2.tipoPPP = 1
LEFT JOIN Rutascambios r3 WITH (NOLOCK)
    ON r3.ruta = c.CLAVE_RUTA_DESARROLLO
    AND r3.idoperacion = c.CLAVE_BODEGA
    AND r3.tipoPPP = 2
WHERE c.CLAVE_CLIENTE = 10001
  AND c.CLAVE_BODEGA = 1
```

---

## 🎬 Casos de Uso Comunes

### Caso 1: Crear un Grupo de Cambios

**Flujo:**

1. **Usuario selecciona operación** → `idBodega = 1`
2. **Usuario selecciona ruta** → `pppcaptura = 123`
3. **Sistema valida acceso:**
   ```
   GET /api/v2/captura_cambios/access?idBodega=1&pppcaptura=123
   ```
4. **Usuario captura cambios para clientes:**
   - NUD 10001 → 5 piezas de SKU 123456
   - NUD 10002 → 3 piezas de SKU 789012
5. **Sistema crea grupo:**
   ```json
   POST /api/v2/captura_cambios
   {
     "ID_Bodega": 1,
     "pppcaptura": 123,
     "items": [
       { "NUD": "10001", "clave_producto": 123456, "piezas": 5, ... },
       { "NUD": "10002", "clave_producto": 789012, "piezas": 3, ... }
     ]
   }
   ```
6. **Sistema genera folio:** `123-2025-10-30`
7. **En BD se crean registros:**
   ```
   CapturaCambios:
     - pppcaptura=123, nud=10001, FechaCambio=2025-10-30, ...
     - pppcaptura=123, nud=10002, FechaCambio=2025-10-30, ...
   ```

---

### Caso 2: Consultar Grupo Existente

**Pregunta:** _"¿Qué cambios capturó la ruta 123 el día 30 de octubre?"_

**API:**

```bash
GET /api/v2/captura_cambios/123-2025-10-30
```

**BD:**

```sql
SELECT
    cc.pppcaptura,
    cc.FechaCambio,
    cc.nud,
    c.NOM_CLIENTE,
    cc.sku,
    cc.cantidad,
    cc.statusAutorizado
FROM CapturaCambios cc WITH (NOLOCK)
INNER JOIN Cliente c WITH (NOLOCK)
    ON c.CLAVE_CLIENTE = cc.nud
WHERE cc.pppcaptura = 123
  AND cc.FechaCambio = '2025-10-30'
```

---

### Caso 3: Autocompletado de Clientes

**Escenario:** Usuario está en la ruta 123 y quiere buscar un cliente por nombre.

**Flujo:**

1. **Obtener tipo de ruta:**
   ```sql
   SELECT tipoPPP FROM Rutascambios WHERE ruta = 123
   ```
2. **Buscar clientes de esa ruta:**
   ```sql
   -- Si tipoPPP = 0 (PREVENTA)
   SELECT
       c.CLAVE_CLIENTE as NUD,
       c.NOM_CLIENTE
   FROM Cliente c WITH (NOLOCK)
   WHERE c.CLAVE_RUTA_PREVENTA = 123
     AND c.NOM_CLIENTE LIKE '%express%'
   ORDER BY c.NOM_CLIENTE
   ```

**Resultado:**

```
NUD   | NOM_CLIENTE
------|----------------------
10002 | Súper Express
10125 | Express Mini Market
```

---

## 📊 Diagramas de Relación

### Diagrama 1: Estructura de Datos

```
                    ┌─────────────────────────────┐
                    │      Operaciones            │
                    │  (ID_Bodega/idoperacion)    │
                    └─────────────┬───────────────┘
                                  │
                    ┌─────────────┴───────────────┐
                    │                             │
         ┌──────────▼──────────┐      ┌──────────▼──────────┐
         │   Rutascambios      │      │      Cliente        │
         │   (pppcaptura)      │      │      (NUD)          │
         ├─────────────────────┤      ├─────────────────────┤
         │ ruta (PK)           │      │ CLAVE_CLIENTE (PK)  │
         │ nombre              │      │ NOM_CLIENTE         │
         │ tipoPPP ◄───────────┼──┐   │ CLAVE_RUTA_PREV ────┼──┐
         │ idoperacion (FK)    │  │   │ CLAVE_RUTA_TELEV────┼──┤
         │ tipo (1=fijo,       │  │   │ CLAVE_RUTA_DESAR────┼──┤
         │       2=dinámico)   │  │   │ CLAVE_BODEGA (FK)   │  │
         └─────────┬───────────┘  │   └─────────┬───────────┘  │
                   │              │             │              │
                   │              └─────────────┼──────────────┘
                   │                            │
                   └───────────┬────────────────┘
                               │
                   ┌───────────▼──────────────┐
                   │   CapturaCambios         │
                   │   (registro cambio)      │
                   ├──────────────────────────┤
                   │ pppcaptura (FK)          │
                   │ nud (FK)                 │
                   │ FechaCambio              │
                   │ sku                      │
                   │ cantidad                 │
                   │ idcambiosmotivos (FK)    │
                   │ statusAutorizado         │
                   └──────────────────────────┘
```

---

### Diagrama 2: Flujo de Validación NUD → pppcaptura

```
┌─────────────────────────────────────────────────────────────┐
│  ¿El NUD 10001 pertenece a la ruta 123?                     │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
        ┌────────────────────────────────┐
        │ 1. Consultar Rutascambios      │
        │    WHERE ruta = 123            │
        │    → tipoPPP = ?               │
        └────────────┬───────────────────┘
                     │
         ┌───────────┴───────────┐
         │                       │
    ┌────▼─────┐      ┌─────────▼────┐      ┌────────────┐
    │ tipoPPP=0│      │ tipoPPP=1    │      │ tipoPPP=2  │
    │ PREVENTA │      │ TELEVENTA    │      │ DESARROLLO │
    └────┬─────┘      └─────────┬────┘      └──────┬─────┘
         │                      │                   │
         ▼                      ▼                   ▼
    ┌────────────┐      ┌──────────────┐     ┌──────────────┐
    │ Validar en │      │  Validar en  │     │  Validar en  │
    │CLAVE_RUTA_ │      │ CLAVE_RUTA_  │     │ CLAVE_RUTA_  │
    │ PREVENTA   │      │  TELEVENTA   │     │  DESARROLLO  │
    └────┬───────┘      └──────┬───────┘     └──────┬───────┘
         │                     │                     │
         └──────────┬──────────┴─────────────────────┘
                    │
                    ▼
         ┌──────────────────────┐
         │  ¿Campo = 123?       │
         └──────────┬───────────┘
                    │
         ┌──────────┴──────────┐
         │                     │
      ✅ SÍ                  ❌ NO
   ┌──────▼──────┐      ┌─────▼────────┐
   │  NUD válido │      │ NUD inválido │
   │ para ruta   │      │  para ruta   │
   └─────────────┘      └──────────────┘
```

---

## 🔧 API Endpoints Relacionados

### Obtener Rutas Disponibles

```bash
GET /api/v2/catalogos/rutas?idoperacion=1
```

**Response:**

```json
{
  "result": {
    "data": [
      {
        "ruta": 123,
        "nombre": "Ruta Norte MTY",
        "tipoPPP": 0,
        "tipo": 1,
        "idoperacion": 1
      },
      {
        "ruta": 456,
        "nombre": "Televenta Central",
        "tipoPPP": 1,
        "tipo": 2,
        "idoperacion": 1
      }
    ],
    "successful": true
  }
}
```

---

### Verificar Acceso de Ruta

```bash
GET /api/v2/captura_cambios/access?idBodega=1&pppcaptura=123
```

**Response:**

```json
{
  "result": {
    "data": {
      "access": true,
      "has_active_ticket": false
    },
    "successful": true,
    "message": "Acceso habilitado al módulo."
  }
}
```

---

## 📝 Resumen Ejecutivo

| Aspecto         | Descripción                                                                 |
| --------------- | --------------------------------------------------------------------------- |
| **NUD**         | Identificador único del cliente/tienda                                      |
| **pppcaptura**  | Identificador de la ruta que captura cambios                                |
| **Relación**    | 1 ruta atiende N clientes; 1 cliente puede tener hasta 3 rutas (según tipo) |
| **tipoPPP**     | Define tipo de ruta (0=Preventa, 1=Televenta, 2=Desarrollo)                 |
| **Campo Clave** | `CLAVE_RUTA_PREVENTA`, `CLAVE_RUTA_TELEVENTA`, `CLAVE_RUTA_DESARROLLO`      |
| **Validación**  | Se consulta `tipoPPP` para saber qué campo del cliente validar              |
| **Agrupación**  | Los cambios se agrupan por `pppcaptura-fecha` (folio virtual)               |

---

## 🎯 Reglas Importantes

1. ✅ **Siempre validar tipoPPP** antes de relacionar pppcaptura con NUD
2. ✅ Un NUD puede tener **hasta 3 rutas diferentes** (preventa, televenta, desarrollo)
3. ✅ Al crear cambios, **validar que el NUD pertenezca a la ruta** según tipoPPP
4. ✅ Los grupos de cambios se identifican por **pppcaptura + FechaCambio**
5. ✅ Una ruta puede estar en **modo fijo** (tipo=1) o **dinámico** (tipo=2)
   - Fijo: Requiere `idruta` y `estatusDis`
   - Dinámico: Solo registra `horadinamico`

---

## 📚 Referencias

- **Tabla Principal**: `CapturaCambios`
- **Tabla de Rutas**: `Rutascambios`
- **Tabla de Clientes**: `Cliente`
- **Código Legacy**:
  - `pcm/mostrarNombreCliente.php`
  - `pcm/guardarCmotivos.php`
  - `pcm/tablaConfCambiosTotal.php`

---

**Última actualización:** 2025-11-04  
**Autor:** Equipo Técnico GEPP/Draweb
