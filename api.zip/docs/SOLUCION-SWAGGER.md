# Solución: Swagger Muestra Solo 6 Endpoints

## ✅ Problema Identificado

El diagnóstico confirmó que:

- ✅ Todos los archivos existen
- ✅ CatalogosModule está correctamente importado
- ✅ Hay 10 endpoints definidos (8 + 2)
- ✅ Los controladores están registrados

**Causa:** Caché del build anterior o versión desactualizada compilada

## 🔧 Solución

### Paso 1: Limpiar y Recompilar

```bash
cd pcm-api
rm -rf dist node_modules/.cache
npm run build
```

### Paso 2: Levantar Servidor

```bash
npm run start:dev
```

### Paso 3: Verificar en Swagger

Abre: `http://localhost:3000/api/docs`

Deberías ver:

```
🔹 Captura de Cambios (8 endpoints)
   ├─ GET /api/captura_cambios/access
   ├─ GET /api/captura_cambios/catalog
   ├─ POST /api/captura_cambios
   ├─ GET /api/captura_cambios/active
   ├─ GET /api/captura_cambios/health
   ├─ GET /api/captura_cambios/{folio}
   ├─ POST /api/captura_cambios/{folio}/submit
   └─ DELETE /api/captura_cambios/{folio}

🔹 Catálogos (2 endpoints) ✨ NUEVO
   ├─ GET /api/catalogos/operaciones
   └─ GET /api/catalogos/rutas

🔹 Auth (0 endpoints)
```

### Paso 4: Verificar Programáticamente

```bash
curl -s http://localhost:3000/api/docs-json | jq '.paths | length'
```

**Resultado esperado:** `10`

## 📊 Detalles de los 10 Endpoints

### Módulo: Captura de Cambios (8)

| #   | Método | Ruta                             | Descripción                            |
| --- | ------ | -------------------------------- | -------------------------------------- |
| 1   | GET    | `/captura_cambios/access`        | Verificar elegibilidad                 |
| 2   | GET    | `/captura_cambios/catalog`       | Obtener catálogo (con filtro idMotivo) |
| 3   | POST   | `/captura_cambios`               | Crear grupo de cambios                 |
| 4   | GET    | `/captura_cambios/active`        | Consultar grupo activo                 |
| 5   | GET    | `/captura_cambios/health`        | Health check                           |
| 6   | GET    | `/captura_cambios/:folio`        | Obtener grupo por folio                |
| 7   | POST   | `/captura_cambios/:folio/submit` | Autorizar grupo                        |
| 8   | DELETE | `/captura_cambios/:folio`        | Declinar grupo                         |

### Módulo: Catálogos (2) ✨ NUEVO

| #   | Método | Ruta                     | Descripción                |
| --- | ------ | ------------------------ | -------------------------- |
| 9   | GET    | `/catalogos/operaciones` | Listar operaciones/bodegas |
| 10  | GET    | `/catalogos/rutas`       | Listar rutas por operación |

## 🐛 Si Aún No Funcionan

### Opción A: Servidor en Puerto Diferente

```bash
# Verificar qué puerto está usando
ps aux | grep "node.*main.js"

# Si está en otro puerto, ajusta la URL
```

### Opción B: Matar Procesos Viejos

```bash
# Matar todos los procesos de Node
pkill -f "node.*main.js"
pkill -f "nest start"

# Limpiar todo
rm -rf dist node_modules/.cache

# Recompilar y levantar
npm run build
npm run start:dev
```

### Opción C: Verificar .env

```bash
# Asegúrate de que Swagger esté habilitado
cat .env | grep SWAGGER
```

Debería tener:

```
SWAGGER_ENABLED=true
# o no tener esta variable (se habilita por default en development)
```

## ✅ Checklist de Verificación

Después de seguir los pasos:

- [ ] Build completado sin errores
- [ ] Servidor levantado en puerto 3000
- [ ] Swagger UI carga en `/api/docs`
- [ ] Se ven 3 tags: "Captura de Cambios", "Catálogos", "Auth"
- [ ] Tag "Captura de Cambios" tiene 8 endpoints
- [ ] Tag "Catálogos" tiene 2 endpoints
- [ ] Total de 10 endpoints visibles

## 🎯 Resultado Final

Al abrir Swagger UI deberías poder:

1. **Ver todos los endpoints organizados** por tags
2. **Expandir cada endpoint** y ver documentación completa
3. **Usar "Try it out"** para probar los endpoints
4. **Ver ejemplos** de request/response
5. **Leer flujos de negocio** en las descripciones

## 📞 Soporte

Si después de seguir todos los pasos aún ves solo 6 endpoints:

1. Comparte el output de:

   ```bash
   ./diagnostico-endpoints.sh
   ```

2. Verifica la consola del servidor:

   ```bash
   npm run start:dev
   ```

   Busca errores o warnings al iniciar.

3. Verifica la respuesta JSON:
   ```bash
   curl -s http://localhost:3000/api/docs-json | jq '.paths | keys'
   ```

---

**Versión del Documento:** 1.0  
**Fecha:** 31 de Octubre de 2025  
**API Version:** 2.0.1
