import { ExecutionContext, createParamDecorator } from '@nestjs/common';

import { ApiKeyData } from '../interfaces/api-key-data.interface';

export const CurrentApiKey = createParamDecorator(
  (data: keyof ApiKeyData | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const apiKeyData = request.apiKeyData as ApiKeyData;

    return data ? apiKeyData?.[data] : apiKeyData;
  },
);
