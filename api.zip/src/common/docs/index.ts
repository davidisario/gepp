import {
  ApiHeaderOptions,
  ApiParamOptions,
  ApiQueryOptions,
  ApiResponseOptions,
} from '@nestjs/swagger';
import { OperationObject } from '@nestjs/swagger/dist/interfaces/open-api-spec.interface';
import { CambioGroupResponseDTO } from 'src/modules/captura-cambio/dto/cambio-response.dto';

const SWAGGER_BASE_URL =
  process.env.SWAGGER_BASE_URL || 'http://localhost:3000/api';

type HeaderKeys = 'x-api-key' | 'x-idempotency-key';
type ResponseKeys =
  | 'ok'
  | 'created'
  | 'badRequest'
  | 'unauthorized'
  | 'forbidden'
  | 'notFound'
  | 'conflict'
  | 'unprocessableEntity'
  | 'noContent';

interface EndpointDocumentation {
  operation: Partial<OperationObject>;
  header?: Partial<Record<HeaderKeys, ApiHeaderOptions>>;
  params?: Record<string, ApiParamOptions>;
  queries?: Record<string, ApiQueryOptions>;
  responses: Partial<Record<ResponseKeys, ApiResponseOptions>>;
}

interface ContentStructure {
  [endpoint: string]: EndpointDocumentation;
}

export const capturaCambioDocs = {
  access: {
    operation: {
      summary: '1️⃣ Verificar elegibilidad de acceso',
      description: `
**FLUJO INICIAL - PASO 1:**
Este es el primer endpoint que debe llamarse al ingresar al módulo de cambios.

**Propósito:**
- Verificar si la combinación operación + ruta + nud tiene acceso al módulo
- Detectar si ya existe un grupo activo (pendiente de autorización)

**🔐 AUTENTICACIÓN:**

Este endpoint requiere API Key:
\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X GET "${SWAGGER_BASE_URL}/captura_cambios/access?idBodega=1&pppcaptura=123&nud=10001" \\
  -H "x-api-key: pcm-mobile-app-key-2025"
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const response = await fetch('/api/v2/captura_cambios/access?idBodega=1&pppcaptura=123&nud=10001', {
  headers: {
    'x-api-key': 'pcm-mobile-app-key-2025'
  }
});
const result = await response.json();
console.log('Acceso:', result.data.access);
console.log('Tiene ticket activo:', result.data.has_active_ticket);
\`\`\`

**Reglas de Negocio:**
1. La operación (ID_Bodega) debe existir y estar activa
2. La ruta (pppcaptura) debe existir y estar activa
3. Si hay un grupo activo (has_active_ticket=true), NO se puede crear uno nuevo
4. La verificación de ticket activo se limita al cliente (nud) ingresado

**Flujo Típico:**
\`\`\`
Usuario ingresa al módulo
  ↓
GET /access?idBodega=1&pppcaptura=123&nud=10001
  ↓
access=true, has_active_ticket=false → Puede crear nuevo grupo (para ese NUD)
access=true, has_active_ticket=true → Debe editar/autorizar grupo existente (para ese NUD)
access=false → No tiene acceso, mostrar mensaje de error
\`\`\`

**Ejemplo de Uso:**
Promotor de ruta 123 ingresa al módulo en operación 1.
El sistema verifica si puede capturar cambios.
    `,
    },
    header: {
      'x-api-key': {
        name: 'x-api-key',
        description: '🔐 API Key para autenticación (REQUERIDO)',
        required: true,
        schema: {
          type: 'string',
          default: 'pcm-mobile-app-key-2025',
        },
      },
    },
    queries: {
      idBodega: {
        name: 'idBodega',
        description: 'ID de operación/bodega',
        example: 1,
        required: true,
      },
      pppcaptura: {
        name: 'pppcaptura',
        description: 'Número de ruta del promotor (PPP)',
        example: 123,
        required: true,
      },
      nud: {
        name: 'nud',
        description:
          'NUD para verificar ticket activo de un cliente específico',
        example: 10001,
        required: true,
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Elegibilidad verificada exitosamente',
        schema: {
          example: {
            result: {
              data: {
                access: true,
                has_active_ticket: false,
              },
              successful: true,
              message: 'Acceso habilitado al módulo.',
            },
          },
        },
      },
      unauthorized: {
        status: 401,
        description: '🔐 No autorizado - API Key faltante o inválida',
        schema: {
          example: {
            statusCode: 401,
            message: 'API Key no proporcionada o inválida',
            error: 'Unauthorized',
          },
        },
      },
      forbidden: {
        status: 403,
        description: 'Usuario no elegible para el módulo',
        schema: {
          example: {
            result: {
              data: { access: false },
              successful: false,
              errors: {
                code: 'NOT_ELIGIBLE',
                detail:
                  'El usuario no es elegible para el módulo en esta operación/ruta.',
              },
            },
          },
        },
      },
    },
  },
  catalog: {
    productos: {
      operation: {
        summary: '2️⃣ Obtener catálogo de productos',
        description: `
**FLUJO INICIAL - PASO 2:**
Después de verificar acceso, obtener el catálogo de productos elegibles.

**Propósito:**
- Obtener lista de productos que pueden ser cambiados
- Conocer los límites por producto (mínimo, máximo, umbral de alerta)

**🔐 AUTENTICACIÓN:**

\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X GET "${SWAGGER_BASE_URL}/captura_cambios/catalog/productos?idBodega=1&pppcaptura=123" \\
  -H "x-api-key: pcm-mobile-app-key-2025"
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const response = await fetch('/api/v2/captura_cambios/catalog/productos?idBodega=1&pppcaptura=123', {
  headers: { 'x-api-key': 'pcm-mobile-app-key-2025' }
});
const { productos } = (await response.json()).result.data;
\`\`\`

**Reglas de Negocio:**
1. Solo se muestran productos activos en \`productoscambios\` para esa operación
2. Se valida la existencia de la ruta (pppcaptura)
3. Se obtienen los productos correspondientes al tipo de mercado de la ruta
4. Los límites son:
   - minimo_permitido: 1 pieza
   - maximo_permitido: 999 piezas
   - maximo_para_alerta: 30 piezas (requiere justificación si se excede)

**Flujo Típico:**
\`\`\`
Usuario tiene acceso
  ↓
GET /catalog/productos?idBodega=1&pppcaptura=123
  ↓
Recibe productos
  ↓
Muestra formulario de captura con estos datos
\`\`\`

**Ejemplo de Uso:**
Sistema carga el catálogo para mostrar:
- Dropdown de productos disponibles
- Validaciones de cantidades por producto
    `,
      },
      header: {
        'x-api-key': {
          name: 'x-api-key',
          description: '🔐 API Key para autenticación (REQUERIDO)',
          required: true,
          schema: {
            type: 'string',
            default: 'pcm-mobile-app-key-2025',
          },
        },
      },
      queries: {
        idBodega: {
          name: 'idBodega',
          description: 'ID de operación/bodega',
          example: 1,
          required: true,
        },
        pppcaptura: {
          name: 'pppcaptura',
          description: 'Número de ruta del promotor (PPP)',
          example: 123,
          required: true,
        },
      },
      responses: {
        ok: {
          status: 200,
          description: 'Catálogo de productos recuperado exitosamente',
          schema: {
            example: {
              result: {
                data: {
                  productos: [
                    {
                      clave_producto: 123456,
                      descripcion: 'Pepsi 600ml',
                      minimo_permitido: 1,
                      maximo_permitido: 999,
                      maximo_para_alerta: 30,
                      unidad: 'Pza',
                    },
                    {
                      clave_producto: 654321,
                      descripcion: '7UP 2L',
                      minimo_permitido: 1,
                      maximo_permitido: 999,
                      maximo_para_alerta: 30,
                      unidad: 'Pza',
                    },
                  ],
                },
                successful: true,
                message: 'Catálogo de productos recuperado correctamente.',
              },
            },
          },
        },
        unauthorized: {
          status: 401,
          description: '🔐 No autorizado - API Key faltante o inválida',
          schema: {
            example: {
              statusCode: 401,
              message: 'API Key no proporcionada o inválida',
              error: 'Unauthorized',
            },
          },
        },
        notFound: {
          status: 404,
          description:
            'No se encontró catálogo de productos para esta combinación',
        },
      },
    },
    motivos: {
      operation: {
        summary: '3️⃣ Obtener catálogo de motivos',
        description: `
**FLUJO INICIAL - PASO 2:**
Después de verificar acceso, obtener el catálogo de motivos disponibles.

**Propósito:**
- Obtener motivos de cambio disponibles

**🔐 AUTENTICACIÓN:**

\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X GET "${SWAGGER_BASE_URL}/captura_cambios/catalog/motivos?idBodega=1&pppcaptura=123&sku=1234" \\
  -H "x-api-key: pcm-mobile-app-key-2025"
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const response = await fetch('/api/v2/captura_cambios/catalog/motivos?idBodega=1&pppcaptura=123&sku=1234', {
  headers: { 'x-api-key': 'pcm-mobile-app-key-2025' }
});
const { motivos } = (await response.json()).result.data;
\`\`\`

**Reglas de Negocio:**
1. Solo se muestran motivos activos
2. Se exponen los motivos vinculados al sku proporcionado, si se encuentra en la lista de skus_permitidos o si es null

**Flujo Típico:**
\`\`\`
Usuario tiene acceso
  ↓
GET /catalog/motivos?idBodega=1&pppcaptura=123&sku=1234
  ↓
Recibe motivos
  ↓
Muestra formulario de captura con estos datos
\`\`\`

**Ejemplo de Uso:**
Sistema carga el catálogo para mostrar:
- Dropdown de motivos de cambio
- Validaciones de cantidades por producto
    `,
      },
      header: {
        'x-api-key': {
          name: 'x-api-key',
          description: '🔐 API Key para autenticación (REQUERIDO)',
          required: true,
          schema: {
            type: 'string',
            default: 'pcm-mobile-app-key-2025',
          },
        },
      },
      queries: {
        idBodega: {
          name: 'idBodega',
          description: 'ID de operación/bodega',
          example: 1,
          required: true,
        },
        pppcaptura: {
          name: 'pppcaptura',
          description: 'Número de ruta del promotor (PPP)',
          example: 123,
          required: true,
        },
        sku: {
          name: 'sku',
          description: 'SKU del producto para filtrar motivos aplicables',
          example: 1234,
          required: true,
        },
      },
      responses: {
        ok: {
          status: 200,
          description: 'Catálogo de motivos recuperado exitosamente',
          schema: {
            example: {
              result: {
                data: {
                  motivos: [
                    {
                      id_motivo: 1,
                      descripcion: 'Producto Dañado',
                      agrupador: 'CALIDAD',
                      justificacion_preconfigurada: true,
                    },
                    {
                      id_motivo: 2,
                      descripcion: 'Próximo a Vencer',
                      agrupador: 'FECHA',
                      justificacion_preconfigurada: false,
                    },
                    {
                      id_motivo: 3,
                      descripcion: 'Error de Entrega',
                      agrupador: 'LOGISTICA',
                      justificacion_preconfigurada: false,
                    },
                  ],
                },
                successful: true,
                message: 'Catálogo de motivos recuperado correctamente.',
              },
            },
          },
        },
        unauthorized: {
          status: 401,
          description: '🔐 No autorizado - API Key faltante o inválida',
          schema: {
            example: {
              statusCode: 401,
              message: 'API Key no proporcionada o inválida',
              error: 'Unauthorized',
            },
          },
        },
        notFound: {
          status: 404,
          description:
            'No se encontró catálogo de motivos para esta combinación',
        },
      },
    },
  },
  create: {
    operation: {
      summary: '4️⃣ Crear grupo de cambios',
      description: `
**FLUJO PRINCIPAL - PASO 3:**
Después de verificar acceso y obtener el catálogo, crear un nuevo grupo de cambios.

**Propósito:**
- Crear un grupo de cambios para una ruta, cedis, nud y fecha específica
- La combinación ruta + cedis + nud + fecha debe ser única
- Agregar items (productos + motivos + cantidades) al grupo
- Todos los items del grupo comparten la misma fecha de entrega calculada automáticamente
- El NUD (cliente) se envía a nivel raíz y aplica a todos los items
- La FechaCambio se toma del día actual y la fechaEntrega se calcula según la ruta/NUD

**🔐 AUTENTICACIÓN:**

Este endpoint requiere API Key. Envíala en el header:
\`\`\`
x-api-key: tu-api-key-aqui
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X POST "${SWAGGER_BASE_URL}/captura_cambios" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: pcm-mobile-app-key-2025" \\
  -H "x-idempotency-key: $(uuidgen)" \\
  -d '{
    "NUD": 10001,
    "ID_Bodega": 1,
    "pppcaptura": 123,
    "items": [
      {
        "clave_producto": 123456,
        "id_motivo": 1,
        "piezas": 25,
        "justificacion": "Producto dañado en transporte"
      }
    ]
  }'
\`\`\`

**Ejemplo JavaScript/TypeScript:**
\`\`\`javascript
const idempotencyKey = crypto.randomUUID();

const response = await fetch('/api/v2/captura_cambios', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': 'pcm-mobile-app-key-2025',
    'x-idempotency-key': idempotencyKey
  },
  body: JSON.stringify({
    NUD: 10001,
    ID_Bodega: 1,
    pppcaptura: 123,
    items: [{
      clave_producto: 123456,
      id_motivo: 1,
      piezas: 25,
      justificacion: "Producto dañado en transporte"
    }]
  })
});

const result = await response.json();
console.log('Folio creado:', result.data.folio_virtual);
\`\`\`

**Reglas de Negocio:**
1. NO puede haber otro grupo activo (pendiente) para la misma combinación:
   - pppcaptura (ruta)
   - NUD (cliente)
   - ID_Bodega (cedis)
   - fecha
2. Tipo de despacho de la ruta:
  La ruta debe existir en el catálogo y su tipo determina el flujo:
  
  - Ruta Fija (tipo=1):
    * Requiere cálculo de idruta (ruta de entrega específica)
    * estatusDis = 2 (pendiente distribución dinámica)
    * horadinamico se registra automáticamente
    * pedidopromsio = 1
  
  - Ruta Dinámica (tipo=2):
    * NO requiere idruta (se asigna en distribución)
    * estatusDis = 0 (sin distribución previa)
    * horadinamico = null
    * pedidopromsio = null
3. El grupo debe tener al menos un item; la fechaEntrega se calcula en backend (día hábil)
4. Cada solicitud debe incluir:
   - NUD del cliente (aplica a todos los items)
   - Producto que exista en el catálogo
   - Motivo que exista en el catálogo
   - Cantidad entre 1 y 999 piezas
   - Justificación si cantidad > 30 piezas o si el motivo requiere justificación
5. No puede haber duplicados en los items (mismo SKU + motivo)
6. Máximo 50 items por grupo
7. El grupo se crea en estado "Pendiente" (statusAutorizado=0)
8. El grupo es para un solo cliente (NUD en el cuerpo principal)
9. La fechaEntrega se calcula automáticamente según calendario de ruta/NUD

**Flujo Típico:**
\`\`\`
Usuario completa formulario con items
  ↓
POST /captura_cambios
  ↓
Sistema valida y crea grupo
  ↓
  Retorna folio virtual (ej: 123-1-10001-2025-11-04) con fechaEntrega calculada
  ↓
Usuario puede editar o autorizar
\`\`\`

**Ejemplo de Uso:**
Promotor captura que Cliente 10001 reporta 25 Pepsis dañadas.
El sistema calcula automáticamente la fecha de entrega válida.
Sistema crea grupo y retorna folio.
    `,
    },
    header: {
      'x-api-key': {
        name: 'x-api-key',
        description: `🔐 **API Key para autenticación (REQUERIDO)**

Contacta al administrador para obtener tu API Key.

**Keys por defecto:**
- \`pcm-mobile-app-key-2025\` - App móvil
- \`pcm-web-portal-key-2025\` - Portal web`,
        required: true,
        schema: {
          type: 'string',
          default: 'pcm-mobile-app-key-2025',
        },
      },
      'x-idempotency-key': {
        name: 'x-idempotency-key',
        description: `🔒 **UUID para prevenir duplicados (RECOMENDADO)**

Genera un UUID nuevo antes de cada petición:
\`\`\`javascript
const key = crypto.randomUUID();
\`\`\`

Si la petición falla por red, reintenta con la MISMA key para evitar duplicados.`,
        required: false,
        schema: {
          type: 'string',
          format: 'uuid',
          example: '550e8400-e29b-41d4-a716-446655440001',
        },
      },
    },
    responses: {
      created: {
        status: 201,
        description: 'Grupo de cambios creado correctamente',
        type: CambioGroupResponseDTO,
      },
      unauthorized: {
        status: 401,
        description: '🔐 No autorizado - API Key faltante o inválida',
        schema: {
          example: {
            statusCode: 401,
            message: 'API Key no proporcionada o inválida',
            error: 'Unauthorized',
            hint: 'Agrega el header: x-api-key: tu-api-key-aqui',
          },
        },
      },
      notFound: {
        status: 404,
        description: 'Operación o ruta no encontrada',
      },
      conflict: {
        status: 409,
        description: 'Ya existe un grupo activo para este pppcaptura + fecha',
      },
      unprocessableEntity: {
        status: 422,
        description: 'Errores de validación (SKU no elegible, fuera de rango)',
      },
    },
  },
  active: {
    operation: {
      summary: '5️⃣ Consultar grupo activo',
      description: `
**FLUJO:**
Verificar si existe un grupo pendiente para una ruta, cliente y fecha específica.

**Propósito:**
- Evitar crear duplicados
- Recuperar un grupo existente para continuar editándolo
- Validar antes de iniciar nueva captura
- Obtener cambios del cliente especificado

**🔐 AUTENTICACIÓN:**

\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X GET "${SWAGGER_BASE_URL}/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001" \\
  -H "x-api-key: pcm-mobile-app-key-2025"
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const response = await fetch('/api/v2/captura_cambios/active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001', {
  headers: { 'x-api-key': 'pcm-mobile-app-key-2025' }
});
if (response.status === 204) {
  console.log('No hay cambios activos para este cliente');
} else {
  const grupo = await response.json();
  console.log('Items del cliente 10001:', grupo.data.items);
}
\`\`\`

**Reglas de Negocio:**
1. Solo retorna grupos en estado "Pendiente" (statusAutorizado=0)
2. Grupos autorizados (1) o declinados (2) NO se retornan
3. Si no hay grupo activo, retorna 204 No Content (sin body)
4. Retorna solo los items del NUD especificado
5. Si el grupo existe pero no tiene items del NUD especificado, retorna 204

**Flujo Típico:**
\`\`\`
Usuario está capturando para cliente 10001
  ↓
Verificar si ya hay cambios para este cliente:
GET /active?pppcaptura=123&fecha=2025-11-04&idoperacion=1&nud=10001
  ↓
200 → Ya existe cambio para este cliente, evitar duplicado
204 → No existe, permitir agregar
\`\`\`

**Ejemplo de Uso:**
Sistema verifica si el promotor de ruta 123 ya tiene cambios capturados
para el cliente 10001 hoy, antes de permitirle agregar más items.
    `,
    },
    header: {
      'x-api-key': {
        name: 'x-api-key',
        description: '🔐 API Key para autenticación (REQUERIDO)',
        required: true,
        schema: {
          type: 'string',
          default: 'pcm-mobile-app-key-2025',
        },
      },
    },
    queries: {
      pppcaptura: {
        name: 'pppcaptura',
        description: 'Ruta del promotor (PPP)',
        example: 123,
        required: true,
      },
      fecha: {
        name: 'fecha',
        description: 'Fecha de cambio (YYYY-MM-DD) - Opcional',
        example: '2025-11-04',
        required: false,
      },
      idoperacion: {
        name: 'idoperacion',
        description: 'ID de operación/bodega',
        example: 1,
        required: true,
      },
      nud: {
        name: 'nud',
        description: 'NUD del cliente - Filtra items de este cliente',
        example: 10001,
        required: true,
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Grupo activo encontrado (completo o filtrado por NUD)',
        type: CambioGroupResponseDTO,
      },
      noContent: {
        status: 204,
        description:
          'No hay grupo activo o no hay items para el NUD especificado',
      },
      unauthorized: {
        status: 401,
        description: '🔐 No autorizado - API Key faltante o inválida',
        schema: {
          example: {
            statusCode: 401,
            message: 'API Key no proporcionada o inválida',
            error: 'Unauthorized',
          },
        },
      },
    },
  },
  //   getFolio: {
  //     operation: {
  //       summary: '5️⃣ Obtener grupo por folio virtual',
  //       description: `
  // **FLUJO DE CONSULTA:**
  // Recuperar un grupo específico por su folio virtual para visualización o edición.

  // **🔐 AUTENTICACIÓN:**

  // \`\`\`
  // x-api-key: pcm-mobile-app-key-2025
  // \`\`\`

  // **Ejemplo cURL:**
  // \`\`\`bash
// curl -X GET "${SWAGGER_BASE_URL}/captura_cambios/123-1-10001-2025-10-30" \\
  //   -H "x-api-key: pcm-mobile-app-key-2025"
  // \`\`\`

  // **Ejemplo JavaScript:**
  // \`\`\`javascript
// const response = await fetch('/api/v2/captura_cambios/123-1-10001-2025-10-30', {
  //   headers: { 'x-api-key': 'pcm-mobile-app-key-2025' }
  // });
  // const grupo = await response.json();
  // \`\`\`

  // **Propósito:**
  // - Recuperar detalles completos de un grupo existente
  // - Ver items capturados con sus productos, motivos y cantidades
  // - Verificar estado de autorización
  // - Consultar fechas de entrega calculadas

  // **Reglas de Negocio:**
// 1. El folio debe existir en formato: {pppcaptura}-{idBodega}-{nud}-{fecha}
  // 2. Retorna el grupo sin importar su estado (Pendiente, Autorizado, Declinado)
  // 3. Incluye información de todos los clientes y productos del grupo
  // 4. Muestra fecha de entrega calculada por item

  // **Flujo Típico:**
  // \`\`\`
  // Usuario busca grupo existente
  //   ↓
// GET /captura_cambios/123-1-10001-2025-10-30
  //   ↓
  // Sistema retorna grupo completo con todos los items
  //   ↓
  // Usuario puede visualizar, editar o autorizar (según estado)
  // \`\`\`

  // **Ejemplo de Uso:**
  // Supervisor quiere revisar qué cambios capturó la ruta 123 el día 30 de octubre.
  // Sistema muestra todos los clientes y productos incluidos en ese grupo.
  //     `,
  //     },
  //     header: {
  //       'x-api-key': {
  //         name: 'x-api-key',
  //         description: '🔐 API Key para autenticación (REQUERIDO)',
  //         required: true,
  //         schema: {
  //           type: 'string',
  //           default: 'pcm-mobile-app-key-2025',
  //         },
  //       },
  //     },
  //     params: {
  //       folio: {
  //         name: 'folio',
  //         description: 'Folio virtual del grupo',
//         example: '123-1-10001-2025-10-30',
  //       },
  //     },
  //     responses: {
  //       ok: {
  //         status: 200,
  //         description: 'Grupo recuperado correctamente',
  //         type: CambioGroupResponseDTO,
  //       },
  //       unauthorized: {
  //         status: 401,
  //         description: '🔐 No autorizado - API Key faltante o inválida',
  //         schema: {
  //           example: {
  //             statusCode: 401,
  //             message: 'API Key no proporcionada o inválida',
  //             error: 'Unauthorized',
  //           },
  //         },
  //       },
  //       notFound: {
  //         status: 404,
  //         description: 'Grupo no encontrado',
  //       },
  //     },
  //   },
  putFolio: {
    operation: {
      summary: '6️⃣ Actualizar grupo de cambios',
      description: `
**FLUJO DE EDICIÓN:**
Modificar un grupo de cambios existente mientras esté en estado Pendiente.

**Propósito:**
- Actualizar items de un grupo ya creado (agregar, modificar, eliminar)
- Corregir cantidades o cambiar motivos
- Agregar o modificar justificaciones
- Ajustar comentarios del grupo

**🔐 AUTENTICACIÓN:**

Este endpoint requiere API Key. Envíala en el header:
\`\`\`
x-api-key: tu-api-key-aqui
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X PUT "${SWAGGER_BASE_URL}/captura_cambios/123-1-10001-2025-11-04" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: pcm-mobile-app-key-2025" \\
  -H "x-idempotency-key: 550e8400-e29b-41d4-a716-446655440001" \\
  -d '{
    "NUD": 10001,
    "pppcaptura": 123,
    "ID_Bodega": 1,
    "items": [
      {
        "clave_producto": 123456,
        "id_motivo": 1,
        "piezas": 30,
        "justificacion": "Corrección de cantidad"
      }
    ]
  }'
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const idempotencyKey = crypto.randomUUID();

const response = await fetch('/api/v2/captura_cambios/123-1-10001-2025-11-04', {
  method: 'PUT',
headers: {
  'Content-Type': 'application/json',
  'x-api-key': 'pcm-mobile-app-key-2025',
  'x-idempotency-key': idempotencyKey
},
body: JSON.stringify({
  NUD: 10001,
  pppcaptura: 123,
  ID_Bodega: 1,
  items: [{
    clave_producto: 123456,
    id_motivo: 1,
    piezas: 30,
    justificacion: "Corrección de cantidad"
  }]
  })
});
\`\`\`

**Reglas de Negocio:**
1. Despacho fijo (tipo=1): sólo actualiza si statusAutorizado = 0
2. Despacho dinámico (tipo=2): sólo actualiza si statusAutorizado = 0 y (estatusDis = 0 o idruta = null)
3. El pppcaptura e ID_Bodega deben coincidir con los del folio
4. La operación es idempotente (puede reintentarse sin efectos duplicados)
5. Al actualizar, se reemplazan TODOS los items del grupo con los nuevos
6. Las validaciones de catálogo, límites y duplicados aplican igual que en creación
7. El folio virtual y la fecha de entrega se recalculan tomando la fecha actual como referencia
8. Se aplican las mismas reglas y validaciones del POST de creación

**Comportamiento:**
- Los items existentes se eliminan y se crean los nuevos
- La fechaEntrega se recalcula automáticamente con la fecha actual
- El NUD se envía a nivel raíz y aplica a todos los items

**Flujo Típico:**
\`\`\`
Usuario detecta error en grupo pendiente
  ↓
GET /captura_cambios/123-1-10001-2025-11-04 → Verifica estado
  ↓
PUT /captura_cambios/123-1-10001-2025-11-04
Body: { NUD, pppcaptura, ID_Bodega, items: [{SKU, ...}] }
  ↓
Sistema:
  1. Valida que esté Pendiente según tipo de ruta (fija: statusAutorizado=0; dinámica: statusAutorizado=0 y estatusDis=0 o ruta=null)
  2. Valida que pppcaptura e ID_Bodega coincidan con el folio
  3. Valida que la ruta exista y tipo (fija o dinámica) según reglas
  4. Elimina items antiguos
  5. Crea items nuevos con validaciones (NUD, fechaEntrega calculada, etc.)
  6. Retorna grupo actualizado
\`\`\`

**Ejemplo de Uso:**
Promotor capturó 50 Pepsis dañadas, pero eran 30.
Antes de autorizar, actualiza la cantidad a 30 piezas.
El sistema valida y guarda los cambios.

**Errores Comunes:**
- 409 Conflict: Grupo ya fue autorizado o cerrado para despacho
- 403 Forbidden: El pppcaptura no coincide con el grupo
- 422 Unprocessable: Items no válidos (SKU no existe, fuera de rango, duplicados)

**Compatibilidad Legacy:**
Replica el comportamiento de \`actualizarCmotivos.php\` que elimina y recrea items.
    `,
    },
    header: {
      'x-api-key': {
        name: 'x-api-key',
        description: `🔐 **API Key para autenticación (REQUERIDO)**

**Cómo obtenerla:**
Contacta al administrador del sistema para obtener tu API Key.

**Keys disponibles por defecto:**
- \`pcm-mobile-app-key-2025\` - Para app móvil
- \`pcm-web-portal-key-2025\` - Para portal web  
- \`pcm-integration-key-2025\` - Para integraciones

**Ejemplo de uso:**
\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\``,
        required: true,
        schema: {
          type: 'string',
          default: 'pcm-mobile-app-key-2025',
        },
      },
      'x-idempotency-key': {
        name: 'x-idempotency-key',
        description: `🔒 **UUID para prevenir operaciones duplicadas (RECOMENDADO)**

**¿Qué es?**
Identificador único que garantiza que si envías la misma petición dos veces, solo se procesa una vez.

**¿Cómo generarlo?**

**JavaScript/TypeScript:**
\`\`\`javascript
const idempotencyKey = crypto.randomUUID();
// Ejemplo: "550e8400-e29b-41d4-a716-446655440001"
\`\`\`

**Python:**
\`\`\`python
import uuid
idempotency_key = str(uuid.uuid4())
\`\`\`

**Bash/cURL:**
\`\`\`bash
IDEMPOTENCY_KEY=$(uuidgen)
\`\`\`

**¿Cuándo usarlo?**
- ✅ Operaciones críticas (crear, actualizar, eliminar)
- ✅ Cuando puede haber reintentos automáticos
- ✅ En conexiones inestables

**¿Cuándo NO usarlo?**
- ❌ Consultas (GET) - ya son idempotentes por naturaleza`,
        required: false,
        schema: {
          type: 'string',
          format: 'uuid',
          example: '550e8400-e29b-41d4-a716-446655440001',
        },
      },
    },
    params: {
      folio: {
        name: 'folio',
        description: 'Folio virtual del grupo a actualizar',
        example: '123-1-10001-2025-10-30',
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Grupo actualizado correctamente',
        type: CambioGroupResponseDTO,
      },
      unauthorized: {
        status: 401,
        description: '🔐 No autorizado - API Key faltante o inválida',
        schema: {
          example: {
            statusCode: 401,
            message: 'API Key no proporcionada o inválida',
            error: 'Unauthorized',
            hint: 'Agrega el header: x-api-key: tu-api-key-aqui',
          },
        },
      },
      forbidden: {
        status: 403,
        description: 'El pppcaptura no coincide con el grupo',
        schema: {
          example: {
            result: {
              data: {},
              successful: false,
              errors: {
                code: 'FORBIDDEN',
                detail: 'El pppcaptura no coincide con el grupo original.',
              },
            },
          },
        },
      },
      notFound: {
        status: 404,
        description: 'Grupo no encontrado',
      },
      conflict: {
        status: 409,
        description: 'El grupo no puede actualizarse en su estado actual',
        schema: {
          example: {
            result: {
              data: {},
              successful: false,
              errors: {
                code: 'CONFLICT',
                detail:
                  'El grupo no puede actualizarse porque ya fue autorizado o el despacho fue cerrado.',
              },
            },
          },
        },
      },
      unprocessableEntity: {
        status: 422,
        description: 'Errores de validación en los items',
      },
    },
  },
  deleteFolio: {
    operation: {
      summary: '7️⃣ Elimina grupo',
      description: `
**FLUJO DE ELIMINACIÓN:**
Este endpoint elimina un grupo de cambios pendiente, utilizando su folio virtual.
La eliminación es física: el registro del grupo y todos sus items son removidos de la base de datos para evitar que el proceso de autorización los considere.

**Propósito:**
- Permitir al cliente eliminar su propio grupo de cambios antes de autorización
- Eliminar el registro del grupo de cambios
- Notificar al sistema legacy que el grupo fue eliminado

**🔐 AUTENTICACIÓN:**

\`\`\`
x-api-key: pcm-mobile-app-key-2025
\`\`\`

**Ejemplo cURL:**
\`\`\`bash
curl -X DELETE "${SWAGGER_BASE_URL}/captura_cambios/123-1-10001-2025-10-30" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: pcm-mobile-app-key-2025" \\
  -H "x-idempotency-key: $(uuidgen)"
\`\`\`

**Ejemplo JavaScript:**
\`\`\`javascript
const response = await fetch('/api/v2/captura_cambios/123-1-10001-2025-10-30', {
  method: 'DELETE',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': 'pcm-mobile-app-key-2025',
    'x-idempotency-key': crypto.randomUUID()
  }
});
\`\`\`

**Reglas de Negocio:**
1. Solo se puede eliminar si statusAutorizado = 0 (Pendiente)
2. Grupos ya autorizados (1) o declinados (2) retornan 409 Conflict
3. La operación elimina físicamente el grupo y todos sus items
4. El endpoint NO actualiza estados
5. La operación es idempotente (puede reintentarse sin efectos duplicados)

**Flujo Típico:**
\`\`\`
Cliente captura cambios de inventario
  ↓
GET /captura_cambios/123-1-10001-2025-10-30 → Detecta error
  ↓
DELETE /captura_cambios/123-1-10001-2025-10-30
  ↓
Sistema:
  1. Valida que esté en estado Pendiente
  2. Elimina el registro
  3. Retorna confirmación
\`\`\`

**Ejemplo de Uso:**
El cliente decide eliminar el grupo antes de enviarlo a autorización por detectar errores en las cantidades o productos.

**Compatibilidad Legacy:**
Equivalente a la eliminación previa al envío en el sistema PHP legacy.
    `,
    },
    header: {
      'x-api-key': {
        name: 'x-api-key',
        description: '🔐 API Key para autenticación (REQUERIDO)',
        required: true,
        schema: {
          type: 'string',
          default: 'pcm-mobile-app-key-2025',
        },
      },
      'x-idempotency-key': {
        name: 'x-idempotency-key',
        description:
          '🔒 UUID para prevenir cancelaciones duplicadas (RECOMENDADO)',
        required: false,
        schema: {
          type: 'string',
          format: 'uuid',
          example: '550e8400-e29b-41d4-a716-446655440001',
        },
      },
    },
    params: {
      folio: {
        name: 'folio',
        description: 'Folio virtual del grupo',
        example: '123-1-10001-2025-10-30',
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Grupo eliminado correctamente',
      },
      unauthorized: {
        status: 401,
        description: '🔐 No autorizado - API Key faltante o inválida',
        schema: {
          example: {
            statusCode: 401,
            message: 'API Key no proporcionada o inválida',
            error: 'Unauthorized',
          },
        },
      },
      notFound: {
        status: 404,
        description: 'Grupo no encontrado',
      },
      conflict: {
        status: 409,
        description: 'El grupo no puede eliminarse en su estado actual',
      },
    },
  },
  //   submitFolio: {
  //     operation: {
  //       summary: '7️⃣ Autorizar grupo (submit)',
  //       description: `
  // **FLUJO DE AUTORIZACIÓN:**
  // Aprobar un grupo de cambios pendiente para que sea procesado por el sistema.

  // **Propósito:**
  // - Cambiar estado del grupo de "Pendiente" (0) a "Autorizado" (1)
  // - Registrar quién autorizó y cuándo
  // - Permitir que el grupo sea procesado para despacho
  // - Notificar al sistema legacy que el grupo está aprobado

  // **🔐 AUTENTICACIÓN:**

  // \`\`\`
  // x-api-key: pcm-mobile-app-key-2025
  // \`\`\`

  // **Ejemplo cURL:**
  // \`\`\`bash
// curl -X POST "${SWAGGER_BASE_URL}/captura_cambios/123-1-10001-2025-10-30/submit" \\
  //   -H "x-api-key: pcm-mobile-app-key-2025" \\
  //   -H "x-idempotency-key: $(uuidgen)"
  // \`\`\`

  // **Ejemplo JavaScript:**
  // \`\`\`javascript
// const response = await fetch('/api/v2/captura_cambios/123-1-10001-2025-10-30/submit', {
  //   method: 'POST',
  //   headers: {
  //     'x-api-key': 'pcm-mobile-app-key-2025',
  //     'x-idempotency-key': crypto.randomUUID()
  //   }
  // });
  // \`\`\`

  // **Reglas de Negocio:**
  // 1. Solo se puede autorizar si statusAutorizado = 0 (Pendiente)
  // 2. Grupos ya autorizados (1) o declinados (2) retornan 409 Conflict
  // 3. Se actualiza \`numAutorizador\` con el usuario que autoriza
  // 4. Se registra \`tiempoAutorizado\` con timestamp actual
  // 5. La operación es idempotente (puede reintentarse sin efectos duplicados)

  // **Flujo Típico:**
  // \`\`\`
  // Supervisor revisa grupo pendiente
  //   ↓
// GET /captura_cambios/123-1-10001-2025-10-30 → Verifica items
  //   ↓
// POST /captura_cambios/123-1-10001-2025-10-30/submit
  //   ↓
  // Sistema:
  //   1. Valida que esté en estado Pendiente
  //   2. Cambia statusAutorizado = 1
  //   3. Registra numAutorizador y tiempoAutorizado
  //   4. Retorna confirmación
  // \`\`\`

  // **Ejemplo de Uso:**
  // Supervisor aprueba cambios de 3 clientes capturados por ruta 123.
  // El grupo pasa de "Pendiente" a "Autorizado" y puede ser despachado.

  // **Compatibilidad Legacy:**
  // Este flujo replica el comportamiento de \`guardarConfirmacionCambios.php\`.
  //     `,
  //     },
  //     header: {
  //       'x-api-key': {
  //         name: 'x-api-key',
  //         description: '🔐 API Key para autenticación (REQUERIDO)',
  //         required: true,
  //         schema: {
  //           type: 'string',
  //           default: 'pcm-mobile-app-key-2025',
  //         },
  //       },
  //       'x-idempotency-key': {
  //         name: 'x-idempotency-key',
  //         description:
  //           '🔒 UUID para prevenir autorizaciones duplicadas (RECOMENDADO)',
  //         required: false,
  //         schema: {
  //           type: 'string',
  //           format: 'uuid',
  //           example: '550e8400-e29b-41d4-a716-446655440001',
  //         },
  //       },
  //     },
  //     params: {
  //       folio: {
  //         name: 'folio',
  //         description: 'Folio virtual del grupo',
//         example: '123-1-10001-2025-10-30',
  //       },
  //     },
  //     responses: {
  //       ok: {
  //         status: 200,
  //         description: 'Grupo autorizado correctamente',
  //       },
  //       unauthorized: {
  //         status: 401,
  //         description: '🔐 No autorizado - API Key faltante o inválida',
  //         schema: {
  //           example: {
  //             statusCode: 401,
  //             message: 'API Key no proporcionada o inválida',
  //             error: 'Unauthorized',
  //           },
  //         },
  //       },
  //       notFound: {
  //         status: 404,
  //         description: 'Grupo no encontrado',
  //       },
  //       conflict: {
  //         status: 409,
  //         description: 'El grupo no puede autorizarse en su estado actual',
  //       },
  //     },
  //   },
};

export const catalogosDocs: ContentStructure = {
  operaciones: {
    operation: {
      summary: 'Listar operaciones/bodegas disponibles',
      description: `
**CATÁLOGO PARA INDEPENDENCIA DEL LEGACY:**
Obtener lista de operaciones/bodegas activas con información del depósito.

**Propósito:**
- Listar operaciones disponibles para selección en formularios
- Mostrar información del depósito asociado
- Filtrar por zona (opcional)

**Uso Típico:**
\`\`\`
Usuario abre aplicación
  ↓
GET /catalogos/operaciones
  ↓
Muestra dropdown de operaciones
  ↓
Usuario selecciona → Usa idoperacion en /access y /catalog
\`\`\`

**Por qué es necesario:**
Sin este catálogo, el frontend depende del sistema legacy PHP para saber qué
operaciones existen. Este endpoint permite total independencia.
    `,
    },
    queries: {
      idZona: {
        name: 'idZona',
        description: 'ID de zona (opcional) para filtrar operaciones',
        example: 1,
        required: false,
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Operaciones recuperadas exitosamente',
        schema: {
          example: {
            result: {
              data: {
                operaciones: [
                  {
                    idoperacion: 1,
                    descripcion: 'CEDIS Monterrey',
                    idDeposito: 1,
                    deposito_nombre: 'Depósito Norte',
                    tipoMercado: 0,
                    tipoMercado_nombre: 'Tradicional',
                    estatus: 1,
                  },
                  {
                    idoperacion: 2,
                    descripcion: 'CEDIS Guadalajara',
                    idDeposito: 2,
                    deposito_nombre: 'Depósito Occidente',
                    tipoMercado: 1,
                    tipoMercado_nombre: 'Moderno',
                    estatus: 1,
                  },
                ],
              },
              successful: true,
              message: 'Operaciones recuperadas correctamente.',
            },
          },
        },
      },
    },
  },
  rutas: {
    operation: {
      summary: 'Listar rutas (PPPs) por operación',
      description: `
**CATÁLOGO PARA INDEPENDENCIA DEL LEGACY:**
Obtener lista de rutas (PPPs) activas para una operación específica.

**Propósito:**
- Listar rutas disponibles filtradas por operación
- Mostrar información de tipo y días de entrega
- Filtrar por tipo de mercado (opcional)

**Uso Típico:**
\`\`\`
Usuario selecciona operación (ej: id=1)
  ↓
GET /catalogos/rutas?idoperacion=1
  ↓
Muestra dropdown de rutas
  ↓
Usuario selecciona ruta → Usa pppcaptura en /access
\`\`\`

**Por qué es necesario:**
Sin este catálogo, el frontend no sabe qué rutas (PPPs) están activas para
una operación. Este endpoint permite total independencia del legacy.
    `,
    },
    queries: {
      idOperacion: {
        name: 'idoperacion',
        description: 'ID de operación (requerido)',
        example: 1,
        required: true,
      },
      tmercado: {
        name: 'tmercado',
        description: 'Tipo de mercado (opcional): 0=Tradicional, 1=Moderno',
        example: 0,
        required: false,
      },
      tipo: {
        name: 'tipo',
        description: 'Tipo de ruta (opcional): 1=Fijo, 2=Dinámico',
        example: 1,
        required: false,
      },
    },
    responses: {
      ok: {
        status: 200,
        description: 'Rutas recuperadas exitosamente',
        schema: {
          example: {
            result: {
              data: {
                rutas: [
                  {
                    idruta: 1,
                    ruta: 123,
                    tipo: 1,
                    tipo_nombre: 'Fijo',
                    tmercado: 0,
                    tmercado_nombre: 'Tradicional',
                    dias_entrega: 3,
                    estatus: 1,
                  },
                  {
                    idruta: 2,
                    ruta: 456,
                    tipo: 2,
                    tipo_nombre: 'Dinámico',
                    tmercado: 1,
                    tmercado_nombre: 'Moderno',
                    dias_entrega: 2,
                    estatus: 1,
                  },
                ],
              },
              successful: true,
              message: 'Rutas recuperadas correctamente.',
            },
          },
        },
      },
      badRequest: {
        status: 400,
        description: 'idoperacion es requerido',
      },
    },
  },
};
