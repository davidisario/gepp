import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  HttpException,
  InternalServerErrorException,
  NotFoundException,
  UnauthorizedException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ApiResponseError } from '../responses/api-response-error';
import { ApiErrorDetails } from '../responses/api-error-details';
import { ErrorCodes } from '../enums/errorCodes';

type ErrorInput = ErrorCodes | ApiErrorDetails[];
type ErrorResult = {
  errors: ApiErrorDetails | ApiErrorDetails[];
  data?: any;
  message?: string;
};

export class ApiErrorFactory {
  private static create<T>(
    ExceptionType: new (response: any) => HttpException,
    errors: ApiErrorDetails | ApiErrorDetails[],
    data?: T,
    message?: string,
  ): HttpException {
    return new ExceptionType(new ApiResponseError(errors, data, message));
  }

  private static buildErrorArgs(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
    message?: string,
  ): ErrorResult {
    if (typeof codeOrErrors === 'string') {
      return {
        errors: new ApiErrorDetails(codeOrErrors, detailOrData as string),
        data: dataIfCode,
        message,
      };
    }

    return {
      errors: codeOrErrors,
      data: detailOrData,
      message,
    };
  }

  static badRequest(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static badRequest(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static badRequest(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): BadRequestException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(BadRequestException, errors, data);
  }

  static conflict(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static conflict(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static conflict(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): ConflictException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(ConflictException, errors, data);
  }

  static forbidden(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static forbidden(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static forbidden(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): ForbiddenException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(ForbiddenException, errors, data);
  }

  static internalServerError(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static internalServerError(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static internalServerError(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): InternalServerErrorException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(InternalServerErrorException, errors, data);
  }

  static notFound(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static notFound(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static notFound(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): NotFoundException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(NotFoundException, errors, data);
  }

  static unauthorized(
    code: ErrorCodes,
    detail: string,
    data?: any,
    message?: string,
  ): UnauthorizedException;
  static unauthorized(
    errors: ApiErrorDetails[],
    data?: any,
    message?: string,
  ): UnauthorizedException;

  static unauthorized(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
    message?: string,
  ): UnauthorizedException {
    const {
      errors,
      data,
      message: msg,
    } = this.buildErrorArgs(codeOrErrors, detailOrData, dataIfCode, message);
    return this.create(UnauthorizedException, errors, data, msg);
  }

  static unprocessable(
    code: ErrorCodes,
    detail: string,
    data?: any,
  ): UnprocessableEntityException;
  static unprocessable(
    errors: ApiErrorDetails[],
    data?: any,
  ): UnprocessableEntityException;

  static unprocessable(
    codeOrErrors: ErrorInput,
    detailOrData?: string | any,
    dataIfCode?: any,
  ): UnprocessableEntityException {
    const { errors, data } = this.buildErrorArgs(
      codeOrErrors,
      detailOrData,
      dataIfCode,
    );
    return this.create(UnprocessableEntityException, errors, data);
  }
}
