import { ApiResponseOk } from '../responses/api-response-ok';

export class ApiResponseFactory {
  static ok<T>(data: T, message?: string) {
    return new ApiResponseOk<T>(data, message);
  }

  static notContent() {
    return;
  }
}
