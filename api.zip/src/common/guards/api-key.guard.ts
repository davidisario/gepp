import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';
import { ApiKeyDefinition } from '../../config/apikey.config';
import { ApiErrorFactory } from '../factories/api-error-factory';
import { ErrorCodes } from '../enums/errorCodes';

@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(private configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const headerName = this.configService.get<string>('apikey.headerName');
    const apiKey = request.headers[headerName.toLowerCase()] as string;

    if (!apiKey) {
      throw ApiErrorFactory.unauthorized(
        ErrorCodes.MISSING_API_KEY,
        `Header ${headerName} es requerido`,
        {},
        'Autenticación requerida',
      );
    }

    // Validate UUID format
    const uuidRegex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(apiKey)) {
      throw ApiErrorFactory.unauthorized(
        ErrorCodes.INVALID_API_KEY_FORMAT,
        'El API Key debe tener formato UUID válido',
        {},
        'API Key inválida',
      );
    }

    // Get configured API keys
    const validKeys =
      this.configService.get<ApiKeyDefinition[]>('apikey.keys') || [];
    const keyData = validKeys.find((k) => k.key === apiKey);

    if (!keyData) {
      throw ApiErrorFactory.unauthorized(
        ErrorCodes.INVALID_API_KEY,
        'El API Key proporcionado no es válido',
        {},
        'API Key inválida',
      );
    }

    // Attach key data to request for use in controllers/services
    request['apiKeyData'] = keyData;

    return true;
  }
}
