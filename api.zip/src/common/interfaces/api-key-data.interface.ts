export interface ApiKeyData {
  key: string;
  name: string;
  description: string;
  permissions: string[];
  userId: number; // numCapturo - Número de empleado asociado a esta API Key
  idoperacion?: number;
  nivel?: number;
}
