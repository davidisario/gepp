export interface ApiResponse<T> {
  data: T;
  successful: boolean;
  message?: string;
  errors?: ApiError | ApiError[];
}

export interface ApiError {
  code: string;
  detail: string;
  field?: string;
}
