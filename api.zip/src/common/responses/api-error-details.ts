import { ErrorCodes } from '../enums/errorCodes';

export class ApiErrorDetails {
  code: ErrorCodes;
  detail: string;
  field?: string;

  constructor(code: ErrorCodes, detail: string, field?: string) {
    this.code = code;
    this.detail = detail;
    this.field = field;
  }
}
