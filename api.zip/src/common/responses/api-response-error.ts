import { ApiErrorDetails } from './api-error-details';
import { ApiResponse } from './api-response';

export class ApiResponseError<T> extends ApiResponse<T> {
  constructor(
    errors: ApiErrorDetails | ApiErrorDetails[],
    data: T = {} as T,
    message?: string,
  ) {
    super(false, data, message, { ...errors });
  }
}
