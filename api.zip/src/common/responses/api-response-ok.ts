import { ApiResponse } from './api-response';

export class ApiResponseOk<T> extends ApiResponse<T> {
  constructor(data: T, message?: string) {
    super(true, data, message, null);
  }
}
