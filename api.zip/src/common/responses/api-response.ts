import {
  ApiError,
  ApiResponse as ApiResponseType,
} from '../interfaces/api-response.interface';

export class ApiResponse<T> {
  result: ApiResponseType<T>;

  constructor(
    successful: boolean,
    data: T,
    message?: string,
    errors?: ApiError | ApiError[],
  ) {
    this.result = {
      data,
      successful,
      message,
      errors,
    };
  }
}
