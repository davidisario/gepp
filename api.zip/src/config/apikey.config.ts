import { registerAs } from '@nestjs/config';

export interface ApiKeyConfig {
  enabled: boolean;
  headerName: string;
  keys: ApiKeyDefinition[];
}

export interface ApiKeyDefinition {
  key: string; // UUID format
  name: string;
  description: string;
  permissions: string[];
  userId: number; // numCapturo - Número de empleado asociado
  idoperacion?: number;
  nivel?: number;
}

export default registerAs(
  'apikey',
  (): ApiKeyConfig => ({
    enabled: true,
    headerName: process.env.API_KEY_HEADER_NAME || 'X-API-Key',
    // Hardcoded API Keys - Version 1
    // TODO: Move to database in future version
    keys: [
      {
        key: 'a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d',
        name: 'GEPP Service',
        description: 'API Key para servicio GEPP',
        permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
        userId: 99999, // Promotor de ejemplo
        idoperacion: 1,
        nivel: 4,
      },
      {
        key: 'f1e2d3c4-b5a6-4978-8c6d-5e4f3a2b1c0d',
        name: 'External Service',
        description: 'API Key para servicio externo',
        permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
        userId: 88888, // Usuario externo
        idoperacion: 1,
        nivel: 4,
      },
      {
        key: 'b2c3d4e5-f6a7-4b8c-9d0e-1f2a3b4c5d6e',
        name: 'Development Service',
        description: 'API Key para desarrollo y testing',
        permissions: ['cambio_mercado:read', 'cambio_mercado:write'],
        userId: 77777, // Usuario de desarrollo
        idoperacion: 1,
        nivel: 4,
      },
    ],
  }),
);
