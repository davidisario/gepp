import { registerAs } from '@nestjs/config';

export default registerAs('swagger', () => ({
  enabled:
    process.env.SWAGGER_ENABLED === 'true' ||
    process.env.NODE_ENV === 'development',
  title: process.env.SWAGGER_TITLE || 'Cambio de Mercado API',
  description:
    process.env.SWAGGER_DESCRIPTION ||
    'API REST para gestión de cambios de mercado. Incluye validaciones completas de restsku/restcedis y catálogos independientes para operaciones y rutas.',
  version: process.env.SWAGGER_VERSION || '2.0.1',
  path: 'docs',
}));
