import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

import { AppModule } from './app.module';
import { CapturaCambioModule } from './modules/captura-cambio/captura-cambio.module';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'debug'],
  });

  const configService = app.get(ConfigService);

  // Security
  app.use(helmet());

  // CORS
  app.enableCors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true,
  });

  // Global prefix
  const apiPrefix = configService.get<string>('app.apiPrefix');
  app.setGlobalPrefix(apiPrefix);

  // Validation pipe
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: false,
      },
    }),
  );

  // Swagger documentation
  if (configService.get<boolean>('swagger.enabled')) {
    const config = new DocumentBuilder()
      .setTitle(configService.get<string>('swagger.title'))
      .setDescription(configService.get<string>('swagger.description'))
      .setVersion(configService.get<string>('swagger.version'))
      .addApiKey(
        {
          type: 'apiKey',
          name: configService.get<string>('apikey.headerName') || 'X-API-Key',
          in: 'header',
          description:
            'API Key en formato UUID para autenticación service-to-service',
        },
        'api-key',
      )
      .build();

    const document = SwaggerModule.createDocument(app, config, {
      include: [CapturaCambioModule],
    });
    SwaggerModule.setup(
      configService.get<string>('swagger.path'),
      app,
      document,
    );

    console.log(
      `📚 Swagger documentation available at: http://localhost:${configService.get<number>('app.port')}/${apiPrefix}/${configService.get<string>('swagger.path')}`,
    );
  }

  const port = configService.get<number>('app.port');
  await app.listen(port);

  console.log(
    `🚀 Application is running on: http://localhost:${port}/${apiPrefix}`,
  );
}
bootstrap();
