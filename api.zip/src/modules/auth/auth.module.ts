import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

/**
 * AuthModule - API Key Authentication
 *
 * Version 1: API Keys are hardcoded in apikey.config.ts
 * Version 2: API Keys will be stored in database (ApiKey entity ready)
 *
 * Authentication is handled by ApiKeyGuard
 * No JWT/Passport dependencies needed for service-to-service auth
 */
// @Module({
//   imports: [ConfigModule],
//   providers: [],
//   exports: [],
// })
// export class AuthModule {}
