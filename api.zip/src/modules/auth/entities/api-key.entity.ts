import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

/**
 * Entity for API Keys (Future version - database storage)
 * Currently API Keys are hardcoded in apikey.config.ts
 * TODO: Migrate hardcoded keys to database in version 2
 */
@Entity('ApiKeys')
export class ApiKey {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'uniqueidentifier', unique: true })
  key: string; // UUID format

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  description: string;

  @Column({ type: 'nvarchar', length: 500 })
  permissions: string; // JSON string array

  @Column({ type: 'int', nullable: true })
  idoperacion: number;

  @Column({ type: 'int', nullable: true })
  nivel: number;

  @Column({ type: 'bit', default: true })
  isActive: boolean;

  @CreateDateColumn({ type: 'datetime' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'datetime' })
  updatedAt: Date;

  @Column({ type: 'datetime', nullable: true })
  lastUsedAt: Date;

  @Column({ type: 'datetime', nullable: true })
  expiresAt: Date;
}
