import { CacheModule } from '@nestjs/cache-manager';
import { CambioMercadoController } from './controllers/cambio-mercado.controller';
import { CambiosMotivo } from '../motivos/entities/cambios-motivo.entity';
import { CatalogService } from './services/catalog.service';
import { Module } from '@nestjs/common';
import { Operation } from '../operations/entities/operation.entity';
import { Product } from '../products/entities/product.entity';
import { ProductoCambios } from '../products/entities/producto-cambios.entity';
import { Ticket } from '../tickets/entities/ticket.entity';
import { TicketItem } from '../tickets/entities/ticket-item.entity';
import { TicketService } from './services/ticket.service';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Product,
      ProductoCambios,
      CambiosMotivo,
      Operation,
      Ticket,
      TicketItem,
    ]),
    CacheModule.register({
      ttl: 3600, // 1 hora
      max: 100,
    }),
  ],
  controllers: [CambioMercadoController],
  providers: [CatalogService, TicketService],
  exports: [CatalogService, TicketService],
})
export class CambioMercadoModule {}
