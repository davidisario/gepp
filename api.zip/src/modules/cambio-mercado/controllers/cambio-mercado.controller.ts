import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
  Headers,
} from '@nestjs/common';
import {
  ApiTags,
  ApiSecurity,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiHeader,
} from '@nestjs/swagger';
import { ApiKeyGuard } from '../../../common/guards/api-key.guard';
import { CurrentApiKey } from '../../../common/decorators/api-key-data.decorator';
import { CatalogService } from '../services/catalog.service';
import { TicketService } from '../services/ticket.service';
import { CatalogQueryDTO } from '../dto/catalog-query.dto';
import { CreateTicketDTO } from '../dto/create-ticket.dto';
import { UpdateTicketDTO } from '../dto/update-ticket.dto';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiResponse as ApiResponseType } from '../../../common/responses/api-response';
import { ApiResponseFactory } from 'src/common/factories/api-response-factory';
import { CatalogDataDTO } from '../dto/catalog-response.dto';
import { CheckAccessDTO } from '../dto/check-access.dto';
import { TicketDTO } from 'src/modules/tickets/dto/ticket.dto';
import { CreatedTicketDTO } from 'src/modules/tickets/dto/ceated-ticket.dto';
import { UpdatedTicketDTO } from 'src/modules/tickets/dto/updated-ticket.dto';
import { SentTicketDTO } from 'src/modules/tickets/dto/sent-ticket.dto';
import { CancelledTicketDTO } from 'src/modules/tickets/dto/cancelled-ticket.dto';
import { TicketByFolioDTO } from 'src/modules/tickets/dto/ticket-by-folio.dto';

@ApiTags('Cambio de Mercado')
@Controller('cambio_mercado')
@UseGuards(ApiKeyGuard)
@ApiSecurity('api-key')
export class CambioMercadoController {
  constructor(
    private readonly catalogService: CatalogService,
    private readonly ticketService: TicketService,
  ) {}

  // ======================
  // ACCESS ENDPOINT
  // ======================
  @Get('access')
  @ApiOperation({
    summary: 'Verificar elegibilidad de acceso',
    description:
      'Verifica si el servicio tiene acceso al módulo y si existen tickets activos',
  })
  @ApiResponse({ status: 200, description: 'Acceso habilitado al módulo' })
  @ApiResponse({ status: 403, description: 'API Key no autorizado' })
  async checkAccess(
    @Query() query: CatalogQueryDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CheckAccessDTO>> {
    const activeTicket = await this.ticketService.getActiveTicket(
      query,
      apiKeyData,
    );

    return ApiResponseFactory.ok<CheckAccessDTO>(
      {
        access: true,
        has_active_ticket: !!activeTicket,
        active_ticket_folio: activeTicket?.folio,
      },
      'Acceso habilitado al módulo.',
    );
  }

  // ======================
  // CATALOG ENDPOINT
  // ======================
  @Get('catalog')
  @ApiOperation({
    summary: 'Obtener catálogo de productos y motivos',
    description:
      'Retorna productos elegibles para cambios y motivos disponibles',
  })
  @ApiResponse({
    status: 200,
    description: 'Catálogo recuperado correctamente',
  })
  @ApiResponse({ status: 404, description: 'No se halló catálogo' })
  async getCatalog(
    @Query() query: CatalogQueryDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CatalogDataDTO>> {
    const catalog = await this.catalogService.getCatalog(query, apiKeyData);

    return ApiResponseFactory.ok<CatalogDataDTO>(
      catalog,
      'Catálogo recuperado correctamente.',
    );
  }

  // ======================
  // ACTIVE TICKET ENDPOINT
  // ======================
  @Get('tickets/active')
  @ApiOperation({
    summary: 'Consultar ticket activo',
    description:
      'Retorna el ticket activo para una combinación Bodega-NUD. Si no existe, retorna 204 No Content.',
  })
  @ApiResponse({
    status: 200,
    description: 'Ticket activo encontrado',
  })
  @ApiResponse({
    status: 204,
    description: 'No existe ticket activo',
  })
  async getActiveTicket(
    @Query() query: CatalogQueryDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<TicketDTO> | void> {
    const ticket = await this.ticketService.getActiveTicket(query, apiKeyData);

    if (!ticket) {
      return ApiResponseFactory.notContent();
    }

    return ApiResponseFactory.ok<TicketDTO>(
      ticket,
      'Ticket activo recuperado.',
    );
  }

  // ======================
  // CREATE TICKET ENDPOINT
  // ======================
  @Post('tickets')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'Crear nuevo ticket',
    description:
      'Crea un nuevo ticket de cambio con validación completa de reglas de negocio',
  })
  @ApiHeader({
    name: 'X-Idempotency-Key',
    description: 'UUID para prevenir creaciones duplicadas (recomendado)',
    required: false,
  })
  @ApiResponse({
    status: 201,
    description: 'Ticket creado correctamente',
  })
  @ApiResponse({ status: 409, description: 'Ya existe un ticket activo' })
  @ApiResponse({
    status: 422,
    description: 'Errores de validación de negocio',
  })
  async createTicket(
    @Body() dto: CreateTicketDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<CreatedTicketDTO>> {
    const ticket = await this.ticketService.createTicket(
      dto,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<CreatedTicketDTO>(
      ticket,
      'Ticket creado correctamente.',
    );
  }

  // ======================
  // UPDATE TICKET ENDPOINT
  // ======================
  @Put('tickets/:folio')
  @ApiOperation({
    summary: 'Editar ticket',
    description: 'Actualiza los items de un ticket en estado editable',
  })
  @ApiParam({
    name: 'folio',
    example: 'A00002',
    description: 'Folio del ticket',
  })
  @ApiResponse({
    status: 200,
    description: 'Ticket actualizado correctamente',
  })
  @ApiResponse({ status: 404, description: 'Ticket no encontrado' })
  @ApiResponse({ status: 409, description: 'Ticket no es editable' })
  async updateTicket(
    @Param('folio') folio: string,
    @Body() dto: UpdateTicketDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<UpdatedTicketDTO>> {
    const result = await this.ticketService.updateTicket(
      folio,
      dto,
      apiKeyData,
    );

    return ApiResponseFactory.ok<UpdatedTicketDTO>(
      result,
      'Ticket actualizado correctamente.',
    );
  }

  // ======================
  // SUBMIT TICKET ENDPOINT
  // ======================
  @Post('tickets/:folio/submit')
  @ApiOperation({
    summary: 'Enviar ticket (submit)',
    description:
      'Cambia el estado del ticket a SENT y dispara el proceso de cambio. Valida reglas finales y catálogo vigente.',
  })
  @ApiParam({
    name: 'folio',
    example: 'A00002',
    description: 'Folio del ticket a enviar',
  })
  @ApiHeader({
    name: 'X-Idempotency-Key',
    description: 'UUID para prevenir envíos duplicados (recomendado)',
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'Ticket enviado correctamente',
  })
  @ApiResponse({ status: 404, description: 'Ticket no encontrado' })
  @ApiResponse({
    status: 409,
    description: 'El ticket no puede enviarse en su estado actual',
  })
  @ApiResponse({
    status: 422,
    description:
      'Errores de validación final (SKU no elegible, fuera de rango)',
  })
  async submitTicket(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<SentTicketDTO>> {
    const result = await this.ticketService.submitTicket(
      folio,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<SentTicketDTO>(
      result,
      'Ticket enviado correctamente.',
    );
  }

  // ======================
  // CANCEL TICKET ENDPOINT
  // ======================
  @Delete('tickets/:folio')
  @ApiOperation({
    summary: 'Cancelar ticket',
    description: 'Cancela un ticket si su estado lo permite',
  })
  @ApiParam({
    name: 'folio',
    example: 'A00002',
    description: 'Folio del ticket a cancelar',
  })
  @ApiHeader({
    name: 'X-Idempotency-Key',
    description: 'UUID para prevenir cancelaciones duplicadas (recomendado)',
    required: false,
  })
  @ApiResponse({
    status: 200,
    description: 'Ticket cancelado correctamente',
  })
  @ApiResponse({ status: 404, description: 'Ticket no encontrado' })
  @ApiResponse({
    status: 409,
    description: 'El ticket no puede cancelarse en su estado actual',
  })
  async cancelTicket(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<CancelledTicketDTO>> {
    const result = await this.ticketService.cancelTicket(
      folio,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<CancelledTicketDTO>(
      result,
      'Ticket cancelado correctamente.',
    );
  }

  // ======================
  // GET TICKET BY FOLIO (OPCIONAL)
  // ======================
  @Get('tickets/:folio')
  @ApiOperation({
    summary: 'Obtener ticket por folio (Opcional)',
    description:
      'Recupera un ticket específico por su folio para rehidratación, soporte o auditoría',
  })
  @ApiParam({
    name: 'folio',
    example: 'A00002',
    description: 'Folio del ticket a consultar',
  })
  @ApiResponse({
    status: 200,
    description: 'Ticket recuperado correctamente',
  })
  @ApiResponse({ status: 404, description: 'Ticket no encontrado' })
  @ApiResponse({
    status: 403,
    description: 'Sin permisos para consultar este ticket',
  })
  async getTicketByFolio(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<TicketByFolioDTO>> {
    const ticket = await this.ticketService.getTicketByFolio(folio, apiKeyData);

    return ApiResponseFactory.ok<TicketByFolioDTO>(
      ticket,
      'Ticket recuperado correctamente.',
    );
  }
}
