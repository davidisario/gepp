import {
  IsInt,
  IsPositive,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';

import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CatalogQueryDTO {
  @ApiProperty({
    description: 'ID del depósito/CEDIS',
    example: 45,
    type: 'integer',
  })
  @Type(() => Number)
  @IsInt({ message: 'ID_Bodega debe ser un número entero' })
  @IsPositive({ message: 'ID_Bodega debe ser positivo' })
  ID_Bodega: number;

  @ApiProperty({
    description: 'Número Único de Distribuidor (ruta)',
    example: '12345',
    minLength: 1,
    maxLength: 20,
  })
  @IsString({ message: 'NUD debe ser una cadena de texto' })
  @MinLength(1, { message: 'NUD es requerido' })
  @MaxLength(20, { message: 'NUD debe tener máximo 20 caracteres' })
  @Matches(/^\d+$/, { message: 'NUD debe contener solo dígitos' })
  NUD: string;
}
