import { ApiProperty } from '@nestjs/swagger';

export class ProductoDTO {
  @ApiProperty({ example: 123456 })
  clave_producto: number;

  @ApiProperty({ example: '7Up 2L Pet' })
  descripcion: string;

  @ApiProperty({ example: 1 })
  minimo_permitido: number;

  @ApiProperty({ example: 99 })
  maximo_permitido: number;

  @ApiProperty({ example: 30 })
  maximo_para_alerta: number;

  @ApiProperty({ example: 'Piezas', required: false })
  unidad?: string;

  @ApiProperty({ example: 'Refrescos', required: false })
  categoria?: string;
}

export class MotivoDTO {
  @ApiProperty({ example: 1 })
  id_motivo: number;

  @ApiProperty({ example: 'Envase roto' })
  descripcion: string;
}

export class MotivoGroupDTO {
  @ApiProperty({ example: 'Producto Dañado' })
  agrupador: string;

  @ApiProperty({ type: [MotivoDTO] })
  items: MotivoDTO[];
}

export class CatalogDataDTO {
  @ApiProperty({ type: [ProductoDTO] })
  productos: ProductoDTO[];

  @ApiProperty({ type: [MotivoGroupDTO] })
  motivos: MotivoGroupDTO[];

  @ApiProperty({ example: '2025-10-30T10:30:00.000Z', required: false })
  generated_at?: string;

  @ApiProperty({ example: 'v1-2025-10-30', required: false })
  catalog_version?: string;
}
