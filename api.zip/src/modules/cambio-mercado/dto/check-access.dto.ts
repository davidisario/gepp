export class CheckAccessDTO {
  access: boolean;
  has_active_ticket: boolean;
  active_ticket_folio?: string;
}
