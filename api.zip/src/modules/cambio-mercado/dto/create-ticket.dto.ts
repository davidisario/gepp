import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsInt,
  IsOptional,
  IsPositive,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
  MinLength,
  ValidateNested,
} from 'class-validator';

import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateTicketItemDTO {
  @ApiProperty({ example: 123456 })
  @IsInt({ message: 'clave_producto debe ser un número entero' })
  @IsPositive({ message: 'clave_producto debe ser positivo' })
  clave_producto: number;

  @ApiProperty({ example: 1 })
  @IsInt({ message: 'id_motivo debe ser un número entero' })
  @IsPositive({ message: 'id_motivo debe ser positivo' })
  id_motivo: number;

  @ApiProperty({ example: 25, minimum: 1, maximum: 999 })
  @IsInt({ message: 'piezas debe ser un número entero' })
  @Min(1, { message: 'Mínimo 1 pieza' })
  @Max(999, { message: 'Máximo 999 piezas' })
  piezas: number;

  @ApiProperty({
    example: 'Llegaron rotas',
    required: false,
    minLength: 5,
    maxLength: 100,
  })
  @IsOptional()
  @IsString({ message: 'justificacion debe ser texto' })
  @MinLength(5, { message: 'Justificación mínimo 5 caracteres' })
  @MaxLength(100, { message: 'Justificación máximo 100 caracteres' })
  justificacion?: string;
}

export class CreateTicketDTO {
  @ApiProperty({ example: 45 })
  @IsInt({ message: 'ID_Bodega debe ser un número entero' })
  @IsPositive({ message: 'ID_Bodega debe ser positivo' })
  ID_Bodega: number;

  @ApiProperty({ example: '12345' })
  @IsString({ message: 'NUD debe ser texto' })
  @MinLength(1, { message: 'NUD es requerido' })
  @MaxLength(20, { message: 'NUD máximo 20 caracteres' })
  @Matches(/^\d+$/, { message: 'NUD debe contener solo dígitos' })
  NUD: string;

  @ApiProperty({ type: [CreateTicketItemDTO] })
  @IsArray({ message: 'items debe ser un array' })
  @ArrayMinSize(1, { message: 'Debe incluir al menos 1 item' })
  @ArrayMaxSize(10, { message: 'Máximo 10 items por ticket' })
  @ValidateNested({ each: true })
  @Type(() => CreateTicketItemDTO)
  items: CreateTicketItemDTO[];
}
