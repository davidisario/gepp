import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  ValidateNested,
} from 'class-validator';

import { ApiProperty } from '@nestjs/swagger';
import { CreateTicketItemDTO } from './create-ticket.dto';
import { Type } from 'class-transformer';

export class UpdateTicketDTO {
  @ApiProperty({ type: [CreateTicketItemDTO] })
  @IsArray({ message: 'items debe ser un array' })
  @ArrayMinSize(1, { message: 'Debe incluir al menos 1 item' })
  @ArrayMaxSize(10, { message: 'Máximo 10 items por ticket' })
  @ValidateNested({ each: true })
  @Type(() => CreateTicketItemDTO)
  items: CreateTicketItemDTO[];
}
