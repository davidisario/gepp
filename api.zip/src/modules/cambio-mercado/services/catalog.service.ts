import { Injectable, Inject, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { ProductoCambios } from '../../products/entities/producto-cambios.entity';
import { CambiosMotivo } from '../../motivos/entities/cambios-motivo.entity';
import { Operation } from '../../operations/entities/operation.entity';
import { CatalogQueryDTO } from '../dto/catalog-query.dto';
import {
  CatalogDataDTO,
  ProductoDTO,
  MotivoGroupDTO,
} from '../dto/catalog-response.dto';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { ErrorCodes } from 'src/common/enums/errorCodes';

@Injectable()
export class CatalogService {
  private readonly logger = new Logger(CatalogService.name);

  constructor(
    @InjectRepository(ProductoCambios)
    private readonly productoCambiosRepo: Repository<ProductoCambios>,
    @InjectRepository(CambiosMotivo)
    private readonly motivoRepo: Repository<CambiosMotivo>,
    @InjectRepository(Operation)
    private readonly operationRepo: Repository<Operation>,
    @Inject(CACHE_MANAGER)
    private cacheManager: Cache,
  ) {}

  async getCatalog(
    query: CatalogQueryDTO,
    apiKeyData: ApiKeyData,
  ): Promise<CatalogDataDTO> {
    // Intentar obtener del caché
    const cacheKey = `catalog:${query.ID_Bodega}:${query.NUD}`;
    const cached = await this.cacheManager.get<CatalogDataDTO>(cacheKey);

    if (cached) {
      this.logger.log({
        action: 'CATALOG_CACHE_HIT',
        apiKeyName: apiKeyData.name,
        ID_Bodega: query.ID_Bodega,
        NUD: query.NUD,
      });
      return cached;
    }

    // Validar operación
    const operation = await this.operationRepo.findOne({
      where: { idDeposito: query.ID_Bodega },
    });

    if (!operation) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.WAREHOUSE_NOT_FOUND,
        `No se encontró operación activa para la bodega ${query.ID_Bodega}`,
      );
    }

    // Validar acceso del servicio
    this.validateServiceAccess(apiKeyData, operation);

    // Obtener productos
    const productos = await this.getProductos(operation.idoperacion);

    // Obtener motivos
    const motivos = await this.getMotivos(
      operation.idoperacion,
      query.ID_Bodega,
    );

    const catalog: CatalogDataDTO = {
      productos,
      motivos,
      generated_at: new Date().toISOString(),
      catalog_version: this.generateCatalogVersion(productos, motivos),
    };

    // Almacenar en caché (1 hora)
    await this.cacheManager.set(cacheKey, catalog, 3600);

    this.logger.log({
      action: 'CATALOG_GENERATED',
      apiKeyName: apiKeyData.name,
      ID_Bodega: query.ID_Bodega,
      NUD: query.NUD,
      productos_count: productos.length,
      motivos_count: motivos.reduce((sum, g) => sum + g.items.length, 0),
    });

    return catalog;
  }

  private async getProductos(idoperacion: number): Promise<ProductoDTO[]> {
    const productos = await this.productoCambiosRepo
      .createQueryBuilder('pc')
      .innerJoinAndSelect('pc.producto', 'p')
      .where('pc.idoperacion = :idoperacion', { idoperacion })
      .andWhere('pc.estatus = 1')
      .orderBy('p.descripcion', 'ASC')
      .getMany();

    return productos.map((pc) => ({
      clave_producto: pc.sku,
      descripcion: pc.producto.descripcion,
      minimo_permitido: 1, // Default value - not in legacy schema
      maximo_permitido: 99, // Default value - not in legacy schema
      maximo_para_alerta: 30, // Default value - not in legacy schema
      unidad: pc.producto.presentacion || 'unidad', // Using presentacion field
      categoria: pc.producto.categoria,
    }));
  }

  private async getMotivos(
    idoperacion: number,
    idDeposito: number,
  ): Promise<MotivoGroupDTO[]> {
    // Query con filtro de CEDIS
    const motivosRaw = await this.motivoRepo
      .createQueryBuilder('cm')
      .andWhere(
        new Brackets((qb) => {
          qb.where('cm.restcedis IS NULL').orWhere(
            `EXISTS (
              SELECT 1 FROM STRING_SPLIT(cm.restcedis, ',') ss
              WHERE LTRIM(RTRIM(ss.value)) = :idDeposito
            )`,
            { idDeposito: idDeposito.toString() },
          );
        }),
      )
      .orderBy('cm.agrupador', 'ASC')
      .addOrderBy('cm.descripcion', 'ASC')
      .getMany();

    // Agrupar por agrupador
    const grupos = motivosRaw.reduce(
      (acc, motivo) => {
        if (!acc[motivo.agrupador]) {
          acc[motivo.agrupador] = [];
        }
        acc[motivo.agrupador].push({
          id_motivo: motivo.idcambiosmotivos,
          descripcion: motivo.descripcion,
        });
        return acc;
      },
      {} as Record<string, any[]>,
    );

    return Object.entries(grupos).map(([agrupador, items]) => ({
      agrupador,
      items,
    }));
  }

  private validateServiceAccess(
    apiKeyData: ApiKeyData,
    operation: Operation,
  ): void {
    // Verificar permisos del API Key
    const hasReadPermission = apiKeyData.permissions.includes(
      'cambio_mercado:read',
    );

    if (!hasReadPermission) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.INSUFFICIENT_PERMISSIONS,
        'El API Key no tiene permisos para consultar el catálogo',
      );
    }

    // Si el API Key tiene operación asignada, validar acceso
    if (
      apiKeyData.idoperacion &&
      apiKeyData.idoperacion !== operation.idoperacion
    ) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.OPERATION_ACCESS_DENIED,
        'El API Key no tiene acceso a esta operación',
      );
    }
  }

  private generateCatalogVersion(
    productos: ProductoDTO[],
    motivos: MotivoGroupDTO[],
  ): string {
    const date = new Date().toISOString().split('T')[0];
    const prodCount = productos.length;
    const motivoCount = motivos.reduce((sum, g) => sum + g.items.length, 0);
    return `v1-${date}-P${prodCount}-M${motivoCount}`;
  }
}
