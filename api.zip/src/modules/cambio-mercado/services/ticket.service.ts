import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, In, LessThan } from 'typeorm';
import { Ticket, TicketEstado } from '../../tickets/entities/ticket.entity';
import { TicketItem } from '../../tickets/entities/ticket-item.entity';
import { Operation } from '../../operations/entities/operation.entity';
import { CatalogQueryDTO } from '../dto/catalog-query.dto';
import { CreateTicketDTO, CreateTicketItemDTO } from '../dto/create-ticket.dto';
import { UpdateTicketDTO } from '../dto/update-ticket.dto';
import { CatalogService } from './catalog.service';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { ApiErrorDetails } from 'src/common/responses/api-error-details';
import { ErrorCodes } from 'src/common/enums/errorCodes';
import { TicketDTO } from 'src/modules/tickets/dto/ticket.dto';
import { UpdatedTicketDTO } from 'src/modules/tickets/dto/updated-ticket.dto';
import { CreatedTicketDTO } from 'src/modules/tickets/dto/ceated-ticket.dto';
import { SentTicketDTO } from 'src/modules/tickets/dto/sent-ticket.dto';
import { CancelledTicketDTO } from 'src/modules/tickets/dto/cancelled-ticket.dto';
import { TicketByFolioDTO } from 'src/modules/tickets/dto/ticket-by-folio.dto';
import { CatalogDataDTO } from '../dto/catalog-response.dto';

@Injectable()
export class TicketService {
  private readonly logger = new Logger(TicketService.name);

  constructor(
    @InjectRepository(Ticket)
    private readonly ticketRepository: Repository<Ticket>,
    @InjectRepository(TicketItem)
    private readonly ticketItemRepository: Repository<TicketItem>,
    @InjectRepository(Operation)
    private readonly operationRepository: Repository<Operation>,
    private readonly catalogService: CatalogService,
    private readonly dataSource: DataSource,
  ) {}

  // ======================
  // GET ACTIVE TICKET
  // ======================
  async getActiveTicket(
    query: CatalogQueryDTO,
    apiKeyData: ApiKeyData,
  ): Promise<TicketDTO | null> {
    // Validar acceso del servicio
    await this.validateServiceAccess(apiKeyData, query.ID_Bodega, query.NUD);

    // Buscar ticket activo
    const ticket = await this.findActiveTicket(query.ID_Bodega, query.NUD);

    if (!ticket) {
      this.logger.log({
        action: 'GET_ACTIVE_TICKET_NOT_FOUND',
        apiKeyName: apiKeyData.name,
        ID_Bodega: query.ID_Bodega,
        NUD: query.NUD,
      });
      return null;
    }

    // Validar acceso al ticket específico
    this.validateTicketAccess(apiKeyData, ticket);

    return {
      folio: ticket.folio,
      estado: ticket.estado,
      fecha_alta: ticket.created_at.toISOString().split('T')[0],
      fecha_cambio_estimado: ticket.fecha_cambio_estimado
        ?.toISOString()
        .split('T')[0],
      items: ticket.items.map((item) => ({
        clave_producto: item.clave_producto,
        descripcion_producto: item.producto.descripcion,
        id_motivo: item.id_motivo,
        descripcion_motivo: item.motivo.descripcion,
        piezas: item.piezas,
        justificacion: item.justificacion,
      })),
    };
  }

  // ======================
  // CREATE TICKET
  // ======================
  async createTicket(
    dto: CreateTicketDTO,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<CreatedTicketDTO> {
    // 1. Validar que no existe ticket activo
    await this.validateNoActiveTicket(dto.ID_Bodega, dto.NUD);

    // 2. Obtener catálogo vigente
    const catalog = await this.catalogService.getCatalog(
      { ID_Bodega: dto.ID_Bodega, NUD: dto.NUD },
      apiKeyData,
    );

    // 3. Validar items contra catálogo
    const validationErrors = await this.validateItemsAgainstCatalog(
      dto.items,
      catalog,
    );
    if (validationErrors.length > 0) {
      throw ApiErrorFactory.unprocessable(validationErrors);
    }

    // 4. Validar unicidad de items
    this.validateNoDuplicateItems(dto.items);

    // 5. Crear ticket en transacción
    const folio = await this.dataSource.transaction(async (manager) => {
      // 5.1 Generar folio único
      const folio = await this.generateUniqueFolio();

      // 5.2 Calcular fecha de cambio estimado
      const fechaCambioEstimado = this.calcularFechaCambioEstimado(new Date());

      // 5.3 Crear ticket
      const ticket = manager.create(Ticket, {
        folio,
        ID_Bodega: dto.ID_Bodega,
        NUD: dto.NUD,
        idoperacion: apiKeyData.idoperacion || 1,
        estado: TicketEstado.DRAFT,
        created_by: 1, // API Key - not user based
        fecha_cambio_estimado: fechaCambioEstimado,
      });

      await manager.save(ticket);

      // 5.4 Crear items
      const items = dto.items.map((item) =>
        manager.create(TicketItem, {
          folio,
          clave_producto: item.clave_producto,
          id_motivo: item.id_motivo,
          piezas: item.piezas,
          justificacion: item.justificacion,
        }),
      );

      await manager.save(items);

      return folio;
    });

    // 6. Log de éxito
    this.logger.log({
      action: 'CREATE_TICKET_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio,
      ID_Bodega: dto.ID_Bodega,
      NUD: dto.NUD,
      items_count: dto.items.length,
    });

    // 7. Retornar respuesta
    return {
      folio,
      fecha_alta: new Date().toISOString().split('T')[0],
      fecha_cambio_estimado: this.calcularFechaCambioEstimado(new Date())
        .toISOString()
        .split('T')[0],
    };
  }

  // ======================
  // UPDATE TICKET
  // ======================
  async updateTicket(
    folio: string,
    dto: UpdateTicketDTO,
    apiKeyData: ApiKeyData,
  ): Promise<UpdatedTicketDTO> {
    // 1. Buscar ticket
    const ticket = await this.ticketRepository.findOne({
      where: { folio },
    });

    if (!ticket) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.TICKET_NOT_FOUND,
        `Ticket ${folio} no encontrado`,
      );
    }

    // 2. Validar estado editable
    this.validateEditableState(ticket);

    // 3. Validar acceso del servicio
    this.validateTicketAccess(apiKeyData, ticket);

    // 4. Obtener catálogo y validar items
    const catalog = await this.catalogService.getCatalog(
      { ID_Bodega: ticket.ID_Bodega, NUD: ticket.NUD },
      apiKeyData,
    );

    const validationErrors = await this.validateItemsAgainstCatalog(
      dto.items,
      catalog,
    );
    if (validationErrors.length > 0) {
      throw ApiErrorFactory.unprocessable(validationErrors);
    }

    // 5. Actualizar en transacción
    await this.dataSource.transaction(async (manager) => {
      // 5.1 Eliminar items existentes
      await manager.delete(TicketItem, { folio });

      // 5.2 Crear nuevos items
      const items = dto.items.map((item) =>
        manager.create(TicketItem, {
          folio,
          clave_producto: item.clave_producto,
          id_motivo: item.id_motivo,
          piezas: item.piezas,
          justificacion: item.justificacion,
        }),
      );

      await manager.save(items);

      // 5.3 Actualizar timestamp del ticket
      await manager.update(Ticket, { folio }, { updated_at: new Date() });
    });

    this.logger.log({
      action: 'UPDATE_TICKET_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio,
    });

    return {
      folio,
      updated: true,
      items_count: dto.items.length,
    };
  }

  // ======================
  // SUBMIT TICKET (SEND)
  // ======================
  async submitTicket(
    folio: string,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<SentTicketDTO> {
    this.logger.log({
      action: 'SUBMIT_TICKET_START',
      apiKeyName: apiKeyData.name,
      folio,
      idempotencyKey,
    });

    // 1. Buscar ticket
    const ticket = await this.ticketRepository.findOne({
      where: { folio },
      relations: ['items', 'items.producto', 'items.motivo'],
    });

    if (!ticket) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.TICKET_NOT_FOUND,
        `No se encontró el ticket ${folio}`,
      );
    }

    // 2. Validar acceso
    this.validateTicketAccess(apiKeyData, ticket);

    // 3. Validar estado (debe ser DRAFT o READY)
    if (
      ticket.estado !== TicketEstado.DRAFT &&
      ticket.estado !== TicketEstado.READY
    ) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.STATE_NOT_SUBMITTABLE,
        `El ticket no puede enviarse en estado ${ticket.estado}`,
      );
    }

    // 4. Revalidar items contra catálogo actual (validación final)
    const catalog = await this.catalogService.getCatalog(
      { ID_Bodega: ticket.ID_Bodega, NUD: ticket.NUD },
      apiKeyData,
    );

    const validationErrors = await this.validateItemsAgainstCatalog(
      ticket.items.map((item) => ({
        clave_producto: item.clave_producto,
        id_motivo: item.id_motivo,
        piezas: item.piezas,
        justificacion: item.justificacion,
      })),
      catalog,
    );

    if (validationErrors.length > 0) {
      throw ApiErrorFactory.unprocessable(validationErrors);
    }

    // 5. Actualizar estado a SENT
    ticket.estado = TicketEstado.SENT;
    ticket.sent_at = new Date();
    ticket.sent_by = 1; // API Key based - not user specific

    // Calcular fecha estimada de cambio (ejemplo: 7 días)
    const fechaCambioEstimado = new Date();
    fechaCambioEstimado.setDate(fechaCambioEstimado.getDate() + 7);
    ticket.fecha_cambio_estimado = fechaCambioEstimado;

    await this.ticketRepository.save(ticket);

    // TODO: Aquí se debe integrar con GEPP o sistema externo
    // Implementar reintentos con backoff exponencial (3 intentos: 300ms, 900ms, 2700ms)
    // await this.sendToExternalSystem(ticket);

    this.logger.log({
      action: 'SUBMIT_TICKET_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio,
      status: ticket.estado,
    });

    return {
      folio: ticket.folio,
      status: ticket.estado,
      fecha_cambio_estimado: ticket.fecha_cambio_estimado,
      sent_at: ticket.sent_at,
    };
  }

  // ======================
  // CANCEL TICKET
  // ======================
  async cancelTicket(
    folio: string,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<CancelledTicketDTO> {
    this.logger.log({
      action: 'CANCEL_TICKET_START',
      apiKeyName: apiKeyData.name,
      folio,
      idempotencyKey,
    });

    // 1. Buscar ticket
    const ticket = await this.ticketRepository.findOne({
      where: { folio },
    });

    if (!ticket) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.TICKET_NOT_FOUND,
        `No se encontró el ticket ${folio}`,
      );
    }

    // 2. Validar acceso
    this.validateTicketAccess(apiKeyData, ticket);

    // 3. Validar estado cancelable (no se puede cancelar si ya está CANCELLED o COMPLETED)
    if (
      ticket.estado === TicketEstado.CANCELLED ||
      ticket.estado === TicketEstado.COMPLETED
    ) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.STATE_NOT_CANCELLABLE,
        `El ticket no puede cancelarse en estado ${ticket.estado}`,
        { current_status: ticket.estado },
      );
    }

    // 4. Cancelar ticket
    ticket.estado = TicketEstado.CANCELLED;
    ticket.cancelled_at = new Date();
    ticket.cancelled_by = 1; // API Key based
    ticket.cancellation_reason = 'Cancelado por API';

    await this.ticketRepository.save(ticket);

    this.logger.log({
      action: 'CANCEL_TICKET_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio,
    });

    return {
      folio: ticket.folio,
      status: ticket.estado,
      cancelled_at: ticket.cancelled_at,
    };
  }

  // ======================
  // GET TICKET BY FOLIO
  // ======================
  async getTicketByFolio(
    folio: string,
    apiKeyData: ApiKeyData,
  ): Promise<TicketByFolioDTO> {
    this.logger.log({
      action: 'GET_TICKET_BY_FOLIO',
      apiKeyName: apiKeyData.name,
      folio,
    });

    // 1. Buscar ticket con sus items
    const ticket = await this.ticketRepository.findOne({
      where: { folio },
      relations: ['items', 'items.producto', 'items.motivo'],
    });

    if (!ticket) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.TICKET_NOT_FOUND,
        `No se encontró el ticket ${folio}`,
      );
    }

    // 2. Validar acceso
    this.validateTicketAccess(apiKeyData, ticket);

    // 3. Formatear respuesta
    return {
      folio: ticket.folio,
      status: ticket.estado,
      ID_Bodega: ticket.ID_Bodega,
      NUD: ticket.NUD,
      fecha_alta: ticket.created_at,
      fecha_cambio_estimado: ticket.fecha_cambio_estimado,
      sent_at: ticket.sent_at,
      cancelled_at: ticket.cancelled_at,
      cancellation_reason: ticket.cancellation_reason,
      productos: ticket.items.map((item) => ({
        clave_producto: item.clave_producto,
        descripcion: item.producto?.descripcion,
        id_motivo: item.id_motivo,
        motivo_descripcion: item.motivo?.descripcion,
        piezas: item.piezas,
        justificacion: item.justificacion,
      })),
    };
  }

  // ======================
  // PRIVATE HELPER METHODS
  // ======================

  private async findActiveTicket(
    ID_Bodega: number,
    NUD: string,
  ): Promise<Ticket | null> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    return await this.ticketRepository
      .createQueryBuilder('ticket')
      .leftJoinAndSelect('ticket.items', 'items')
      .leftJoinAndSelect('items.producto', 'producto')
      .leftJoinAndSelect('items.motivo', 'motivo')
      .where('ticket.ID_Bodega = :ID_Bodega', { ID_Bodega })
      .andWhere('ticket.NUD = :NUD', { NUD })
      .andWhere('ticket.estado IN (:...estados)', {
        estados: [TicketEstado.DRAFT, TicketEstado.READY, TicketEstado.SENT],
      })
      .andWhere('ticket.created_at > :thirtyDaysAgo', { thirtyDaysAgo })
      .orderBy('ticket.created_at', 'DESC')
      .getOne();
  }

  private async validateNoActiveTicket(
    ID_Bodega: number,
    NUD: string,
  ): Promise<void> {
    const existing = await this.findActiveTicket(ID_Bodega, NUD);

    if (existing) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.ACTIVE_TICKET_EXISTS,
        `Ya existe un ticket activo (${existing.folio}) para esta bodega/NUD.`,
      );
    }
  }

  private validateNoDuplicateItems(items: CreateTicketItemDTO[]): void {
    const combinations = new Set<string>();
    const duplicates: string[] = [];

    items.forEach((item) => {
      const key = `${item.clave_producto}-${item.id_motivo}`;
      if (combinations.has(key)) {
        duplicates.push(key);
      }
      combinations.add(key);
    });

    if (duplicates.length > 0) {
      throw ApiErrorFactory.unprocessable(
        ErrorCodes.DUPLICATE_ITEM,
        `Items duplicados: ${duplicates.join(', ')}`,
      );
    }
  }

  private async validateItemsAgainstCatalog(
    items: CreateTicketItemDTO[],
    catalog: CatalogDataDTO,
  ): Promise<ApiErrorDetails[]> {
    const errors: ApiErrorDetails[] = [];

    for (const item of items) {
      const producto = catalog.productos.find(
        (p) => p.clave_producto === item.clave_producto,
      );

      if (!producto) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.PRODUCT_NOT_ELIGIBLE,
            `Producto ${item.clave_producto} no elegible para cambios`,
            'clave_producto',
          ),
        );
        continue;
      }

      if (item.piezas < producto.minimo_permitido) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.OUT_OF_RANGE,
            `Mínimo ${producto.minimo_permitido} piezas`,
            'piezas',
          ),
        );
      }

      if (item.piezas > producto.maximo_permitido) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.OUT_OF_RANGE,
            `Máximo ${producto.maximo_permitido} piezas`,
            'piezas',
          ),
        );
      }

      if (item.piezas > producto.maximo_para_alerta) {
        if (!item.justificacion || item.justificacion.length < 5) {
          errors.push(
            new ApiErrorDetails(
              ErrorCodes.JUSTIFICATION_REQUIRED,
              `Justificación obligatoria (5-100 caracteres) cuando piezas supera el umbral`,
              'justificacion',
            ),
          );
        }
      }

      const motivoExists = catalog.motivos.some((grupo) =>
        grupo.items.some((m) => m.id_motivo === item.id_motivo),
      );

      if (!motivoExists) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.MOTIVO_NOT_ELIGIBLE,
            `Motivo ${item.id_motivo} no elegible para esta bodega`,
            'id_motivo',
          ),
        );
      }
    }

    return errors;
  }

  private async generateUniqueFolio(): Promise<string> {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let folio: string;
    let attempts = 0;
    const maxAttempts = 100;

    do {
      const letter = letters[Math.floor(Math.random() * letters.length)];
      const number = Math.floor(Math.random() * 100000)
        .toString()
        .padStart(5, '0');
      folio = `${letter}${number}`;

      const exists = await this.ticketRepository.findOne({ where: { folio } });
      if (!exists) {
        return folio;
      }

      attempts++;
    } while (attempts < maxAttempts);

    throw ApiErrorFactory.internalServerError(
      ErrorCodes.INTERNAL_SERVER_ERROR,
      'No se pudo generar un folio único después de múltiples intentos',
    );
  }

  private calcularFechaCambioEstimado(fechaAlta: Date): Date {
    // Simplificado: agregar 5 días hábiles
    const fecha = new Date(fechaAlta);
    let diasAgregados = 0;

    while (diasAgregados < 5) {
      fecha.setDate(fecha.getDate() + 1);
      const diaSemana = fecha.getDay();
      // Saltar sábado (6) y domingo (0)
      if (diaSemana !== 0 && diaSemana !== 6) {
        diasAgregados++;
      }
    }

    return fecha;
  }

  private async validateServiceAccess(
    apiKeyData: ApiKeyData,
    ID_Bodega: number,
    NUD: string,
  ): Promise<void> {
    // Verificar permisos
    const hasWritePermission = apiKeyData.permissions.includes(
      'cambio_mercado:write',
    );

    if (!hasWritePermission) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.INSUFFICIENT_PERMISSIONS,
        'El API Key no tiene permisos de escritura',
      );
    }

    // Validar operación si está asignada
    const operation = await this.operationRepository.findOne({
      where: { idDeposito: ID_Bodega },
    });

    if (!operation) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.WAREHOUSE_NOT_FOUND,
        `No se encontró operación para la bodega ${ID_Bodega}`,
      );
    }

    if (
      apiKeyData.idoperacion &&
      apiKeyData.idoperacion !== operation.idoperacion
    ) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.OPERATION_ACCESS_DENIED,
        'El API Key no tiene acceso a esta operación',
      );
    }
  }

  private validateTicketAccess(apiKeyData: ApiKeyData, ticket: Ticket): void {
    // API Keys con permisos de escritura pueden acceder a todos los tickets
    const hasWritePermission = apiKeyData.permissions.includes(
      'cambio_mercado:write',
    );

    if (!hasWritePermission) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.TICKET_ACCESS_DENIED,
        'El API Key no tiene permisos para acceder a este ticket',
      );
    }
  }

  private validateEditableState(ticket: Ticket): void {
    const EDITABLE_STATES = [TicketEstado.DRAFT, TicketEstado.READY];

    if (!EDITABLE_STATES.includes(ticket.estado)) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.STATE_NOT_EDITABLE,
        `El ticket en estado ${ticket.estado} no admite edición`,
      );
    }
  }
}
