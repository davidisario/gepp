import { CambiosMotivo } from '../motivos/entities/cambios-motivo.entity';
import { CapturaCambio } from './entities/captura-cambio.entity';
import { CapturaCambioController } from './controllers/captura-cambio.controller';
import { CapturaCambioService } from './services/captura-cambio.service';
import { Deposito } from '../operations/entities/deposito.entity';
import { FechaEntregaService } from './services/fecha-entrega.service';
import { Module } from '@nestjs/common';
import { Operation } from '../operations/entities/operation.entity';
import { Product } from '../products/entities/product.entity';
import { ProductoCambios } from '../products/entities/producto-cambios.entity';
import { RutaCambios } from '../rutas/entities/ruta-cambios.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../users/entities/user.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CapturaCambio,
      RutaCambios,
      Product,
      ProductoCambios,
      CambiosMotivo,
      Operation,
      Deposito,
      User,
    ]),
  ],
  controllers: [CapturaCambioController],
  providers: [CapturaCambioService, FechaEntregaService],
  exports: [CapturaCambioService, FechaEntregaService],
})
export class CapturaCambioModule {}
