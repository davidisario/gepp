import {
  Controller,
  Post,
  Get,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Headers,
  UseGuards,
  HttpCode,
  HttpStatus,
  ParseIntPipe,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiQuery,
  ApiHeader,
  ApiSecurity,
} from '@nestjs/swagger';

import { CapturaCambioService } from '../services/captura-cambio.service';
import { CreateCambioDTO } from '../dto/create-cambio.dto';
import { UpdateCambioDTO } from '../dto/update-cambio.dto';
import { CambioGroupResponseDTO } from '../dto/cambio-response.dto';
import { ApiKeyGuard } from '../../../common/guards/api-key.guard';
import { CurrentApiKey } from '../../../common/decorators/api-key-data.decorator';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiResponse as ApiResponseType } from '../../../common/responses/api-response';
import { ApiResponseFactory } from 'src/common/factories/api-response-factory';
import { ErrorCodes } from 'src/common/enums/errorCodes';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { CheckAccessDTO } from 'src/modules/cambio-mercado/dto/check-access.dto';
import {
  CatalogProductosDTO,
  CatalogMotivosDTO,
} from 'src/modules/catalogos/dto/catalog.dto';
import { CancelGroupDTO, SubmittedGroupDTO } from '../dto/group.dto';
import { capturaCambioDocs as docs } from 'src/common/docs';

@ApiTags('Captura de Cambios')
@Controller('captura_cambios')
@UseGuards(ApiKeyGuard)
@ApiSecurity('api-key')
export class CapturaCambioController {
  constructor(private readonly capturaCambioService: CapturaCambioService) {}

  // ==============================================
  // FLUJO 1: ELEGIBILIDAD DE ACCESO
  // ==============================================

  @Get('access')
  @ApiOperation(docs.access.operation)
  @ApiHeader(docs.access.header['x-api-key'])
  @ApiQuery(docs.access.queries.idBodega)
  @ApiQuery(docs.access.queries.pppcaptura)
  @ApiQuery(docs.access.queries.nud)
  @ApiResponse(docs.access.responses.ok)
  @ApiResponse(docs.access.responses.unauthorized)
  @ApiResponse(docs.access.responses.forbidden)
  async getAccess(
    @Query('idBodega', ParseIntPipe) idBodega: number,
    @Query('pppcaptura', ParseIntPipe) pppcaptura: number,
    @Query('nud', ParseIntPipe) nud: number,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CheckAccessDTO>> {
    const accessData = await this.capturaCambioService.getAccess(
      idBodega,
      pppcaptura,
      apiKeyData,
      nud,
    );

    if (!accessData.access) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.NOT_ELIGIBLE,
        'El usuario no es elegible para el módulo en esta operación/ruta/nud.',
        { access: false },
      );
    }

    return ApiResponseFactory.ok<CheckAccessDTO>(
      accessData,
      'Acceso habilitado al módulo.',
    );
  }

  // ==============================================
  // FLUJO 2: CATÁLOGO DE PRODUCTOS Y MOTIVOS
  // ==============================================

  @Get('catalog/productos')
  @ApiOperation(docs.catalog.productos.operation)
  @ApiHeader(docs.catalog.productos.header['x-api-key'])
  @ApiQuery(docs.catalog.productos.queries.idBodega)
  @ApiQuery(docs.catalog.productos.queries.pppcaptura)
  @ApiResponse(docs.catalog.productos.responses.ok)
  @ApiResponse(docs.catalog.productos.responses.unauthorized)
  @ApiResponse(docs.catalog.productos.responses.notFound)
  async getCatalogProductos(
    @Query('idBodega', ParseIntPipe) idBodega: number,
    @Query('pppcaptura', ParseIntPipe) pppcaptura: number,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CatalogProductosDTO>> {
    const catalogData = await this.capturaCambioService.getCatalogProductos(
      idBodega,
      pppcaptura,
      apiKeyData,
    );

    if (catalogData.productos.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.NOT_FOUND,
        'No se halló catálogo de productos para la operación/ruta.',
      );
    }

    return ApiResponseFactory.ok<CatalogProductosDTO>(
      catalogData,
      'Catálogo de productos recuperado correctamente.',
    );
  }

  @Get('catalog/motivos')
  @ApiOperation(docs.catalog.motivos.operation)
  @ApiHeader(docs.catalog.motivos.header['x-api-key'])
  @ApiQuery(docs.catalog.motivos.queries.idBodega)
  @ApiQuery(docs.catalog.motivos.queries.pppcaptura)
  @ApiQuery(docs.catalog.motivos.queries.sku)
  @ApiResponse(docs.catalog.motivos.responses.ok)
  @ApiResponse(docs.catalog.motivos.responses.unauthorized)
  @ApiResponse(docs.catalog.motivos.responses.notFound)
  async getCatalogMotivos(
    @Query('idBodega', ParseIntPipe) idBodega: number,
    @Query('pppcaptura', ParseIntPipe) pppcaptura: number,
    @Query('sku', ParseIntPipe) sku: number,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CatalogMotivosDTO>> {
    const catalogData = await this.capturaCambioService.getCatalogMotivos(
      idBodega,
      pppcaptura,
      sku,
      apiKeyData,
    );

    if (catalogData.motivos.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.NOT_FOUND,
        'No se halló catálogo de motivos para la operación/ruta.',
      );
    }

    return ApiResponseFactory.ok<CatalogMotivosDTO>(
      catalogData,
      'Catálogo de motivos recuperado correctamente.',
    );
  }

  // ==============================================
  // FLUJO 3: CREAR GRUPO DE CAMBIOS
  // ==============================================

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation(docs.create.operation)
  @ApiHeader(docs.create.header['x-api-key'])
  @ApiHeader(docs.create.header['x-idempotency-key'])
  @ApiResponse(docs.create.responses.created)
  @ApiResponse(docs.create.responses.unauthorized)
  @ApiResponse(docs.create.responses.notFound)
  @ApiResponse(docs.create.responses.conflict)
  @ApiResponse(docs.create.responses.unprocessableEntity)
  async createCambios(
    @Body() dto: CreateCambioDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<CambioGroupResponseDTO>> {
    const grupo = await this.capturaCambioService.createCambios(
      dto,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<CambioGroupResponseDTO>(
      grupo,
      'Grupo de cambios creado correctamente.',
    );
  }

  // ==============================================
  // FLUJO 4: CONSULTAR GRUPO ACTIVO
  // ==============================================

  @Get('active')
  @ApiOperation(docs.active.operation)
  @ApiHeader(docs.active.header['x-api-key'])
  @ApiQuery(docs.active.queries.pppcaptura)
  @ApiQuery(docs.active.queries.fecha)
  @ApiQuery(docs.active.queries.idoperacion)
  @ApiQuery(docs.active.queries.nud)
  @ApiResponse(docs.active.responses.ok)
  @ApiResponse(docs.active.responses.noContent)
  @ApiResponse(docs.active.responses.unauthorized)
  async getActiveGroup(
    @Query('pppcaptura', ParseIntPipe) pppcaptura: number,
    @Query('fecha') fecha: string | undefined,
    @Query('idoperacion', ParseIntPipe) idoperacion: number,
    @Query('nud', ParseIntPipe) nud: number,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CambioGroupResponseDTO | {}> | void> {
    const grupo = await this.capturaCambioService.getActiveGroup(
      pppcaptura,
      idoperacion,
      apiKeyData,
      nud,
    );

    if (!grupo) {
      return ApiResponseFactory.ok({}, 'Queried successfully');
    }

    return ApiResponseFactory.ok<CambioGroupResponseDTO>(
      grupo,
      nud
        ? `Grupo activo encontrado con items del cliente ${nud}.`
        : 'Grupo activo encontrado.',
    );
  }

  // ==============================================
  // FLUJO 5: OBTENER GRUPO POR FOLIO
  // ==============================================

  //@Get(':folio') -- se oculta endpoint
  // @ApiOperation(docs.getFolio.operation)
  // @ApiHeader(docs.getFolio.header['x-api-key'])
  // @ApiParam(docs.getFolio.params.folio)
  // @ApiResponse(docs.getFolio.responses.ok)
  // @ApiResponse(docs.getFolio.responses.unauthorized)
  // @ApiResponse(docs.getFolio.responses.notFound)
  async getGroupByFolio(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CambioGroupResponseDTO>> {
    this.validateFolioFormat(folio);

    const grupo = await this.capturaCambioService.getGroupByFolio(
      folio,
      apiKeyData,
    );

    return ApiResponseFactory.ok<CambioGroupResponseDTO>(
      grupo,
      'Grupo recuperado correctamente.',
    );
  }

  // ==============================================
  // FLUJO 5.5: ACTUALIZAR GRUPO
  // ==============================================

  @Put(':folio')
  @ApiOperation(docs.putFolio.operation)
  @ApiParam(docs.putFolio.params.folio)
  @ApiHeader(docs.putFolio.header['x-api-key'])
  @ApiHeader(docs.putFolio.header['x-idempotency-key'])
  @ApiResponse(docs.putFolio.responses.ok)
  @ApiResponse(docs.putFolio.responses.unauthorized)
  @ApiResponse(docs.putFolio.responses.forbidden)
  @ApiResponse(docs.putFolio.responses.notFound)
  @ApiResponse(docs.putFolio.responses.conflict)
  @ApiResponse(docs.putFolio.responses.unprocessableEntity)
  async updateGroup(
    @Param('folio') folio: string,
    @Body() dto: UpdateCambioDTO,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<CambioGroupResponseDTO>> {
    this.validateFolioFormat(folio);

    const grupo = await this.capturaCambioService.updateGroup(
      folio,
      dto,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<CambioGroupResponseDTO>(
      grupo,
      'Grupo actualizado correctamente.',
    );
  }

  // ==============================================
  // FLUJO 7: DECLINAR GRUPO (CANCEL)
  // ==============================================

  @Delete(':folio')
  @ApiOperation(docs.deleteFolio.operation)
  @ApiParam(docs.deleteFolio.params.folio)
  @ApiHeader(docs.deleteFolio.header['x-api-key'])
  @ApiHeader(docs.deleteFolio.header['x-idempotency-key'])
  @ApiResponse(docs.deleteFolio.responses.ok)
  @ApiResponse(docs.deleteFolio.responses.unauthorized)
  @ApiResponse(docs.deleteFolio.responses.notFound)
  @ApiResponse(docs.deleteFolio.responses.conflict)
  async cancelGroup(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<CancelGroupDTO>> {
    this.validateFolioFormat(folio);

    const result = await this.capturaCambioService.cancelGroup(
      folio,
      apiKeyData,
    );

    return ApiResponseFactory.ok<CancelGroupDTO>(
      result,
      'Grupo eliminado correctamente.',
    );
  }

  // ==============================================
  // FLUJO 7: AUTORIZAR GRUPO (SUBMIT)
  // ==============================================

  //Post(':folio/submit') -- se oculta endpoint
  // @ApiOperation(docs.submitFolio.operation)
  // @ApiParam(docs.submitFolio.params.folio)
  // @ApiHeader(docs.submitFolio.header['x-api-key'])
  // @ApiHeader(docs.submitFolio.header['x-idempotency-key'])
  // @ApiResponse(docs.submitFolio.responses.ok)
  // @ApiResponse(docs.submitFolio.responses.unauthorized)
  // @ApiResponse(docs.submitFolio.responses.notFound)
  // @ApiResponse(docs.submitFolio.responses.conflict)
  async submitGroup(
    @Param('folio') folio: string,
    @CurrentApiKey() apiKeyData: ApiKeyData,
    @Headers('x-idempotency-key') idempotencyKey?: string,
  ): Promise<ApiResponseType<SubmittedGroupDTO>> {
    this.validateFolioFormat(folio);

    const result = await this.capturaCambioService.submitGroup(
      folio,
      apiKeyData,
      idempotencyKey,
    );

    return ApiResponseFactory.ok<SubmittedGroupDTO>(
      result,
      'Grupo autorizado correctamente.',
    );
  }

  // ==============================================
  // HELPERS
  // ==============================================

  private validateFolioFormat(folio: string): void {
    const match = folio.match(/^(\d+)-(\d+)-(\d+)-(\d{4}-\d{2}-\d{2})$/);
    if (!match) {
      throw ApiErrorFactory.badRequest(
        ErrorCodes.BAD_REQUEST,
        'Folio inválido. Formato esperado: {pppcaptura}-{idBodega}-{nud}-YYYY-MM-DD',
      );
    }
  }
}
