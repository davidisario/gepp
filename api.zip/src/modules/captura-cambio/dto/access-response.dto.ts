import { ApiProperty } from '@nestjs/swagger';

export class AccessResponseDTO {
  @ApiProperty({
    description: 'Indica si el usuario tiene acceso al módulo',
    example: true,
  })
  access: boolean;

  @ApiProperty({
    description:
      'Indica si ya existe un grupo activo (pendiente) para esta combinación',
    example: false,
  })
  has_active_ticket: boolean;
}
