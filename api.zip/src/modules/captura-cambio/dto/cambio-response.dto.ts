import { ApiProperty } from '@nestjs/swagger';

export class CambioItemResponseDTO {
  @ApiProperty({
    description: 'ID único del cambio en BD',
    example: 123,
  })
  idcambios: number;

  @ApiProperty({
    description: 'NUD del cliente',
    example: 10001,
  })
  nud: number;

  @ApiProperty({
    description: 'Nombre del cliente',
    example: 'Tienda de Prueba',
    required: false,
  })
  nombre_cliente?: string;

  @ApiProperty({
    description: 'SKU del producto',
    example: 123456,
  })
  sku: number;

  @ApiProperty({
    description: 'Descripción del producto',
    example: 'Pepsi 600ml',
    required: false,
  })
  descripcion_producto?: string;

  @ApiProperty({
    description: 'Cantidad de piezas',
    example: 25,
  })
  cantidad: number;

  @ApiProperty({
    description: 'ID del motivo',
    example: 1,
  })
  id_motivo: number;

  @ApiProperty({
    description: 'Descripción del motivo',
    example: 'Producto Dañado',
    required: false,
  })
  descripcion_motivo?: string;

  @ApiProperty({
    description: 'Comentario/justificación',
    example: 'Llegó en mal estado',
    required: false,
  })
  comentario?: string;

  @ApiProperty({
    description: 'Fecha de entrega calculada',
    example: '2025-11-02',
    required: false,
  })
  fecha_entrega?: string;
}

export class CambioGroupResponseDTO {
  @ApiProperty({
    description: 'Folio virtual: {pppcaptura}-{idBodega}-{nud}-{fecha}',
    example: '123-1-10001-2025-10-30',
  })
  folio_virtual: string;

  @ApiProperty({
    description: 'Ruta del promotor (PPP)',
    example: 123,
  })
  pppcaptura: number;

  @ApiProperty({
    description: 'Fecha de cambio/preventa',
    example: '2025-10-30',
  })
  FechaCambio: string;

  @ApiProperty({
    description: 'ID de operación',
    example: 1,
  })
  idoperacion: number;

  @ApiProperty({
    description: 'Total de clientes únicos en el grupo',
    example: 3,
  })
  clientes_total: number;

  @ApiProperty({
    description: 'Total de piezas en el grupo',
    example: 150,
  })
  piezas_total: number;

  @ApiProperty({
    description: 'Total de items en el grupo',
    example: 8,
  })
  items_total: number;

  @ApiProperty({
    description:
      'Estado de autorización (0=Pendiente, 1=Autorizado, 2=Declinado)',
    example: 0,
  })
  statusAutorizado: number;

  @ApiProperty({
    description: 'Fecha de creación del grupo',
    example: '2025-10-30T14:30:00Z',
  })
  fecha_creacion: Date;

  @ApiProperty({
    description: 'Fecha de autorización',
    example: '2025-10-31T09:15:00Z',
    required: false,
  })
  fecha_autorizacion?: Date;

  @ApiProperty({
    description: 'Items del grupo',
    type: [CambioItemResponseDTO],
  })
  items: CambioItemResponseDTO[];
}
