import { ApiProperty } from '@nestjs/swagger';

export class ProductoCatalogoDTO {
  @ApiProperty({
    description: 'SKU del producto',
    example: 123456,
  })
  clave_producto: number;

  @ApiProperty({
    description: 'Descripción del producto',
    example: 'Pepsi 600ml',
  })
  descripcion: string;

  @ApiProperty({
    description: 'Mínimo de piezas permitido',
    example: 1,
  })
  minimo_permitido: number;

  @ApiProperty({
    description: 'Máximo de piezas permitido',
    example: 999,
  })
  maximo_permitido: number;

  @ApiProperty({
    description: 'Umbral para requerir justificación',
    example: 30,
  })
  maximo_para_alerta: number;

  @ApiProperty({
    description: 'Unidad de medida',
    example: 'Pza',
    required: false,
  })
  unidad?: string;
}

export class MotivoCatalogoDTO {
  @ApiProperty({
    description: 'ID del motivo',
    example: 1,
  })
  id_motivo: number;

  @ApiProperty({
    description: 'Descripción del motivo',
    example: 'Producto Dañado',
  })
  descripcion: string;

  @ApiProperty({
    description: 'Agrupador del motivo',
    example: 'CALIDAD',
    required: false,
  })
  agrupador?: string;

  @ApiProperty({
    description:
      'Lista de SKUs permitidos para el motivo (null = aplica a todos los productos)',
    example: [123456, 789012],
    required: false,
    type: [Number],
    nullable: true,
  })
  skus_permitidos?: number[] | null;
}

export class CatalogResponseDTO {
  @ApiProperty({
    description: 'Lista de productos elegibles para cambio',
    type: [ProductoCatalogoDTO],
  })
  productos: ProductoCatalogoDTO[];

  @ApiProperty({
    description: 'Lista de motivos disponibles',
    type: [MotivoCatalogoDTO],
  })
  motivos: MotivoCatalogoDTO[];
}
