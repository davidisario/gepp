import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Length,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';

import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CambioItemDTO {
  @ApiProperty({
    description: 'SKU del producto',
    example: 123456,
  })
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  clave_producto: number;

  @ApiProperty({
    description: 'ID del motivo de cambio',
    example: 1,
  })
  @IsInt()
  @IsNotEmpty()
  id_motivo: number;

  @ApiProperty({
    description: 'Cantidad de piezas',
    example: 25,
    minimum: 1,
    maximum: 999,
  })
  @IsInt()
  @Min(1)
  @Max(999)
  piezas: number;

  @ApiProperty({
    description: 'Justificación del cambio (requerida si piezas > umbral)',
    example: 'Producto llegó dañado en transporte',
    required: false,
  })
  @IsString()
  @IsOptional()
  @Length(5, 255)
  justificacion?: string;
}

export class CreateCambioDTO {
  @ApiProperty({
    description: 'NUD del cliente (aplica a todos los items)',
    example: 10001,
  })
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  NUD: number;

  @ApiProperty({
    description: 'ID de bodega/operación',
    example: 1,
  })
  @IsInt()
  @IsNotEmpty()
  ID_Bodega: number;

  @ApiProperty({
    description: 'PPP Captura - Ruta del promotor',
    example: 123,
  })
  @IsInt()
  @IsNotEmpty()
  pppcaptura: number;

  @ApiProperty({
    description: 'Items del cambio',
    type: [CambioItemDTO],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CambioItemDTO)
  items: CambioItemDTO[];
}
