class GroupDTO {
  folio_virtual: string;
}

export class CancelGroupDTO extends GroupDTO {
  fecha_cancelacion: Date;
  registros_actualizados: number;
}

export class SubmittedGroupDTO extends GroupDTO {
  fecha_autorizacion: Date;
  registros_actualizados: number;
  status: string;
}
