import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

import { CambiosMotivo } from '../../motivos/entities/cambios-motivo.entity';
import { Operation } from '../../operations/entities/operation.entity';
import { Product } from '../../products/entities/product.entity';
import { User } from '../../users/entities/user.entity';

@Entity({ name: 'capturacambios' })
export class CapturaCambio {
  @PrimaryGeneratedColumn({ name: 'idcambios' })
  idcambios: number;

  @Column({ name: 'idoperacion', type: 'int' })
  idoperacion: number;

  @Column({ name: 'NumEmpleado', type: 'int' })
  numCapturo: number;

  @Column({ name: 'idCambiosMotivos', type: 'int' })
  idcambiosmotivos: number;

  @Column({ name: 'idProductoCambio', type: 'int' })
  idProductoCambio: number;

  @Column({ name: 'nud', type: 'int' })
  nud: number;

  @Column({ name: 'FechaCambio', type: 'date' })
  FechaCambio: Date;

  @Column({ name: 'cantidad', type: 'int' })
  cantidad: number;

  @Column({ name: 'idruta', type: 'int', nullable: true })
  idruta: number | null;

  @Column({ name: 'estatusDis', type: 'int', default: 0 })
  estatusDis: number;

  @Column({ name: 'fechaEntrega', type: 'date', nullable: true })
  fechaEntrega: Date | null;

  @Column({
    name: 'horaCaptura',
    type: 'datetime2',
    precision: 0,
    nullable: true,
  })
  horaCaptura: Date | null;

  @Column({
    name: 'horadinamico',
    type: 'datetime2',
    precision: 0,
    nullable: true,
  })
  horadinamico: Date | null;

  @Column({ name: 'pppcaptura', type: 'int', nullable: true })
  pppcaptura: number | null;

  @Column({ name: 'pzasconfirmar', type: 'int', nullable: true })
  pzasconfirmar: number | null;

  @Column({ name: 'pedidopromsio', type: 'int', nullable: true })
  pedidopromsio: number | null;

  @Column({ name: 'motivoentrega', type: 'int', nullable: true })
  motivoentrega: number | null;

  @Column({ name: 'pzaentregadas', type: 'int', nullable: true })
  pzaentregadas: number | null;

  @Column({
    name: 'horaCarga',
    type: 'datetime2',
    precision: 0,
    nullable: true,
  })
  horaCarga: Date | null;

  @Column({ name: 'idBodega', type: 'int' })
  idBodega: number;

  @Column({ name: 'sku', type: 'int' })
  sku: number;

  @Column({ name: 'skuConver', type: 'int' })
  skuConver: number;

  @Column({ name: 'numSupervisor', type: 'int', default: 0 })
  numSupervisor: number;

  @Column({ name: 'numGrupoSupervision', type: 'int', default: 0 })
  numGrupoSupervision: number;

  @Column({ name: 'numAutorizador', type: 'int', default: 0 })
  numAutorizador: number;

  @Column({ name: 'tiempoAutorizado', type: 'datetime', nullable: true })
  tiempoAutorizado: Date | null;

  @Column({ name: 'statusAutorizado', type: 'int', default: 0 })
  statusAutorizado: number;

  @Column({ name: 'comentario', type: 'nvarchar', length: 400, nullable: true })
  comentario: string | null;

  @Column({ name: 'tiempoEntrega', type: 'datetime', nullable: true })
  tiempoEntrega: Date | null;

  @Column({ name: 'AutorizadoEnDetalle', type: 'bit', nullable: true })
  AutorizadoEnDetalle: number | null;

  @Column({
    name: 'ComentarioVPP',
    type: 'varchar',
    length: 200,
    nullable: true,
  })
  ComentarioVPP: string | null;

  @Column({
    name: 'EvidenciaFotografica',
    type: 'varchar',
    length: 400,
    nullable: true,
  })
  EvidenciaFotografica: string | null;

  @Column({ name: 'NoEmpleadoVPP', type: 'int', nullable: true })
  NoEmpleadoVPP: number | null;

  @Column({
    name: 'HorarioServidorDescargaHHC',
    type: 'datetime',
    nullable: true,
  })
  HorarioServidorDescargaHHC: Date | null;

  @Column({
    name: 'HorarioServidorVerificacion',
    type: 'datetime',
    nullable: true,
  })
  HorarioServidorVerificacion: Date | null;

  @Column({ name: 'skuPadre', type: 'int', nullable: true })
  skuPadre: number | null;

  @Column({ name: 'EnviadoAPI', type: 'bit', nullable: true })
  EnviadoAPI: number | null;

  @ManyToOne(() => Product, { nullable: true })
  @JoinColumn({ name: 'sku', referencedColumnName: 'sku' })
  producto: Product | null;

  @ManyToOne(() => CambiosMotivo, { nullable: true })
  @JoinColumn({ name: 'idCambiosMotivos' })
  motivo: CambiosMotivo | null;

  @ManyToOne(() => Operation, { nullable: true })
  @JoinColumn({ name: 'idoperacion' })
  operacion: Operation | null;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn([
    { name: 'NumEmpleado', referencedColumnName: 'NumEmpleado' },
    { name: 'idoperacion', referencedColumnName: 'idoperacion' },
  ])
  usuarioCapturo: User | null;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn([
    { name: 'numAutorizador', referencedColumnName: 'NumEmpleado' },
    { name: 'idoperacion', referencedColumnName: 'idoperacion' },
  ])
  usuarioAutorizador: User | null;
}
