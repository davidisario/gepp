import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In, DataSource, EntityManager } from 'typeorm';

import { CapturaCambio } from '../entities/captura-cambio.entity';
import { RutaCambios } from '../../rutas/entities/ruta-cambios.entity';
import { ProductoCambios } from '../../products/entities/producto-cambios.entity';
import { CambiosMotivo } from '../../motivos/entities/cambios-motivo.entity';
import { Operation } from '../../operations/entities/operation.entity';

import { CreateCambioDTO, CambioItemDTO } from '../dto/create-cambio.dto';
import { UpdateCambioDTO } from '../dto/update-cambio.dto';
import { CambioGroupResponseDTO } from '../dto/cambio-response.dto';
import { FechaEntregaService } from './fecha-entrega.service';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { ErrorCodes } from 'src/common/enums/errorCodes';
import { ApiErrorDetails } from 'src/common/responses/api-error-details';
import { CheckAccessDTO } from 'src/modules/cambio-mercado/dto/check-access.dto';
import {
  CatalogProductosDTO,
  CatalogMotivosDTO,
} from 'src/modules/catalogos/dto/catalog.dto';
import { CancelGroupDTO, SubmittedGroupDTO } from '../dto/group.dto';

@Injectable()
export class CapturaCambioService {
  private readonly logger = new Logger(CapturaCambioService.name);

  constructor(
    @InjectRepository(CapturaCambio)
    private capturaCambioRepo: Repository<CapturaCambio>,
    @InjectRepository(RutaCambios)
    private rutaCambiosRepo: Repository<RutaCambios>,
    @InjectRepository(ProductoCambios)
    private productoCambiosRepo: Repository<ProductoCambios>,
    @InjectRepository(CambiosMotivo)
    private cambiosMotivosRepo: Repository<CambiosMotivo>,
    @InjectRepository(Operation)
    private operacionRepo: Repository<Operation>,
    private fechaEntregaService: FechaEntregaService,
    private dataSource: DataSource,
  ) {}

  // ==============================================
  // ELEGIBILIDAD DE ACCESO
  // ==============================================

  async getAccess(
    idBodega: number,
    pppcaptura: number,
    apiKeyData: ApiKeyData,
    nud: number,
  ): Promise<CheckAccessDTO> {
    this.logger.log({
      action: 'GET_ACCESS',
      idBodega,
      pppcaptura,
      nud,
      apiKeyName: apiKeyData.name,
    });

    // 1. Verificar que la operación (por depósito) existe
    let operacion: Operation;
    try {
      operacion = await this.resolveOperacionByDeposito(idBodega);
    } catch {
      return {
        access: false,
        has_active_ticket: false,
      };
    }

    try {
      await this.validateNudExists(nud);
    } catch {
      return {
        access: false,
        has_active_ticket: false,
      };
    }

    // 2. Verificar que la ruta existe y está activa
    const ruta = await this.rutaCambiosRepo.findOne({
      where: {
        ruta: pppcaptura,
        idoperacion: operacion.idoperacion,
        estatus: 1,
      },
    });

    if (!ruta) {
      return {
        access: false,
        has_active_ticket: false,
      };
    }

    // 3. Verificar si hay un grupo activo (pendiente)
    const grupoActivo = await this.findActiveGroup(
      pppcaptura,
      operacion.idoperacion,
      nud,
      undefined,
    );

    return {
      access: true,
      has_active_ticket: grupoActivo.length > 0,
    };
  }

  // ==============================================
  // CATÁLOGO DE PRODUCTOS Y MOTIVOS
  // ==============================================

  async getCatalogProductos(
    idBodega: number,
    pppcaptura: number,
    apiKeyData: ApiKeyData,
  ): Promise<CatalogProductosDTO> {
    this.logger.log({
      action: 'GET_CATALOG_PRODUCTOS',
      idBodega,
      pppcaptura,
      apiKeyName: apiKeyData.name,
    });

    // Validar que la operación exista para conocer su depósito (CEDIS)
    const operacion = await this.resolveOperacionByDeposito(idBodega);

    // Resolver el tipo de mercado de la ruta para filtrar el catálogo
    const ruta = await this.rutaCambiosRepo.findOne({
      where: {
        ruta: pppcaptura,
        idoperacion: operacion.idoperacion,
        estatus: 1,
      },
    });

    if (!ruta) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.ROUTE_NOT_FOUND,
        `Ruta ${pppcaptura} no encontrada`,
      );
    }

    const whereProductos: any = {
      idoperacion: operacion.idoperacion,
      estatus: 1,
    };

    // Si la ruta tiene tipo de mercado definido, usarlo para filtrar productos
    if (ruta.tmercado !== null && ruta.tmercado !== undefined) {
      whereProductos.tmercado = ruta.tmercado;
    }

    // 1. Obtener productos elegibles para esta operación
    let productos = await this.productoCambiosRepo.find({
      where: whereProductos,
      relations: ['producto'],
      order: {
        sku: 'ASC',
      },
    });

    // 2. Formatear respuesta
    const productosFormatted = productos.map((pc) => ({
      clave_producto: pc.sku,
      descripcion: pc.producto?.descripcion || 'Producto sin descripción',
      minimo_permitido: 1,
      maximo_permitido: 999,
      maximo_para_alerta: 30,
      unidad: pc.producto?.presentacion || 'Pza',
    }));

    return {
      productos: productosFormatted,
    };
  }

  async getCatalogMotivos(
    idBodega: number,
    pppcaptura: number,
    sku: number,
    apiKeyData: ApiKeyData,
  ): Promise<CatalogMotivosDTO> {
    this.logger.log({
      action: 'GET_CATALOG_MOTIVOS',
      idBodega,
      sku,
      apiKeyName: apiKeyData.name,
    });

    // Validar que la operación exista para conocer su depósito (CEDIS)
    const operacion = await this.resolveOperacionByDeposito(idBodega);

    // Resolver el tipo de mercado de la ruta para filtrar el catálogo
    const ruta = await this.rutaCambiosRepo.findOne({
      where: {
        ruta: pppcaptura,
        idoperacion: operacion.idoperacion,
        estatus: 1,
      },
    });

    if (!ruta) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.ROUTE_NOT_FOUND,
        `Ruta ${pppcaptura} no encontrada`,
      );
    }

    const whereProductos: any = {
      idoperacion: operacion.idoperacion,
      estatus: 1,
      sku: this.normalizeSkuValue(sku),
    };

    // Si la ruta tiene tipo de mercado definido, usarlo para filtrar productos
    if (ruta.tmercado !== null && ruta.tmercado !== undefined) {
      whereProductos.tmercado = ruta.tmercado;
    }

    // 1. Validar la existencia del producto con el sku ingresado
    let productos = await this.productoCambiosRepo.find({
      where: whereProductos,
      relations: ['producto'],
      order: {
        sku: 'ASC',
      },
    });

    if (productos.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.PRODUCT_NOT_IN_CATALOG,
        `Producto ${sku} no encontrado en el catálogo con los valores ingresados`,
      );
    }

    // 1. Obtener motivos activos
    const motivos = await this.cambiosMotivosRepo.find({
      order: {
        idcambiosmotivos: 'ASC',
      },
    });

    // 2.1 Filtrar motivos por restcedis (CEDIS permitidos)
    let motivosFiltrados = motivos.filter((m) => {
      const restCedisValue = m.restcedis?.trim();
      const hasRestCedis =
        restCedisValue && restCedisValue.toLowerCase() !== 'null';

      if (!hasRestCedis) {
        return true;
      }

      const cedisPermitidos = restCedisValue
        .split(',')
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      return (
        cedisPermitidos.length === 0 ||
        cedisPermitidos.includes(operacion.idDeposito.toString())
      );
    });

    // 2.2 Filtrar motivos por sku ingresado
    motivosFiltrados = motivosFiltrados.filter((m) => {
      const restSkuValue = m.restsku?.trim();
      const hasRestSku = restSkuValue && restSkuValue.toLowerCase() !== 'null';

      if (!hasRestSku) {
        return true;
      }

      const skuPermitidos = restSkuValue
        .split(',')
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      return (
        skuPermitidos.length === 0 || skuPermitidos.includes(sku.toString())
      );
    });

    // 3. Formatear respuesta
    const motivosFormatted = motivosFiltrados.map((m) => ({
      id_motivo: m.idcambiosmotivos,
      descripcion: m.descripcion,
      agrupador: m.agrupador || 'GENERAL',
      justificacion_preconfigurada: m.restSkuComentarios
        .split(',')
        .map((code) => code.trim())
        .includes(sku.toString()),
    }));

    return {
      motivos: motivosFormatted,
    };
  }

  // ==============================================
  // VALIDACIÓN DE RESTRICCIONES DE MOTIVOS (restsku, restcedis)
  // ==============================================

  /**
   * Valida que un SKU sea elegible para un motivo específico según restricciones legacy.
   * Verifica restsku (SKUs permitidos) y restcedis (CEDIs permitidos).
   * @param sku SKU del producto
   * @param idMotivo ID del motivo
   * @param idoperacion ID de operación (para validar restcedis)
   * @throws UnprocessableEntityException si el SKU o CEDIS no es elegible
   */
  async validateMotivoRestrictions(
    sku: number,
    idMotivo: number,
    idoperacion: number,
    justificacion?: string,
  ): Promise<void> {
    const normalizedSku = this.normalizeSkuValue(sku);

    this.logger.debug({
      action: 'VALIDATE_MOTIVO_RESTRICTIONS',
      sku: normalizedSku,
      idMotivo,
      idoperacion,
    });

    // Obtener el motivo con sus restricciones
    const motivo = await this.cambiosMotivosRepo.findOne({
      where: { idcambiosmotivos: idMotivo },
    });

    if (!motivo) {
      throw ApiErrorFactory.unprocessable(
        ErrorCodes.MOTIVO_NOT_FOUND,
        `Motivo ${idMotivo} no encontrado o inactivo`,
      );
    }

    // 1. Validar restsku (SKUs restringidos)
    const restSkuValue = motivo.restsku?.trim();
    const hasRestSku = restSkuValue && restSkuValue.toLowerCase() !== 'null';

    if (hasRestSku) {
      const skusPermitidos = restSkuValue
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s.length > 0)
        .map((s) => this.normalizeSkuValue(s));

      if (
        skusPermitidos.length > 0 &&
        !skusPermitidos.includes(normalizedSku)
      ) {
        throw ApiErrorFactory.unprocessable(
          ErrorCodes.SKU_NOT_ELIGIBLE_FOR_MOTIVO,
          `El SKU ${normalizedSku} no es elegible para el motivo "${motivo.descripcion}". Solo se permiten: ${skusPermitidos.join(', ')}`,
        );
      }
    }

    // 2. Validar restcedis (CEDIs restringidos)
    const restCedisValue = motivo.restcedis?.trim();
    const hasRestCedis =
      restCedisValue && restCedisValue.toLowerCase() !== 'null';

    if (hasRestCedis) {
      // Obtener el idDeposito de la operación
      const operacion = await this.operacionRepo.findOne({
        where: { idoperacion },
      });

      if (!operacion) {
        throw ApiErrorFactory.notFound(
          ErrorCodes.OPERATION_NOT_FOUND,
          'Operación no encontrada',
        );
      }

      const cedisPermitidos = restCedisValue
        .split(',')
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      if (
        cedisPermitidos.length > 0 &&
        !cedisPermitidos.includes(operacion.idDeposito.toString())
      ) {
        throw ApiErrorFactory.unprocessable(
          ErrorCodes.CEDIS_NOT_ELIGIBLE_FOR_MOTIVO,
          `El CEDIS/Depósito ${operacion.idDeposito} no es elegible para el motivo "${motivo.descripcion}"`,
        );
      }
    }

    const restSkuComentarios = motivo.restSkuComentarios?.trim();
    const hasRestSkuComentarios =
      restSkuComentarios && restSkuComentarios.toLowerCase() !== 'null';

    if (hasRestSkuComentarios) {
      const skusRequierenJustificacion = restSkuComentarios
        .split(',')
        .map((s) => s.trim());

      if (
        skusRequierenJustificacion.includes(normalizedSku.toString()) &&
        (!justificacion || justificacion.trim().length === 0)
      ) {
        throw ApiErrorFactory.unprocessable(
          ErrorCodes.JUSTIFICATION_REQUIRED,
          `El SKU ${normalizedSku} requiere una justificación`,
        );
      }
    }

    this.logger.debug({
      action: 'VALIDATE_MOTIVO_RESTRICTIONS_PASSED',
      sku: normalizedSku,
      idMotivo,
    });
  }

  // ==============================================
  // CREAR GRUPO DE CAMBIOS
  // ==============================================

  async createCambios(
    dto: CreateCambioDTO,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<CambioGroupResponseDTO> {
    this.logger.log({
      action: 'CREATE_CAMBIOS_START',
      apiKeyName: apiKeyData.name,
      pppcaptura: dto.pppcaptura,
      items: dto.items.length,
      nud: dto.NUD,
    });

    if (dto.NUD === undefined || dto.NUD === null) {
      throw ApiErrorFactory.unprocessable(
        ErrorCodes.BAD_REQUEST,
        'El NUD es requerido y debe ser numérico',
      );
    }

    const operacion = await this.resolveOperacionByDeposito(dto.ID_Bodega);

    // 1. Validar que NO exista ticket activo para este pppcaptura + idBodega + nud
    await this.validateNoActiveGroup(
      dto.pppcaptura,
      operacion.idoperacion,
      operacion.idDeposito,
      dto.NUD,
      undefined,
    );

    const fechaCambio = new Date();
    fechaCambio.setHours(0, 0, 0, 0);
    const fechaEntregaData =
      await this.fechaEntregaService.calcularFechaEntregaPorFrecuenciaVisita(
        fechaCambio,
        dto.NUD,
        operacion.idDeposito,
        operacion.idoperacion,
      );

    // 3. Validar ruta existe
    const ruta = await this.rutaCambiosRepo.findOne({
      where: { ruta: dto.pppcaptura, idoperacion: operacion.idoperacion },
    });

    if (!ruta) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.ROUTE_NOT_FOUND,
        'Ruta no encontrada',
      );
    }

    await this.validateNudExists(dto.NUD);

    // 4. Validar catálogo y obtener límites
    const catalogoProductos = await this.validateCatalog(
      dto.items,
      operacion.idoperacion,
    );

    // 5. Validar items (rangos, duplicados, etc.)
    const validationErrors = this.validateItems(dto.items, catalogoProductos);
    if (validationErrors.length > 0) {
      throw ApiErrorFactory.unprocessable(validationErrors);
    }

    // 5.5 Validar restricciones de motivos (restsku, restcedis)
    for (const item of dto.items) {
      await this.validateMotivoRestrictions(
        item.clave_producto,
        item.id_motivo,
        operacion.idoperacion,
        item.justificacion,
      );
    }

    // 6. Crear registros en transacción
    const cambiosCreados = await this.dataSource.transaction(
      async (manager) => {
        const cambios: CapturaCambio[] = [];

        for (const item of dto.items) {
          cambios.push(
            await this.saveCapturaCambio({
              manager,
              operacion,
              ruta,
              fechaCambio,
              pppcaptura: dto.pppcaptura,
              nud: dto.NUD,
              item,
              comentarioGeneral: null,
              apiKeyData,
              catalogoProductos,
              fechaEntregaPrecalculada: fechaEntregaData,
            }),
          );
        }

        return cambios;
      },
    );

    this.logger.log({
      action: 'CREATE_CAMBIOS_SUCCESS',
      apiKeyName: apiKeyData.name,
      pppcaptura: dto.pppcaptura,
      registros: cambiosCreados.length,
    });

    // 7. Retornar agrupación
    return this.buildGroupResponse(
      dto.pppcaptura,
      fechaCambio,
      operacion.idoperacion,
      operacion.idDeposito,
      dto.NUD,
    );
  }

  // ==============================================
  // VALIDACIONES
  // ==============================================

  private async resolveOperacionByDeposito(
    idDeposito: number,
  ): Promise<Operation> {
    const operacion = await this.operacionRepo.findOne({
      where: { idDeposito },
    });

    if (!operacion) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.OPERATION_NOT_FOUND,
        `Operación no encontrada para depósito ${idDeposito}`,
      );
    }

    return operacion;
  }

  private async validateNudExists(nud: number): Promise<void> {
    const existsQuery = `
      SELECT TOP 1 1
      FROM dbo.Cliente c
      WHERE c.CLAVE_CLIENTE = @0
    `;

    const clienteExiste = await this.operacionRepo.query(existsQuery, [nud]);

    if (!clienteExiste || clienteExiste.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.NOT_FOUND,
        `Cliente con NUD ${nud} no encontrado`,
      );
    }
  }

  private async validateNoActiveGroup(
    pppcaptura: number,
    idoperacion: number,
    idBodega: number,
    nud: number,
    FechaCambio?: Date,
  ): Promise<void> {
    const existing = await this.findActiveGroup(
      pppcaptura,
      idoperacion,
      idBodega,
      nud,
      FechaCambio,
    );

    if (existing.length > 0) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.ACTIVE_GROUP_EXISTS,
        `Ya existe un grupo activo para pppcaptura ${pppcaptura}, idBodega ${idBodega}, NUD ${nud} en fecha ${existing[0].FechaCambio}`,
        {
          folio_virtual: this.buildFolioVirtual(
            pppcaptura,
            idBodega,
            nud,
            existing[0].FechaCambio,
          ),
          nud,
        },
      );
    }
  }

  private async validateCatalog(
    items: CambioItemDTO[],
    idoperacion: number,
  ): Promise<ProductoCambios[]> {
    const skuValues = items.map((i) =>
      this.normalizeSkuValue(i.clave_producto),
    );

    const productos = await this.productoCambiosRepo.find({
      where: {
        sku: In(skuValues),
        idoperacion,
        estatus: 1,
      },
      relations: ['producto'],
    });

    // Validar que todos los SKUs existan
    const skusEncontrados = productos.map((p) => p.sku);
    const skusFaltantes = skuValues.filter((s) => !skusEncontrados.includes(s));

    if (skusFaltantes.length > 0) {
      throw ApiErrorFactory.unprocessable(
        ErrorCodes.PRODUCT_NOT_IN_CATALOG,
        `Productos no habilitados: ${skusFaltantes.join(', ')}`,
      );
    }

    return productos;
  }

  private validateItems(
    items: CambioItemDTO[],
    catalogoProductos: ProductoCambios[],
  ): ApiErrorDetails[] {
    const errors: ApiErrorDetails[] = [];
    const seen = new Set<string>();

    for (const item of items) {
      // Validar duplicados
      const key = `${item.clave_producto}-${item.id_motivo}`;
      if (seen.has(key)) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.DUPLICATE_ITEM,
            `Producto ${item.clave_producto} con motivo ${item.id_motivo} duplicado`,
          ),
        );
      }
      seen.add(key);

      // Validar rangos (usando defaults ya que no están en productoscambios)
      const minimo = 1;
      const maximo = 999;
      const umbral = 30;

      if (item.piezas < minimo || item.piezas > maximo) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.OUT_OF_RANGE,
            `Producto ${item.clave_producto}: piezas deben estar entre ${minimo} y ${maximo}`,
          ),
        );
      }

      // Validar justificación si supera umbral
      if (item.piezas > umbral && !item.justificacion) {
        errors.push(
          new ApiErrorDetails(
            ErrorCodes.JUSTIFICATION_REQUIRED,
            `Producto ${item.clave_producto}: justificación requerida (piezas > ${umbral})`,
          ),
        );
      }
    }

    // Validar límite de items (parametrizable)
    const limiteItems = 50; // Ajustado - el legacy no tiene límite pero ponemos uno razonable
    if (items.length > limiteItems) {
      errors.push(
        new ApiErrorDetails(
          ErrorCodes.LIMIT_EXCEEDED,
          `Máximo ${limiteItems} items por ticket`,
        ),
      );
    }

    return errors;
  }

  private async saveCapturaCambio(params: {
    manager: EntityManager;
    operacion: Operation;
    ruta: RutaCambios;
    fechaCambio: Date;
    pppcaptura: number;
    nud: number;
    item: {
      clave_producto: number;
      id_motivo: number;
      piezas: number;
      justificacion?: string;
    };
    comentarioGeneral: string | null;
    apiKeyData: ApiKeyData;
    catalogoProductos: ProductoCambios[];
    fechaEntregaPrecalculada?: { fechaEntrega: Date; idruta: number | null };
  }): Promise<CapturaCambio> {
    const {
      manager,
      operacion,
      ruta,
      fechaCambio,
      pppcaptura,
      nud,
      item,
      comentarioGeneral,
      apiKeyData,
      catalogoProductos,
      fechaEntregaPrecalculada,
    } = params;

    const fechaEntregaData =
      fechaEntregaPrecalculada ??
      (await this.fechaEntregaService.calcularFechaEntregaPorFrecuenciaVisita(
        fechaCambio,
        nud,
        operacion.idDeposito,
        operacion.idoperacion,
      ));

    const productoCambio = catalogoProductos.find(
      (p) => p.sku === item.clave_producto,
    );

    const cambio = manager.create(CapturaCambio, {
      idoperacion: operacion.idoperacion,
      numCapturo: apiKeyData.userId,
      idcambiosmotivos: item.id_motivo,
      idProductoCambio: productoCambio?.idProductoCambio,
      FechaCambio: fechaCambio,
      horaCaptura: new Date(),
      cantidad: item.piezas,
      nud,
      fechaEntrega: fechaEntregaData.fechaEntrega,
      pppcaptura,
      comentario: item.justificacion || comentarioGeneral || null,
      idBodega: operacion.idDeposito,
      sku: item.clave_producto,
      skuConver: productoCambio?.skuConver ?? item.clave_producto,
      statusAutorizado: 0,
      numAutorizador: 0,
      idruta: ruta.tipo === 1 ? (fechaEntregaData.idruta ?? null) : null,
      estatusDis: ruta.tipo === 1 ? 2 : 0,
      horadinamico: ruta.tipo === 1 ? new Date() : null,
      pedidopromsio: ruta.tipo === 1 ? 1 : null,
    });

    return manager.save(cambio);
  }

  private async findActiveGroup(
    pppcaptura: number,
    idoperacion: number,
    idBodega: number,
    nud: number,
    FechaCambio?: Date,
    withRelations = false,
  ): Promise<CapturaCambio[]> {
    const where: any = {
      pppcaptura,
      idoperacion,
      idBodega,
      statusAutorizado: 0,
      estatusDis: In([0, 2]),
    };

    if (FechaCambio) {
      where.FechaCambio = FechaCambio;
    }

    if (nud !== undefined && !Number.isNaN(nud)) {
      where.nud = nud;
    }

    return this.capturaCambioRepo.find({
      where,
      relations: withRelations ? ['producto', 'motivo'] : undefined,
      order: withRelations ? { idcambios: 'ASC' } : undefined,
    });
  }

  // ==============================================
  // CONSTRUCCIÓN DE RESPUESTA
  // ==============================================

  private buildFolioVirtual(
    pppcaptura: number,
    idBodega: number,
    nud: number,
    FechaCambio: Date | string,
  ): string {
    const fecha =
      typeof FechaCambio === 'string'
        ? FechaCambio
        : FechaCambio.toISOString().split('T')[0];
    return `${pppcaptura}-${idBodega}-${nud}-${fecha}`;
  }

  private async buildGroupResponse(
    pppcaptura: number,
    FechaCambio: Date,
    idoperacion: number,
    idBodega: number,
    nud?: number,
    statusAutorizado?: number,
  ): Promise<CambioGroupResponseDTO> {
    // Construir where dinámicamente
    const whereCondition: any = {
      pppcaptura,
      FechaCambio,
      idoperacion,
      idBodega,
    };

    // Si se proporciona NUD, agregar al filtro
    if (nud !== undefined) {
      whereCondition.nud = nud;
    }

    if (statusAutorizado || statusAutorizado === 0) {
      whereCondition.statusAutorizado = statusAutorizado; // Autorizado
    }

    const cambios = await this.capturaCambioRepo.find({
      where: whereCondition,
      relations: ['producto', 'motivo'],
      order: { idcambios: 'ASC' },
    });

    const clientesUnicos = new Set(cambios.map((c) => c.nud)).size;
    const piezasTotal = cambios.reduce((sum, c) => sum + c.cantidad, 0);

    const folioNud = nud ?? cambios[0]?.nud ?? 0;

    return {
      folio_virtual: this.buildFolioVirtual(
        pppcaptura,
        idBodega,
        folioNud,
        FechaCambio,
      ),
      pppcaptura,
      FechaCambio: FechaCambio.toISOString().split('T')[0],
      idoperacion,
      clientes_total: clientesUnicos,
      piezas_total: piezasTotal,
      items_total: cambios.length,
      statusAutorizado: cambios[0]?.statusAutorizado || 0,
      fecha_creacion: cambios[0]?.horaCaptura || new Date(),
      fecha_autorizacion: cambios[0]?.tiempoAutorizado,
      items: cambios.map((c) => ({
        idcambios: c.idcambios,
        nud: c.nud,
        sku: c.sku,
        descripcion_producto: c.producto?.descripcion,
        cantidad: c.cantidad,
        id_motivo: c.idcambiosmotivos,
        descripcion_motivo: c.motivo?.descripcion,
        comentario: c.comentario,
        fecha_entrega: c.fechaEntrega?.toString(),
      })),
    };
  }

  // ==============================================
  // CONSULTAR GRUPOS
  // ==============================================

  async getActiveGroup(
    pppcaptura: number,
    idBodega: number,
    apiKeyData: ApiKeyData,
    nud: number,
  ): Promise<CambioGroupResponseDTO | null> {
    const operacion = await this.resolveOperacionByDeposito(idBodega);
    const statusAutorizado = 0; // Pendiente

    const cambios = await this.findActiveGroup(
      pppcaptura,
      operacion.idoperacion,
      idBodega,
      nud,
      undefined,
      true,
    );

    if (cambios.length === 0) {
      return null; // 204 No Content
    }

    const fechaCambio = new Date(cambios[0].FechaCambio);
    fechaCambio.setHours(0, 0, 0, 0);

    return this.buildGroupResponse(
      pppcaptura,
      fechaCambio,
      operacion.idoperacion,
      idBodega,
      nud,
      statusAutorizado,
    );
  }

  async getGroupByFolio(
    folioVirtual: string,
    apiKeyData: ApiKeyData,
  ): Promise<CambioGroupResponseDTO> {
    // Extraer pppcaptura y fecha del folio virtual
    const { pppcaptura, idBodega, nud, FechaCambio } =
      this.getFolioItems(folioVirtual);
    FechaCambio.setHours(0, 0, 0, 0);

    const cambios = await this.capturaCambioRepo.find({
      where: { pppcaptura, FechaCambio },
      relations: ['producto', 'motivo'],
      order: { idcambios: 'ASC' },
    });

    if (cambios.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.GROUP_NOT_FOUND,
        `Grupo ${folioVirtual} no encontrado`,
      );
    }

    return this.buildGroupResponse(
      pppcaptura,
      FechaCambio,
      cambios[0].idoperacion,
      idBodega,
      nud,
    );
  }

  // ==============================================
  // ACTUALIZAR GRUPO
  // ==============================================

  async updateGroup(
    folioVirtual: string,
    dto: UpdateCambioDTO,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<CambioGroupResponseDTO> {
    this.logger.log({
      action: 'UPDATE_GROUP_START',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
      pppcaptura: dto.pppcaptura,
      nud: dto.NUD,
    });

    // 1. Extraer datos básicos del folio (validar ruta y NUD)
    const { pppcaptura, idBodega, nud } = this.getFolioItems(folioVirtual);

    if (dto.pppcaptura !== pppcaptura) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.FORBIDDEN,
        'El pppcaptura no coincide con el grupo original.',
      );
    }

    if (dto.ID_Bodega !== idBodega) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.FORBIDDEN,
        'El ID_Bodega no coincide con el grupo original.',
      );
    }

    if (dto.NUD !== nud) {
      throw ApiErrorFactory.forbidden(
        ErrorCodes.FORBIDDEN,
        'El NUD no coincide con el folio proporcionado.',
      );
    }

    // 2. Usar fecha actual como referencia (mismo comportamiento que POST)
    const FechaCambio = new Date();
    FechaCambio.setHours(0, 0, 0, 0);

    // 3. Validar operación (por depósito)
    const operacion = await this.resolveOperacionByDeposito(dto.ID_Bodega);

    // 4. Validar ruta
    const ruta = await this.rutaCambiosRepo.findOne({
      where: {
        ruta: dto.pppcaptura,
        idoperacion: operacion.idoperacion,
        estatus: 1,
      },
    });

    if (!ruta) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.ROUTE_NOT_FOUND,
        `Ruta ${dto.pppcaptura} no encontrada o inactiva`,
      );
    }

    await this.validateNudExists(dto.NUD);

    // 5. Validar catálogo y obtener límites
    const catalogoProductos = await this.validateCatalog(
      dto.items,
      operacion.idoperacion,
    );

    // 6. Validar items (rangos, duplicados, etc.)
    const validationErrors = this.validateItems(dto.items, catalogoProductos);
    if (validationErrors.length > 0) {
      throw ApiErrorFactory.unprocessable(validationErrors);
    }

    // 7. Validar restricciones de motivos (restsku, restcedis)
    for (const item of dto.items) {
      await this.validateMotivoRestrictions(
        item.clave_producto,
        item.id_motivo,
        operacion.idoperacion,
        item.justificacion,
      );
    }

    // 8. Eliminar registros previos por combinación ruta-fecha-bodega-NUD y recrear

    const cambiosExistentes = await this.capturaCambioRepo.find({
      where: {
        pppcaptura: dto.pppcaptura,
        FechaCambio,
        idoperacion: operacion.idoperacion,
        idBodega: operacion.idDeposito,
        nud: dto.NUD,
      },
    });

    const bloqueado = cambiosExistentes.find(
      (c) =>
        c.statusAutorizado !== 0 ||
        (ruta.tipo === 2 && c.estatusDis !== 0 && c.idruta !== null),
    );

    if (bloqueado) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.GROUP_ALREADY_AUTHORIZED,
        'El grupo no puede actualizarse porque ya fue autorizado o declinado o el despacho fue cerrado.',
      );
    }

    const cambiosActualizados = await this.dataSource.transaction(
      async (manager) => {
        // 8.1 Eliminar items antiguos por combinación ruta-fecha-bodega-NUD
        await manager.delete(CapturaCambio, {
          pppcaptura: dto.pppcaptura,
          FechaCambio,
          idoperacion: operacion.idoperacion,
          idBodega: operacion.idDeposito,
          nud: dto.NUD,
        });

        this.logger.log({
          action: 'DELETE_OLD_ITEMS',
          folio: folioVirtual,
          deletedCount: cambiosExistentes.length,
        });

        // 8.2 Crear nuevos items con lógica de POST
        const cambios: CapturaCambio[] = [];

        for (const item of dto.items) {
          cambios.push(
            await this.saveCapturaCambio({
              manager,
              operacion,
              ruta,
              fechaCambio: FechaCambio,
              pppcaptura: dto.pppcaptura,
              nud: dto.NUD,
              item,
              comentarioGeneral: dto.comentario,
              apiKeyData,
              catalogoProductos,
            }),
          );
        }

        return cambios;
      },
    );

    this.logger.log({
      action: 'UPDATE_GROUP_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
      newItemsCount: cambiosActualizados.length,
    });

    // 9. Retornar grupo actualizado
    return this.buildGroupResponse(
      dto.pppcaptura,
      FechaCambio,
      operacion.idoperacion,
      dto.NUD,
    );
  }

  // ==============================================
  // AUTORIZAR GRUPO (SUBMIT)
  // ==============================================

  async submitGroup(
    folioVirtual: string,
    apiKeyData: ApiKeyData,
    idempotencyKey?: string,
  ): Promise<SubmittedGroupDTO> {
    this.logger.log({
      action: 'SUBMIT_GROUP_START',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
    });

    // 1. Extraer datos del folio
    const [pppStr, fechaStr] = folioVirtual.split(/-(.+)/).slice(0, 2);
    const pppcaptura = parseInt(pppStr, 10);
    const FechaCambio = new Date(fechaStr);

    // 2. Buscar grupo
    const cambios = await this.capturaCambioRepo.find({
      where: { pppcaptura, FechaCambio },
    });

    if (cambios.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.GROUP_NOT_FOUND,
        `Grupo ${folioVirtual} no encontrado`,
      );
    }

    // 3. Validar estado (todos deben estar en statusAutorizado = 0)
    const noAutorizables = cambios.filter((c) => c.statusAutorizado !== 0);
    if (noAutorizables.length > 0) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.STATE_NOT_SUBMITTABLE,
        `El grupo no puede autorizarse en su estado actual`,
        { current_status: noAutorizables[0].statusAutorizado },
      );
    }

    // 4. Actualizar TODOS los registros del grupo
    await this.capturaCambioRepo.update(
      { pppcaptura, FechaCambio },
      {
        statusAutorizado: 1, // Autorizado
        numAutorizador: apiKeyData.idoperacion || 1,
        tiempoAutorizado: new Date(),
        AutorizadoEnDetalle: 0,
      },
    );

    this.logger.log({
      action: 'SUBMIT_GROUP_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
      registros: cambios.length,
    });

    return {
      folio_virtual: folioVirtual,
      status: 'AUTORIZADO',
      fecha_autorizacion: new Date(),
      registros_actualizados: cambios.length,
    };
  }

  // ==============================================
  // CANCELAR/DECLINAR GRUPO
  // ==============================================

  async cancelGroup(
    folioVirtual: string,
    apiKeyData: ApiKeyData,
  ): Promise<CancelGroupDTO> {
    this.logger.log({
      action: 'CANCEL_GROUP_START',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
    });

    const { pppcaptura, nud, FechaCambio, idBodega } =
      this.getFolioItems(folioVirtual);

    const cambios = await this.capturaCambioRepo.find({
      where: { pppcaptura, FechaCambio, nud, idBodega },
    });

    if (cambios.length === 0) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.GROUP_NOT_FOUND,
        `Grupo ${folioVirtual} no encontrado`,
      );
    }

    // Validar estado cancelable
    const noCancelables = cambios.filter(
      (c) => c.statusAutorizado !== 0 || c.estatusDis === 1,
    );
    if (noCancelables.length > 0) {
      throw ApiErrorFactory.conflict(
        ErrorCodes.STATE_NOT_CANCELLABLE,
        `El grupo no puede cancelarse en su estado actual`,
      );
    }

    const result = await this.capturaCambioRepo.delete({
      pppcaptura,
      FechaCambio,
      nud,
      idBodega,
      statusAutorizado: 0, // Pendiente
      estatusDis: In([0, 2]),
    });

    this.logger.log({
      action: 'CANCEL_GROUP_SUCCESS',
      apiKeyName: apiKeyData.name,
      folio: folioVirtual,
      deletedCount: result.affected,
    });

    return {
      folio_virtual: folioVirtual,
      fecha_cancelacion: new Date(),
      registros_actualizados: cambios.length,
    };
  }

  private normalizeSkuValue(value: string | number): number {
    const normalized = Number(value);

    if (Number.isNaN(normalized)) {
      throw ApiErrorFactory.unprocessable(
        ErrorCodes.PRODUCT_NOT_IN_CATALOG,
        `El SKU ${value} no es válido`,
      );
    }

    return normalized;
  }

  private getFolioItems(value: string): {
    pppcaptura: number;
    idBodega: number;
    nud: number;
    FechaCambio: Date;
  } {
    const [pppcaptura, idBodega, nud, year, month, day] = value.split('-');

    return {
      pppcaptura: Number(pppcaptura),
      idBodega: Number(idBodega),
      nud: Number(nud),
      FechaCambio: new Date(`${year}-${month}-${day}`),
    };
  }
}
