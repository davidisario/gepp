import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { RutaCambios } from '../../rutas/entities/ruta-cambios.entity';
import { Deposito } from '../../operations/entities/deposito.entity';
import { Operation } from '../../operations/entities/operation.entity';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { ErrorCodes } from 'src/common/enums/errorCodes';

@Injectable()
export class FechaEntregaService {
  private readonly logger = new Logger(FechaEntregaService.name);

  constructor(
    @InjectRepository(RutaCambios)
    private rutaCambiosRepo: Repository<RutaCambios>,
    @InjectRepository(Deposito)
    private depositoRepo: Repository<Deposito>,
    @InjectRepository(Operation)
    private operacionRepo: Repository<Operation>,
  ) {}

  async calcularFechaEntregaPorFrecuenciaVisita(
    fechaBase: Date,
    nud: number,
    idBodega: number,
    idoperacion: number,
  ): Promise<{ fechaEntrega: Date; idruta: number | null }> {
    const query = `
      SELECT c.FRECUENCIA_VISITA, c.CLAVE_RUTA_ENTREGA as vpp
      FROM Cliente c
      INNER JOIN Operaciones o ON c.CLAVE_BODEGA = o.idDeposito
      WHERE c.CLAVE_CLIENTE = @0
        AND c.CLAVE_BODEGA = @1
        AND o.idoperacion = @2
    `;

    const result = await this.operacionRepo.query(query, [
      nud,
      idBodega,
      idoperacion,
    ]);

    const frecuencia: string | null =
      result && result.length > 0 ? result[0].FRECUENCIA_VISITA : null;

    if (!frecuencia) {
      // TODO: Definir qué hacer cuando FRECUENCIA_VISITA es null
      return { fechaEntrega: new Date(fechaBase), idruta: result?.[0]?.vpp ?? null };
    }

    const diasMap: Record<string, number> = {
      L: 1,
      M: 2,
      W: 3,
      J: 4,
      V: 5,
      S: 6,
      D: 0,
    };

    const diasVisita = Array.from(new Set(frecuencia.trim().toUpperCase().split('')))
      .map((c) => diasMap[c])
      .filter((d) => d !== undefined);

    const fechaEntrega = new Date(fechaBase);
    let offset = 1;
    const maxDias = 14;

    while (offset <= maxDias) {
      fechaEntrega.setDate(fechaEntrega.getDate() + 1);
      if (diasVisita.includes(fechaEntrega.getDay())) {
        break;
      }
      offset++;
    }

    return {
      fechaEntrega,
      idruta: result?.[0]?.vpp ?? null,
    };
  }
  
  /**
   * Calcula la fecha de entrega según la lógica del legacy
   * Considera días hábiles del depósito
   */
  async calcularFechaEntrega(
    fechaPreventa: Date,
    pppcaptura: number,
    idoperacion: number,
  ): Promise<Date> {
    this.logger.debug({
      action: 'CALCULAR_FECHA_ENTREGA',
      fechaPreventa,
      pppcaptura,
      idoperacion,
    });

    // 1. Obtener días de entrega de la ruta
    const ruta = await this.rutaCambiosRepo.findOne({
      where: { ruta: pppcaptura, idoperacion },
    });

    if (!ruta) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.ROUTE_NOT_FOUND,
        'Ruta no encontrada',
      );
    }

    const dias = ruta.dias || 2; // Default 2 días

    // 2. Obtener días hábiles del depósito
    const operacion = await this.operacionRepo.findOne({
      where: { idoperacion },
      relations: ['deposito'],
    });

    if (!operacion || !operacion.deposito) {
      throw ApiErrorFactory.notFound(
        ErrorCodes.NOT_FOUND,
        'Operación o depósito no encontrado',
      );
    }

    const diasHabiles = {
      0: operacion.deposito.dom, // Domingo
      1: operacion.deposito.lun,
      2: operacion.deposito.mar,
      3: operacion.deposito.mie,
      4: operacion.deposito.jue,
      5: operacion.deposito.vie,
      6: operacion.deposito.sab,
    };

    // 3. Calcular fecha inicial
    const fechaEntrega = new Date(fechaPreventa);
    fechaEntrega.setDate(fechaEntrega.getDate() + dias);

    // 4. Ajustar si cae en día inhábil
    let intentos = 0;
    const maxIntentos = 14; // Evitar loop infinito

    while (diasHabiles[fechaEntrega.getDay()] === 0 && intentos < maxIntentos) {
      fechaEntrega.setDate(fechaEntrega.getDate() + 1);
      intentos++;
    }

    if (intentos >= maxIntentos) {
      throw ApiErrorFactory.internalServerError(
        ErrorCodes.INTERNAL_SERVER_ERROR,
        'No se pudo calcular fecha de entrega válida',
      );
    }

    this.logger.debug({
      action: 'FECHA_ENTREGA_CALCULADA',
      fechaPreventa,
      fechaEntrega,
      diasSumados: dias + intentos,
    });

    return fechaEntrega;
  }

  /**
   * Calcula la fecha de entrega considerando la ruta de entrega del cliente
   * (puede ser diferente a la ruta de captura)
   */
  async calcularFechaEntregaPorCliente(
    fechaPreventa: Date,
    nud: number,
    idBodega: number,
    pppcaptura: number,
    idoperacion: number,
  ): Promise<{ fechaEntrega: Date; idruta: number }> {
    this.logger.debug({
      action: 'CALCULAR_FECHA_ENTREGA_POR_CLIENTE',
      nud,
      idBodega,
      pppcaptura,
    });

    // Esta versión consulta la ruta de entrega del cliente
    // (puede ser diferente a pppcaptura)

    // 1. Consultar ruta de entrega del cliente
    const queryRuta = `
      SELECT 
        c.CLAVE_RUTA_ENTREGA as vpp,
        rc.dias,
        rc.tipo
      FROM Cliente c
      INNER JOIN Operaciones o ON c.CLAVE_BODEGA = o.idDeposito
      LEFT JOIN rutascambios rc ON rc.ruta = c.CLAVE_RUTA_ENTREGA AND rc.idoperacion = o.idoperacion
      WHERE c.CLAVE_CLIENTE = @0
        AND c.CLAVE_BODEGA = @1
        AND o.idoperacion = @2
    `;

    try {
      const result = await this.operacionRepo.query(queryRuta, [
        nud,
        idBodega,
        idoperacion,
      ]);

      if (!result || result.length === 0) {
        // Si no tiene ruta de entrega, usar pppcaptura
        this.logger.debug({
          action: 'RUTA_ENTREGA_NO_ENCONTRADA',
          nud,
          usingFallback: pppcaptura,
        });

        const fechaEntrega = await this.calcularFechaEntrega(
          fechaPreventa,
          pppcaptura,
          idoperacion,
        );
        return { fechaEntrega, idruta: pppcaptura };
      }

      const vpp = result[0].vpp;
      const dias = result[0].dias || 2;

      // 2. Calcular con días hábiles (igual que antes)
      const fechaEntrega = await this.calcularFechaEntrega(
        fechaPreventa,
        vpp,
        idoperacion,
      );

      return { fechaEntrega, idruta: vpp };
    } catch (error) {
      this.logger.error({
        action: 'ERROR_CALCULAR_FECHA_ENTREGA_CLIENTE',
        error: error.message,
        nud,
      });

      // Fallback a pppcaptura
      const fechaEntrega = await this.calcularFechaEntrega(
        fechaPreventa,
        pppcaptura,
        idoperacion,
      );
      return { fechaEntrega, idruta: pppcaptura };
    }
  }
}
