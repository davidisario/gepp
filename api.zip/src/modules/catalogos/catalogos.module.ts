import { CatalogosController } from './controllers/catalogos.controller';
import { CatalogosService } from './services/catalogos.service';
import { Deposito } from '../operations/entities/deposito.entity';
import { Module } from '@nestjs/common';
import { Operation } from '../operations/entities/operation.entity';
import { RutaCambios } from '../rutas/entities/ruta-cambios.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

// @Module({
//   imports: [TypeOrmModule.forFeature([Operation, RutaCambios, Deposito])],
//   controllers: [CatalogosController],
//   providers: [CatalogosService],
//   exports: [CatalogosService],
// })
// export class CatalogosModule {}
