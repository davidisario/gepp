import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiQuery,
  ApiSecurity,
} from '@nestjs/swagger';

import { CatalogosService } from '../services/catalogos.service';
import { ApiKeyGuard } from '../../../common/guards/api-key.guard';
import { CurrentApiKey } from '../../../common/decorators/api-key-data.decorator';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { ApiResponse as ApiResponseType } from '../../../common/responses/api-response';
import { ApiResponseFactory } from 'src/common/factories/api-response-factory';
import { ApiErrorFactory } from 'src/common/factories/api-error-factory';
import { ErrorCodes } from 'src/common/enums/errorCodes';
import { OperacionesResponse } from '../responses/operaciones.response';
import { RutasResponse } from '../responses/rutas.response';
import { catalogosDocs as docs } from 'src/common/docs';

@ApiTags('Catálogos')
@Controller('catalogos')
@UseGuards(ApiKeyGuard)
@ApiSecurity('api-key')
export class CatalogosController {
  constructor(private readonly catalogosService: CatalogosService) {}

  // ==============================================
  // CATÁLOGO DE OPERACIONES
  // ==============================================

  //@Get('operaciones')
  @ApiOperation(docs.operaciones.operation)
  @ApiQuery(docs.operaciones.queries.idZona)
  @ApiResponse(docs.operaciones.responses.ok)
  async getOperaciones(
    @Query('idZona') idZona: number | undefined,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<OperacionesResponse>> {
    const operaciones = await this.catalogosService.getOperaciones(
      idZona ? +idZona : undefined,
      apiKeyData,
    );

    return ApiResponseFactory.ok<OperacionesResponse>(
      { operaciones },
      'Operaciones recuperadas correctamente.',
    );
  }

  // ==============================================
  // CATÁLOGO DE RUTAS
  // ==============================================

  //@Get('rutas')
  @ApiOperation(docs.rutas.operation)
  @ApiQuery(docs.rutas.queries.idOperacion)
  @ApiQuery(docs.rutas.queries.tmercado)
  @ApiQuery(docs.rutas.queries.tipo)
  @ApiResponse(docs.rutas.responses.ok)
  @ApiResponse(docs.rutas.responses.badRequest)
  async getRutas(
    @Query('idoperacion') idoperacion: number | undefined,
    @Query('tmercado') tmercado: number | undefined,
    @Query('tipo') tipo: number | undefined,
    @CurrentApiKey() apiKeyData: ApiKeyData,
  ): Promise<ApiResponseType<RutasResponse>> {
    if (!idoperacion) {
      throw ApiErrorFactory.badRequest(
        ErrorCodes.BAD_REQUEST,
        'El parámetro idoperacion es requerido',
      );
    }

    const rutas = await this.catalogosService.getRutas(
      +idoperacion,
      tmercado ? +tmercado : undefined,
      tipo ? +tipo : undefined,
      apiKeyData,
    );

    return ApiResponseFactory.ok<RutasResponse>(
      { rutas },
      'Rutas recuperadas correctamente.',
    );
  }
}
