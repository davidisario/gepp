import { MotivoDTO } from 'src/modules/cambio-mercado/dto/catalog-response.dto';
import { ProductoCatalogoDTO } from 'src/modules/captura-cambio/dto/catalog-response.dto';

export class CatalogProductosDTO {
  productos: ProductoCatalogoDTO[];
}

export class CatalogMotivosDTO {
  motivos: MotivoDTO[];
}
