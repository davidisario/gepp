export class OperacionDTO {
  idoperacion: number;
  descripcion: string;
  idDeposito: number;
  deposito_nombre: string;
  tipoMercado: number;
  tipoMercado_nombre: string;
  estatus: number;
}
