export class RutaDTO {
  idruta: number;
  ruta: number;
  tipo: number;
  tipo_nombre: string;
  tmercado: number;
  tmercado_nombre: string;
  dias_entrega: number;
  estatus: number;
}
