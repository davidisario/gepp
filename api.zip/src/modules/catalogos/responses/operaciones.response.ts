import { OperacionDTO } from '../dto/operacion.dto';

export class OperacionesResponse {
  operaciones: OperacionDTO[];
}
