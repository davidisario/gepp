import { RutaDTO } from '../dto/ruta.dto';

export class RutasResponse {
  rutas: RutaDTO[];
}
