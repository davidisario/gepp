import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Operation } from '../../operations/entities/operation.entity';
import { RutaCambios } from '../../rutas/entities/ruta-cambios.entity';
import { ApiKeyData } from '../../../common/interfaces/api-key-data.interface';
import { OperacionDTO } from '../dto/operacion.dto';
import { RutaDTO } from '../dto/ruta.dto';

@Injectable()
export class CatalogosService {
  private readonly logger = new Logger(CatalogosService.name);

  constructor(
    @InjectRepository(Operation)
    private operacionRepo: Repository<Operation>,
    @InjectRepository(RutaCambios)
    private rutaCambiosRepo: Repository<RutaCambios>,
  ) {}

  // ==============================================
  // CATÁLOGO DE OPERACIONES
  // ==============================================

  async getOperaciones(
    idZona: number | undefined,
    apiKeyData: ApiKeyData,
  ): Promise<Array<OperacionDTO>> {
    this.logger.log({
      action: 'GET_OPERACIONES',
      idZona,
      apiKeyName: apiKeyData.name,
    });

    // Construir query con filtro opcional por zona
    const whereClause: any = {};

    if (idZona) {
      whereClause.deposito = { idZona };
    }

    const operaciones = await this.operacionRepo.find({
      where: whereClause,
      relations: ['deposito'],
      order: { descripcion: 'ASC' },
    });

    const operacionesFormatted: OperacionDTO[] = operaciones.map((op) => ({
      idoperacion: op.idoperacion,
      descripcion: op.descripcion,
      idDeposito: op.idDeposito,
      deposito_nombre: op.deposito?.deposito || 'Sin depósito',
      tipoMercado: op.tipoMercado,
      tipoMercado_nombre:
        op.tipoMercado === 0
          ? 'Tradicional'
          : op.tipoMercado === 1
            ? 'Moderno'
            : 'Otro',
      estatus: 1,
    }));

    this.logger.debug({
      action: 'GET_OPERACIONES_RESULT',
      total: operacionesFormatted.length,
    });

    return operacionesFormatted;
  }

  // ==============================================
  // CATÁLOGO DE RUTAS
  // ==============================================

  async getRutas(
    idoperacion: number,
    tmercado: number | undefined,
    tipo: number | undefined,
    apiKeyData: ApiKeyData,
  ): Promise<RutaDTO[]> {
    this.logger.log({
      action: 'GET_RUTAS',
      idoperacion,
      tmercado,
      tipo,
      apiKeyName: apiKeyData.name,
    });

    // Construir query con filtros opcionales
    const whereClause: any = {
      idoperacion,
      estatus: 1,
    };

    if (tmercado !== undefined) {
      whereClause.tmercado = tmercado;
    }

    if (tipo !== undefined) {
      whereClause.tipo = tipo;
    }

    const rutas = await this.rutaCambiosRepo.find({
      where: whereClause,
      order: { ruta: 'ASC' },
    });

    const rutasFormatted: RutaDTO[] = rutas.map((r) => ({
      idruta: r.idruta,
      ruta: r.ruta,
      tipo: r.tipo,
      tipo_nombre: r.tipo === 1 ? 'Fijo' : r.tipo === 2 ? 'Dinámico' : 'Otro',
      tmercado: r.tmercado,
      tmercado_nombre:
        r.tmercado === 0
          ? 'Tradicional'
          : r.tmercado === 1
            ? 'Moderno'
            : 'Otro',
      dias_entrega: r.dias || 0,
      estatus: r.estatus,
    }));

    this.logger.debug({
      action: 'GET_RUTAS_RESULT',
      total: rutasFormatted.length,
    });

    return rutasFormatted;
  }
}
