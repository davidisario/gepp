export class MotivoDTO {
  id_motivo: number;
  descripcion: string;
  agrupador: string;
}
