import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'cambiosmotivos' })
export class CambiosMotivo {
  @PrimaryGeneratedColumn({ name: 'idCambiosMotivos' })
  idcambiosmotivos: number;

  @Column({ name: 'Descripcion', type: 'varchar', length: 45, nullable: true })
  descripcion: string | null;

  @Column({ name: 'agrupador', type: 'varchar', length: 45, nullable: true })
  agrupador: string | null;

  @Column({
    name: 'arearesponsable',
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  areaResponsable: string | null;

  @Column({
    name: 'areaimpactar',
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  areaImpactar: string | null;

  @Column({
    name: 'restCedis',
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  restcedis: string | null;

  @Column({
    name: 'restSku',
    type: 'varchar',
    length: 500,
    nullable: true,
  })
  restsku: string | null;

  @Column({ name: 'Bloque', type: 'int', nullable: true })
  bloque: number | null;

  @Column({
    name: 'restSkuComentarios',
    type: 'varchar',
    length: 500,
    nullable: true,
  })
  restSkuComentarios: string | null;
}
