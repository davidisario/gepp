import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ name: 'deposito' })
export class Deposito {
  @PrimaryColumn({ name: 'idDeposito', type: 'int' })
  idDeposito: number;

  @Column({ name: 'idZona', type: 'int' })
  idZona: number;

  @Column({ name: 'deposito', type: 'varchar', length: 30 })
  deposito: string;

  @Column({ name: 'latitud', type: 'varchar', length: 15, nullable: true })
  latitud: string | null;

  @Column({ name: 'longitud', type: 'varchar', length: 15, nullable: true })
  longitud: string | null;

  @Column({
    name: 'gerenteDeposito',
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  gerenteDeposito: string | null;

  @Column({ name: 'jefeEntrega', type: 'varchar', length: 45, nullable: true })
  jefeEntrega: string | null;

  @Column({
    name: 'operadorSistema',
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  operadorSistema: string | null;

  @Column({ name: 'telefonoExt', type: 'varchar', length: 45, nullable: true })
  telefonoExt: string | null;

  @Column({ name: 'correoGD', type: 'varchar', length: 45, nullable: true })
  correoGD: string | null;

  @Column({ name: 'correoJE', type: 'varchar', length: 45, nullable: true })
  correoJE: string | null;

  @Column({ name: 'correoOP', type: 'varchar', length: 45, nullable: true })
  correoOP: string | null;

  @Column({ name: 'estatus', type: 'int', nullable: true })
  estatus: number | null;

  @Column({ name: 'total_vpp', type: 'int', nullable: true })
  totalVpp: number | null;

  @Column({ name: 'total_ppp', type: 'int', nullable: true })
  totalPpp: number | null;

  @Column({ name: 'total_av', type: 'int', nullable: true })
  totalAv: number | null;

  @Column({ name: 'diferenciaHoraria', type: 'int', nullable: true })
  diferenciaHoraria: number | null;

  @Column({
    name: 'zonaHoraria',
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  zonaHoraria: string | null;

  // Campos de días hábiles (bit en SQL)
  @Column({ name: 'dom', type: 'bit' })
  dom: number;

  @Column({ name: 'lun', type: 'bit' })
  lun: number;

  @Column({ name: 'mar', type: 'bit' })
  mar: number;

  @Column({ name: 'mie', type: 'bit' })
  mie: number;

  @Column({ name: 'jue', type: 'bit' })
  jue: number;

  @Column({ name: 'vie', type: 'bit' })
  vie: number;

  @Column({ name: 'sab', type: 'bit' })
  sab: number;

  @Column({ name: 'ClaveUOP', type: 'int', nullable: true })
  claveUop: number | null;

  @Column({ name: 'Arquetipo', type: 'nvarchar', length: 2, nullable: true })
  arquetipo: string | null;
}
