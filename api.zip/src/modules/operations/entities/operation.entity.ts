import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

import { Deposito } from './deposito.entity';

@Entity({ name: 'operaciones' })
export class Operation {
  @PrimaryGeneratedColumn({ name: 'idoperacion' })
  idoperacion: number;

  @Column({ name: 'idDeposito', type: 'int' })
  idDeposito: number;

  // Campo "mercado" del legacy - mantiene nombre lógico tipoMercado
  @Column({ name: 'mercado', type: 'int', default: 0 })
  tipoMercado: number;

  @Column({ name: 'coordinador_despacho', type: 'varchar', length: 150 })
  coordinadorDespacho: string;

  @Column({ name: 'nocelda', type: 'int', nullable: true })
  nocelda: number | null;

  @Column({ name: 'descripcion', type: 'varchar', length: 75, nullable: true })
  descripcion: string | null;

  @ManyToOne(() => Deposito, { nullable: false })
  @JoinColumn({ name: 'idDeposito' })
  deposito: Deposito;
}
