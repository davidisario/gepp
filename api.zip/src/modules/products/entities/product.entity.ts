import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ name: 'Producto' })
export class Product {
  @PrimaryColumn({ name: 'SKU', type: 'int' })
  sku: number;

  @Column({
    name: 'DESCRIPCION',
    type: 'nvarchar',
    length: 120,
    nullable: true,
  })
  descripcion: string | null;

  @Column({
    name: 'MARCA',
    type: 'nvarchar',
    length: 120,
    nullable: true,
  })
  marca: string | null;

  // Se mantiene el nombre lógico "categoria" pero proviene de la columna FAMILIA
  @Column({
    name: 'FAMILIA',
    type: 'nvarchar',
    length: 120,
    nullable: true,
  })
  categoria: string | null;

  @Column({
    name: 'EMPAQUE',
    type: 'nvarchar',
    length: 120,
    nullable: true,
  })
  presentacion: string | null;

  @Column({ name: 'BOT_X_CJA', type: 'int', nullable: true })
  unidadesPorCaja: number | null;
}
