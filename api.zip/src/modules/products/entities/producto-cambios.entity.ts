import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';

import { Operation } from '../../operations/entities/operation.entity';
import { Product } from './product.entity';

@Entity({ name: 'productoscambios' })
export class ProductoCambios {
  @PrimaryGeneratedColumn({ name: 'idProductoCambio' })
  idProductoCambio: number;

  @PrimaryColumn({ name: 'idoperacion', type: 'int' })
  idoperacion: number;

  @PrimaryColumn({ name: 'sku', type: 'int' })
  sku: number;

  @Column({
    name: 'DescripcionInterna',
    type: 'varchar',
    length: 125,
  })
  descripcionInterna: string;

  @Column({ name: 'skuConver', type: 'int', nullable: true })
  skuConver: number | null;

  @Column({ name: 'estatus', type: 'int', nullable: true })
  estatus: number | null;

  @Column({ name: 'tmercado', type: 'int' })
  tmercado: number;

  @ManyToOne(() => Product)
  @JoinColumn({ name: 'sku', referencedColumnName: 'sku' })
  producto: Product;

  @ManyToOne(() => Operation)
  @JoinColumn({ name: 'idoperacion' })
  operacion: Operation;
}
