import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

import { Operation } from '../../operations/entities/operation.entity';

@Entity({ name: 'rutascambios' })
export class RutaCambios {
  @PrimaryGeneratedColumn({ name: 'idrutasCambios' })
  idruta: number;

  @Column({ name: 'ruta', type: 'int', nullable: true })
  ruta: number | null;

  @Column({ name: 'idoperacion', type: 'int' })
  idoperacion: number;

  @Column({ name: 'idgruposupervision', type: 'int' })
  idgruposupervision: number;

  @Column({ name: 'tipo', type: 'int', nullable: true })
  tipo: number | null;

  @Column({ name: 'tMercado', type: 'int', nullable: true })
  tmercado: number | null;

  @Column({ name: 'dias', type: 'int', nullable: true })
  dias: number | null;

  @Column({ name: 'estatus', type: 'int', nullable: true })
  estatus: number | null;

  @Column({ name: 'impxcte', type: 'smallint', nullable: true })
  impxcte: number | null;

  @Column({ name: 'tipoPPP', type: 'int', default: 0 })
  tipoPPP: number;

  @Column({ name: 'virtual', type: 'int', nullable: true })
  virtual: number | null;

  @ManyToOne(() => Operation, { nullable: false })
  @JoinColumn({ name: 'idoperacion' })
  operacion: Operation;
}
