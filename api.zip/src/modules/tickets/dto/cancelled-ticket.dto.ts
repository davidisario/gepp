import { TicketEstado } from '../entities/ticket.entity';

export class CancelledTicketDTO {
  folio: string;
  status: TicketEstado;
  cancelled_at: Date;
}
