export class CreatedTicketDTO {
  folio: string;
  fecha_alta: string;
  fecha_cambio_estimado: string;
}
