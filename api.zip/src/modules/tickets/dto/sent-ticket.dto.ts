import { TicketEstado } from '../entities/ticket.entity';

export class SentTicketDTO {
  folio: string;
  status: TicketEstado;
  fecha_cambio_estimado: Date;
  sent_at: Date;
}
