import { TicketEstado } from '../entities/ticket.entity';

export class TicketByFolioDTO {
  folio: string;
  status: TicketEstado;
  ID_Bodega: number;
  NUD: string;
  fecha_alta: Date;
  fecha_cambio_estimado: Date;
  sent_at: Date;
  cancelled_at: Date;
  cancellation_reason: string;
  productos: ProductoDTO[];
}

class ProductoDTO {
  clave_producto: number;
  descripcion: string;
  id_motivo: number;
  motivo_descripcion: string;
  piezas: number;
  justificacion: string;
}
