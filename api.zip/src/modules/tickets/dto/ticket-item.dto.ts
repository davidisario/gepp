export class TicketItemDTO {
  clave_producto: number;
  descripcion_producto: string;
  id_motivo: number;
  descripcion_motivo: string;
  piezas: number;
  justificacion: string;
}
