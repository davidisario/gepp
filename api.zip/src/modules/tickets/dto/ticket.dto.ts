import { TicketEstado } from '../entities/ticket.entity';
import { TicketItemDTO } from './ticket-item.dto';

export class TicketDTO {
  folio: string;
  estado: TicketEstado;
  fecha_alta: string;
  fecha_cambio_estimado: string;
  items: TicketItemDTO[];
}
