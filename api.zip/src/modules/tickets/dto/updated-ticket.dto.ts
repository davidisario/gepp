export class UpdatedTicketDTO {
  folio: string;
  updated: boolean;
  items_count: number;
}
