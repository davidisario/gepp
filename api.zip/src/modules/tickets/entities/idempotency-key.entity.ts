import { Column, CreateDateColumn, Entity, PrimaryColumn } from 'typeorm';

@Entity('IdempotencyKeys')
export class IdempotencyKey {
  @PrimaryColumn({ type: 'varchar', length: 36 })
  idempotency_key: string;

  @Column({ type: 'varchar', length: 10 })
  folio: string;

  @CreateDateColumn({ type: 'datetime' })
  created_at: Date;

  @Column({ type: 'datetime' })
  expires_at: Date;

  @Column({ type: 'text' })
  request_hash: string;

  @Column({ type: 'varchar', length: 20 })
  operation_type: string; // CREATE, UPDATE, SUBMIT, DELETE
}
