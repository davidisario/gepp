import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

import { CambiosMotivo } from '../../motivos/entities/cambios-motivo.entity';
import { Product } from '../../products/entities/product.entity';
import { Ticket } from './ticket.entity';

@Entity('TicketItems')
export class TicketItem {
  @PrimaryGeneratedColumn()
  id_item: number;

  @Column({ type: 'varchar', length: 10 })
  folio: string;

  @Column({ type: 'int' })
  clave_producto: number;

  @Column({ type: 'int' })
  id_motivo: number;

  @Column({ type: 'int' })
  piezas: number;

  @Column({ type: 'varchar', length: 100, nullable: true })
  justificacion: string;

  @CreateDateColumn({ type: 'datetime' })
  created_at: Date;

  @ManyToOne(() => Ticket, (ticket) => ticket.items, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'folio' })
  ticket: Ticket;

  @ManyToOne(() => Product)
  @JoinColumn({ name: 'clave_producto', referencedColumnName: 'sku' })
  producto: Product;

  @ManyToOne(() => CambiosMotivo)
  @JoinColumn({ name: 'id_motivo' })
  motivo: CambiosMotivo;
}
