import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  UpdateDateColumn,
  VersionColumn,
} from 'typeorm';

import { Operation } from '../../operations/entities/operation.entity';
import { TicketItem } from './ticket-item.entity';

export enum TicketEstado {
  DRAFT = 'DRAFT',
  READY = 'READY',
  SENT = 'SENT',
  CANCELLED = 'CANCELLED',
  REJECTED = 'REJECTED',
  COMPLETED = 'COMPLETED',
}

@Entity('Tickets')
export class Ticket {
  @PrimaryColumn({ type: 'varchar', length: 10 })
  folio: string;

  @Column({ type: 'int' })
  ID_Bodega: number;

  @Column({ type: 'varchar', length: 20 })
  NUD: string;

  @Column({ type: 'int' })
  idoperacion: number;

  @Column({
    type: 'varchar',
    length: 20,
    enum: TicketEstado,
    default: TicketEstado.DRAFT,
  })
  estado: TicketEstado;

  @Column({ type: 'int' })
  created_by: number;

  @CreateDateColumn({ type: 'datetime' })
  created_at: Date;

  @UpdateDateColumn({ type: 'datetime' })
  updated_at: Date;

  @VersionColumn()
  version: number;

  @Column({ type: 'date', nullable: true })
  fecha_cambio_estimado: Date;

  @Column({ type: 'datetime', nullable: true })
  sent_at: Date;

  @Column({ type: 'int', nullable: true })
  sent_by: number;

  @Column({ type: 'datetime', nullable: true })
  cancelled_at: Date;

  @Column({ type: 'int', nullable: true })
  cancelled_by: number;

  @Column({ type: 'varchar', length: 200, nullable: true })
  cancellation_reason: string;

  @OneToMany(() => TicketItem, (item) => item.ticket, { cascade: true })
  items: TicketItem[];

  @ManyToOne(() => Operation)
  @JoinColumn({ name: 'idoperacion' })
  operacion: Operation;
}
