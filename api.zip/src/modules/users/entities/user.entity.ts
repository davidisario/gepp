import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ name: 'usrcambios' })
export class User {
  @PrimaryColumn({ name: 'NumEmpleado', type: 'int' })
  NumEmpleado: number;

  @PrimaryColumn({ name: 'idoperacion', type: 'int' })
  idoperacion: number;

  @Column({ name: 'Nombre', type: 'varchar', length: 45 })
  nombre: string;

  @Column({ name: 'Psw', type: 'varchar', length: 45 })
  psw: string;

  @Column({ name: 'PPP', type: 'int', nullable: true })
  ppp: number | null;

  @Column({ name: 'nivel', type: 'int', nullable: true })
  nivel: number | null;

  @Column({ name: 'asignado', type: 'int', nullable: true })
  asignado: number | null;

  @Column({ name: 'estatus', type: 'int', nullable: true })
  estatus: number | null;

  @Column({ name: 'Email', type: 'nvarchar', length: 200, nullable: true })
  email: string | null;
}
